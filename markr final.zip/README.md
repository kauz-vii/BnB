
  # Gradient Shader Card (Community)

  This is a code bundle for Gradient Shader Card (Community). The original project is available at https://www.figma.com/design/jaxxeojutQ3HkiG5UsINhV/Gradient-Shader-Card--Community-.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  