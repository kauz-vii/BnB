import { Hono } from 'npm:hono';
import { cors } from 'npm:hono/cors';
import { logger } from 'npm:hono/logger';
import { createClient } from 'npm:@supabase/supabase-js@2';

const app = new Hono();

// CORS and logging middleware
app.use('*', cors({
  origin: '*',
  allowMethods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
  allowHeaders: ['Content-Type', 'Authorization'],
}));
app.use('*', logger(console.log));

const supabase = createClient(
  Deno.env.get('SUPABASE_URL')!,
  Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!,
);

// Simple in-memory storage for demo (replace with proper database in production)
const storage = new Map();

// Helper functions
function validateRequiredFields(data: any, fields: string[]): string | null {
  for (const field of fields) {
    if (!data[field] || (typeof data[field] === 'string' && data[field].trim() === '')) {
      return `Missing required field: ${field}`;
    }
  }
  return null;
}

function calculateLevel(xp: number): number {
  return Math.floor(xp / 100) + 1;
}

async function getUser(request: Request) {
  const accessToken = request.headers.get('Authorization')?.split(' ')[1];
  if (!accessToken) return null;
  
  try {
    const { data: { user }, error } = await supabase.auth.getUser(accessToken);
    if (error || !user) return null;
    return user;
  } catch {
    return null;
  }
}

// Initialize some mock data
if (!storage.has('global_activities')) {
  storage.set('global_activities', []);
}

if (!storage.has('maps')) {
  storage.set('maps', []);
}

if (!storage.has('users')) {
  storage.set('users', []);
}

// Routes
app.get('/health', (c) => {
  return c.json({
    status: 'healthy',
    timestamp: new Date().toISOString(),
    service: 'TravelMapX API',
    version: '1.0.0'
  });
});

// Auth routes
app.post('/auth/signup', async (c) => {
  try {
    const requestData = await c.req.json();
    const validationError = validateRequiredFields(requestData, ['email', 'password', 'name']);
    
    if (validationError) {
      return c.json({ error: validationError }, 400);
    }
    
    const { email, password, name } = requestData;
    
    if (password.length < 6) {
      return c.json({ error: 'Password must be at least 6 characters long' }, 400);
    }
    
    const { data, error } = await supabase.auth.admin.createUser({
      email,
      password,
      user_metadata: { name },
      email_confirm: true
    });

    if (error) {
      return c.json({ error: `Signup error: ${error.message}` }, 400);
    }

    const userId = data.user.id;
    const profile = {
      id: userId,
      name: name.trim(),
      email,
      level: 1,
      xp: 0,
      totalDistance: 0,
      placesExplored: 0,
      mapsContributed: 0,
      achievements: [],
      badges: [],
      preferences: {
        theme: 'light',
        notifications: true,
        privacy: 'public'
      },
      stats: {
        loginStreak: 1,
        lastLogin: new Date().toISOString(),
        totalSessions: 1
      },
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };
    
    const users = storage.get('users') || [];
    users.push(profile);
    storage.set('users', users);
    storage.set(`user:${userId}`, profile);

    return c.json({ 
      user: data.user,
      profile,
      message: 'Account created successfully!' 
    });
  } catch (error) {
    return c.json({ error: `Signup error: ${error.message || 'Unknown error'}` }, 500);
  }
});

app.post('/auth/oauth-profile', async (c) => {
  try {
    const user = await getUser(c.req.raw);
    if (!user) {
      return c.json({ error: 'Unauthorized' }, 401);
    }
    
    const existingProfile = storage.get(`user:${user.id}`);
    if (existingProfile) {
      return c.json({ profile: existingProfile });
    }
    
    const name = user.user_metadata?.name || user.user_metadata?.full_name || 'Travel Explorer';
    const profile = {
      id: user.id,
      name,
      email: user.email,
      level: 1,
      xp: 0,
      totalDistance: 0,
      placesExplored: 0,
      mapsContributed: 0,
      achievements: [],
      badges: [],
      preferences: {
        theme: 'light',
        notifications: true,
        privacy: 'public'
      },
      stats: {
        loginStreak: 1,
        lastLogin: new Date().toISOString(),
        totalSessions: 1
      },
      authProvider: user.app_metadata?.provider || 'email',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };
    
    const users = storage.get('users') || [];
    users.push(profile);
    storage.set('users', users);
    storage.set(`user:${user.id}`, profile);
    
    return c.json({ profile });
  } catch (error) {
    return c.json({ error: 'Failed to create OAuth profile' }, 500);
  }
});

// Profile routes
app.get('/profile', async (c) => {
  try {
    const user = await getUser(c.req.raw);
    if (!user) {
      return c.json({ error: 'Unauthorized' }, 401);
    }

    const profile = storage.get(`user:${user.id}`);
    if (!profile) {
      return c.json({ error: 'Profile not found' }, 404);
    }

    return c.json(profile);
  } catch (error) {
    return c.json({ error: `Get profile error: ${error.message}` }, 500);
  }
});

app.put('/profile', async (c) => {
  try {
    const user = await getUser(c.req.raw);
    if (!user) {
      return c.json({ error: 'Unauthorized' }, 401);
    }

    const updates = await c.req.json();
    const currentProfile = storage.get(`user:${user.id}`);
    
    if (!currentProfile) {
      return c.json({ error: 'Profile not found' }, 404);
    }

    const allowedFields = ['name', 'preferences'];
    const sanitizedUpdates = {};
    
    for (const [key, value] of Object.entries(updates)) {
      if (allowedFields.includes(key)) {
        sanitizedUpdates[key] = value;
      }
    }
    
    const updatedProfile = { 
      ...currentProfile, 
      ...sanitizedUpdates,
      level: calculateLevel(currentProfile.xp || 0),
      updatedAt: new Date().toISOString()
    };
    
    storage.set(`user:${user.id}`, updatedProfile);

    return c.json(updatedProfile);
  } catch (error) {
    return c.json({ error: `Update profile error: ${error.message}` }, 500);
  }
});

// Leaderboard
app.get('/leaderboard', (c) => {
  try {
    const query = c.req.query();
    const type = query.type || 'xp';
    const limit = Math.min(parseInt(query.limit || '50'), 100);
    
    const users = storage.get('users') || [];
    
    users.sort((a, b) => {
      switch (type) {
        case 'maps':
          return (b.mapsContributed || 0) - (a.mapsContributed || 0);
        case 'places':
          return (b.placesExplored || 0) - (a.placesExplored || 0);
        case 'distance':
          return (b.totalDistance || 0) - (a.totalDistance || 0);
        case 'xp':
        default:
          return (b.xp || 0) - (a.xp || 0);
      }
    });
    
    const leaderboard = users.slice(0, limit).map((profile, index) => ({
      rank: index + 1,
      id: profile.id,
      username: profile.name,
      xp: profile.xp || 0,
      level: profile.level || 1,
      placesExplored: profile.placesExplored || 0,
      mapsContributed: profile.mapsContributed || 0,
      totalDistance: profile.totalDistance || 0,
      achievements: profile.achievements?.length || 0,
      badges: profile.badges?.length || 0,
      joinDate: profile.createdAt
    }));
    
    return c.json(leaderboard);
  } catch (error) {
    return c.json({ error: `Leaderboard error: ${error.message}` }, 500);
  }
});

// Maps
app.get('/maps', (c) => {
  try {
    const query = c.req.query();
    const limit = Math.min(parseInt(query.limit || '20'), 50);
    
    const maps = storage.get('maps') || [];
    const publicMaps = maps.filter(map => map.visibility === 'public');
    
    const enhancedMaps = publicMaps.slice(0, limit).map(map => ({
      ...map,
      creator: { name: 'Demo User', level: 5 },
      markerCount: map.markers?.length || 0
    }));
    
    return c.json({
      maps: enhancedMaps,
      pagination: {
        page: 1,
        limit,
        total: publicMaps.length,
        totalPages: Math.ceil(publicMaps.length / limit),
        hasNext: false,
        hasPrev: false
      }
    });
  } catch (error) {
    return c.json({ error: `Get maps error: ${error.message}` }, 500);
  }
});

app.post('/maps', async (c) => {
  try {
    const user = await getUser(c.req.raw);
    if (!user) {
      return c.json({ error: 'Unauthorized' }, 401);
    }

    const requestData = await c.req.json();
    const validationError = validateRequiredFields(requestData, ['title', 'visibility']);
    
    if (validationError) {
      return c.json({ error: validationError }, 400);
    }
    
    const { title, description, visibility, tags, centerCoords } = requestData;
    
    if (!['public', 'private', 'unlisted'].includes(visibility)) {
      return c.json({ error: 'Invalid visibility option' }, 400);
    }
    
    const mapId = crypto.randomUUID();
    const map = {
      id: mapId,
      title: title.trim(),
      description: description?.trim() || '',
      visibility,
      tags: tags || [],
      centerCoords: centerCoords || { lat: 0, lng: 0 },
      createdBy: user.id,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      markers: [],
      stats: { views: 0, likes: 0, forks: 0 }
    };

    const maps = storage.get('maps') || [];
    maps.push(map);
    storage.set('maps', maps);

    // Update user profile
    const profile = storage.get(`user:${user.id}`);
    if (profile) {
      profile.mapsContributed += 1;
      profile.xp += 50;
      profile.level = calculateLevel(profile.xp);
      storage.set(`user:${user.id}`, profile);
    }

    return c.json({ 
      map,
      message: 'Map created successfully!',
      xpGained: 50
    });
  } catch (error) {
    return c.json({ error: `Create map error: ${error.message}` }, 500);
  }
});

// Location services
app.get('/user-location', (c) => {
  const mockLocations = [
    { lat: 40.7128, lng: -74.0060, name: 'New York City, NY' },
    { lat: 34.0522, lng: -118.2437, name: 'Los Angeles, CA' },
    { lat: 51.5074, lng: -0.1278, name: 'London, UK' },
    { lat: 48.8566, lng: 2.3522, name: 'Paris, France' }
  ];
  
  const location = mockLocations[Math.floor(Math.random() * mockLocations.length)];
  
  return c.json({
    lat: location.lat + (Math.random() - 0.5) * 0.01,
    lng: location.lng + (Math.random() - 0.5) * 0.01,
    accuracy: 10 + Math.random() * 20,
    timestamp: new Date().toISOString(),
    source: 'mock_gps',
    address: location.name
  });
});

app.get('/directions', (c) => {
  try {
    const query = c.req.query();
    const validationError = validateRequiredFields(query, ['origin_lat', 'origin_lng', 'destination_lat', 'destination_lng']);
    
    if (validationError) {
      return c.json({ error: validationError }, 400);
    }
    
    const originLat = parseFloat(query.origin_lat);
    const originLng = parseFloat(query.origin_lng);
    const destLat = parseFloat(query.destination_lat);
    const destLng = parseFloat(query.destination_lng);
    
    if (isNaN(originLat) || isNaN(originLng) || isNaN(destLat) || isNaN(destLng)) {
      return c.json({ error: 'Invalid coordinate values' }, 400);
    }
    
    // Simple distance calculation
    const R = 6371;
    const dLat = (destLat - originLat) * Math.PI / 180;
    const dLng = (destLng - originLng) * Math.PI / 180;
    const a = Math.sin(dLat/2) * Math.sin(dLat/2) +
              Math.cos(originLat * Math.PI / 180) * Math.cos(destLat * Math.PI / 180) *
              Math.sin(dLng/2) * Math.sin(dLng/2);
    const c_calc = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
    const distance = R * c_calc;
    
    return c.json({
      distance: Math.round(distance * 1000),
      duration: Math.round(distance * 1000 / 1.4 * 60),
      start: { lat: originLat, lng: originLng },
      end: { lat: destLat, lng: destLng },
      steps: [
        {
          instruction: "Head towards your destination",
          distance: Math.round(distance * 1000 * 0.5),
          duration: Math.round(distance * 1000 / 1.4 * 60 * 0.5),
          coordinates: [[originLng, originLat], [destLng, destLat]]
        },
        {
          instruction: "Arrive at destination",
          distance: Math.round(distance * 1000 * 0.5),
          duration: Math.round(distance * 1000 / 1.4 * 60 * 0.5),
          coordinates: [[destLng, destLat]]
        }
      ],
      polyline: [[originLng, originLat], [destLng, destLat]],
      mode: query.mode || 'walking',
      created_at: new Date().toISOString()
    });
  } catch (error) {
    return c.json({ error: `Directions error: ${error.message}` }, 500);
  }
});

// Activity feed
app.get('/activity', (c) => {
  try {
    const query = c.req.query();
    const limit = Math.min(parseInt(query.limit || '20'), 100);
    
    const activities = storage.get('global_activities') || [];
    
    return c.json({
      activities: activities.slice(0, limit).map(activity => ({
        ...activity,
        user: { id: 'demo', name: 'Demo User', level: 5 }
      })),
      total: activities.length,
      limit
    });
  } catch (error) {
    return c.json({ error: `Activity feed error: ${error.message}` }, 500);
  }
});

// Search
app.get('/search', (c) => {
  try {
    const query = c.req.query();
    const searchQuery = query.q?.toLowerCase();
    const limit = Math.min(parseInt(query.limit || '20'), 50);
    
    if (!searchQuery || searchQuery.length < 2) {
      return c.json({ error: 'Search query must be at least 2 characters' }, 400);
    }
    
    const maps = storage.get('maps') || [];
    const users = storage.get('users') || [];
    
    const filteredMaps = maps.filter(map => 
      map.visibility === 'public' &&
      (map.title.toLowerCase().includes(searchQuery) ||
       map.description?.toLowerCase().includes(searchQuery))
    ).slice(0, limit);
    
    const filteredUsers = users.filter(user => 
      user.preferences?.privacy !== 'private' &&
      user.name.toLowerCase().includes(searchQuery)
    ).slice(0, limit);
    
    return c.json({
      maps: filteredMaps.map(map => ({ ...map, type: 'map' })),
      users: filteredUsers.map(user => ({ ...user, type: 'user' })),
      markers: [],
      total: filteredMaps.length + filteredUsers.length
    });
  } catch (error) {
    return c.json({ error: `Search error: ${error.message}` }, 500);
  }
});

// Error handlers
app.notFound((c) => {
  return c.json({ error: 'Endpoint not found' }, 404);
});

app.onError((err, c) => {
  console.error('Server error:', err);
  return c.json({ 
    error: 'Internal server error',
    message: err.message 
  }, 500);
});

Deno.serve(app.fetch);