import { Hono } from 'npm:hono';
import { cors } from 'npm:hono/cors';
import { logger } from 'npm:hono/logger';
import { createClient } from 'npm:@supabase/supabase-js@2';
import * as kv from './kv_store.tsx';

const app = new Hono();

// CORS and logging middleware
app.use('*', cors({
  origin: '*',
  allowMethods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
  allowHeaders: ['Content-Type', 'Authorization'],
}));
app.use('*', logger(console.log));

const supabase = createClient(
  Deno.env.get('SUPABASE_URL')!,
  Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!,
);

// Storage bucket setup for user-generated content
const BUCKET_NAME = 'make-52837870-travel-assets';

// Initialize storage bucket on startup
async function initializeStorage() {
  try {
    const { data: buckets } = await supabase.storage.listBuckets();
    const bucketExists = buckets?.some(bucket => bucket.name === BUCKET_NAME);
    
    if (!bucketExists) {
      const { error } = await supabase.storage.createBucket(BUCKET_NAME, {
        public: false,
        allowedMimeTypes: ['image/*'],
        fileSizeLimit: 5242880, // 5MB
      });
      
      if (error) {
        console.log('Error creating storage bucket:', error);
      } else {
        console.log('Storage bucket created successfully');
      }
    }
  } catch (error) {
    console.log('Error initializing storage:', error);
  }
}

// Initialize storage on server start
initializeStorage();

// Helper function to get user from access token
async function getUser(request: Request) {
  const accessToken = request.headers.get('Authorization')?.split(' ')[1];
  if (!accessToken) return null;
  
  const { data: { user }, error } = await supabase.auth.getUser(accessToken);
  if (error || !user) return null;
  
  return user;
}

// Helper function to validate request data
function validateRequiredFields(data: any, fields: string[]): string | null {
  for (const field of fields) {
    if (!data[field] || (typeof data[field] === 'string' && data[field].trim() === '')) {
      return `Missing required field: ${field}`;
    }
  }
  return null;
}

// Helper function to calculate user level from XP
function calculateLevel(xp: number): number {
  // Level progression: Level 1 = 0-99 XP, Level 2 = 100-299 XP, etc.
  return Math.floor(xp / 100) + 1;
}

// Helper function to add activity with better error handling
async function addActivity(userId: string, action: string, location: string, metadata?: any) {
  try {
    const activitiesKey = `activities:${userId}`;
    const activities = await kv.get(activitiesKey) || [];
    
    const activity = {
      id: crypto.randomUUID(),
      action,
      location,
      metadata: metadata || {},
      timestamp: new Date().toISOString(),
      userId
    };
    
    activities.unshift(activity);
    
    // Keep only latest 100 activities per user
    if (activities.length > 100) {
      activities.splice(100);
    }
    
    await kv.set(activitiesKey, activities);
    
    // Also add to global activity feed
    const globalKey = 'global_activities';
    const globalActivities = await kv.get(globalKey) || [];
    globalActivities.unshift(activity);
    
    // Keep only latest 500 global activities
    if (globalActivities.length > 500) {
      globalActivities.splice(500);
    }
    
    await kv.set(globalKey, globalActivities);
    
    return activity;
  } catch (error) {
    console.log('Error adding activity:', error);
    return null;
  }
}

// Auth Routes
app.post('/make-server-52837870/auth/signup', async (c) => {
  try {
    const requestData = await c.req.json();
    const validationError = validateRequiredFields(requestData, ['email', 'password', 'name']);
    
    if (validationError) {
      return c.json({ error: validationError }, 400);
    }
    
    const { email, password, name } = requestData;
    
    // Validate password strength
    if (password.length < 6) {
      return c.json({ error: 'Password must be at least 6 characters long' }, 400);
    }
    
    const { data, error } = await supabase.auth.admin.createUser({
      email,
      password,
      user_metadata: { name },
      // Automatically confirm the user's email since an email server hasn't been configured.
      email_confirm: true
    });

    if (error) {
      console.log('Signup error:', error);
      return c.json({ error: `Signup error: ${error.message}` }, 400);
    }

    // Initialize comprehensive user profile
    const userId = data.user.id;
    const initialProfile = {
      id: userId,
      name: name.trim(),
      email,
      level: 1,
      xp: 0,
      totalDistance: 0,
      placesExplored: 0,
      mapsContributed: 0,
      achievements: [],
      badges: [],
      preferences: {
        theme: 'light',
        notifications: true,
        privacy: 'public'
      },
      stats: {
        loginStreak: 1,
        lastLogin: new Date().toISOString(),
        totalSessions: 1
      },
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };
    
    await kv.set(`user:${userId}`, initialProfile);
    
    // Add welcome activity
    await addActivity(userId, 'joined', 'TravelMapX Community', {
      welcomeMessage: 'Welcome to TravelMapX!'
    });

    return c.json({ 
      user: data.user,
      profile: initialProfile,
      message: 'Account created successfully! Welcome to TravelMapX!' 
    });
  } catch (error) {
    console.log('Signup error:', error);
    return c.json({ error: `Signup error: ${error.message || 'Unknown error'}` }, 500);
  }
});

// OAuth initiation route
app.post('/make-server-52837870/auth/oauth', async (c) => {
  try {
    const { provider } = await c.req.json();
    
    if (!['google', 'github', 'discord'].includes(provider)) {
      return c.json({ error: 'Unsupported OAuth provider' }, 400);
    }
    
    // Note: OAuth setup requires configuration in Supabase dashboard
    // Users will need to configure their OAuth providers in Supabase
    return c.json({ 
      message: `OAuth with ${provider} initiated. Please complete setup in Supabase dashboard.`,
      provider,
      setupUrl: 'https://supabase.com/docs/guides/auth/social-login'
    });
  } catch (error) {
    console.log('OAuth error:', error);
    return c.json({ error: 'OAuth initialization failed' }, 500);
  }
});

// Handle OAuth callback and profile creation
app.post('/make-server-52837870/auth/oauth-profile', async (c) => {
  try {
    const user = await getUser(c.req.raw);
    if (!user) {
      return c.json({ error: 'Unauthorized' }, 401);
    }
    
    // Check if profile already exists
    const existingProfile = await kv.get(`user:${user.id}`);
    if (existingProfile) {
      return c.json({ profile: existingProfile });
    }
    
    // Create profile for OAuth user
    const name = user.user_metadata?.name || user.user_metadata?.full_name || 'Travel Explorer';
    const profile = {
      id: user.id,
      name,
      email: user.email,
      level: 1,
      xp: 0,
      totalDistance: 0,
      placesExplored: 0,
      mapsContributed: 0,
      achievements: [],
      badges: [],
      preferences: {
        theme: 'light',
        notifications: true,
        privacy: 'public'
      },
      stats: {
        loginStreak: 1,
        lastLogin: new Date().toISOString(),
        totalSessions: 1
      },
      authProvider: user.app_metadata?.provider || 'email',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };
    
    await kv.set(`user:${user.id}`, profile);
    
    await addActivity(user.id, 'joined', 'TravelMapX Community', {
      provider: user.app_metadata?.provider,
      welcomeMessage: 'Welcome to TravelMapX!'
    });
    
    return c.json({ profile });
  } catch (error) {
    console.log('OAuth profile creation error:', error);
    return c.json({ error: 'Failed to create OAuth profile' }, 500);
  }
});

// User Profile Routes
app.get('/make-server-52837870/profile', async (c) => {
  try {
    const user = await getUser(c.req.raw);
    if (!user) {
      return c.json({ error: 'Unauthorized' }, 401);
    }

    const profile = await kv.get(`user:${user.id}`);
    if (!profile) {
      return c.json({ error: 'Profile not found' }, 404);
    }

    return c.json(profile);
  } catch (error) {
    console.log('Get profile error:', error);
    return c.json({ error: `Get profile error: ${error.message}` }, 500);
  }
});

app.put('/make-server-52837870/profile', async (c) => {
  try {
    const user = await getUser(c.req.raw);
    if (!user) {
      return c.json({ error: 'Unauthorized' }, 401);
    }

    const updates = await c.req.json();
    const currentProfile = await kv.get(`user:${user.id}`);
    
    if (!currentProfile) {
      return c.json({ error: 'Profile not found' }, 404);
    }

    // Validate and sanitize updates
    const allowedFields = ['name', 'preferences', 'privacy'];
    const sanitizedUpdates = {};
    
    for (const [key, value] of Object.entries(updates)) {
      if (allowedFields.includes(key)) {
        sanitizedUpdates[key] = value;
      }
    }
    
    // Update level based on XP
    if (currentProfile.xp !== undefined) {
      currentProfile.level = calculateLevel(currentProfile.xp);
    }
    
    const updatedProfile = { 
      ...currentProfile, 
      ...sanitizedUpdates,
      updatedAt: new Date().toISOString()
    };
    
    await kv.set(`user:${user.id}`, updatedProfile);
    
    // Add activity for significant profile updates
    if (sanitizedUpdates.name && sanitizedUpdates.name !== currentProfile.name) {
      await addActivity(user.id, 'updated_profile', 'Profile Settings', {
        field: 'name',
        oldValue: currentProfile.name,
        newValue: sanitizedUpdates.name
      });
    }

    return c.json(updatedProfile);
  } catch (error) {
    console.log('Update profile error:', error);
    return c.json({ error: `Update profile error: ${error.message}` }, 500);
  }
});

// User statistics endpoint
app.get('/make-server-52837870/profile/stats', async (c) => {
  try {
    const user = await getUser(c.req.raw);
    if (!user) {
      return c.json({ error: 'Unauthorized' }, 401);
    }
    
    const profile = await kv.get(`user:${user.id}`);
    if (!profile) {
      return c.json({ error: 'Profile not found' }, 404);
    }
    
    // Get user's maps
    const userMaps = await kv.get(`user_maps:${user.id}`) || [];
    const maps = await Promise.all(
      userMaps.slice(0, 10).map(async (mapId) => await kv.get(`map:${mapId}`))
    );
    
    // Get recent activities
    const activities = await kv.get(`activities:${user.id}`) || [];
    
    // Calculate additional stats
    const totalMarkers = maps.reduce((acc, map) => acc + (map?.markers?.length || 0), 0);
    const publicMaps = maps.filter(map => map?.visibility === 'public').length;
    
    const stats = {
      profile: {
        level: profile.level,
        xp: profile.xp,
        totalDistance: profile.totalDistance,
        placesExplored: profile.placesExplored,
        mapsContributed: profile.mapsContributed
      },
      detailed: {
        totalMarkers,
        publicMaps,
        privateMaps: maps.length - publicMaps,
        recentActivities: activities.slice(0, 5),
        joinDate: profile.createdAt,
        achievements: profile.achievements || [],
        badges: profile.badges || []
      },
      engagement: {
        loginStreak: profile.stats?.loginStreak || 0,
        lastLogin: profile.stats?.lastLogin,
        totalSessions: profile.stats?.totalSessions || 0
      }
    };
    
    return c.json(stats);
  } catch (error) {
    console.log('Get stats error:', error);
    return c.json({ error: `Get stats error: ${error.message}` }, 500);
  }
});

// Maps Routes
app.post('/make-server-52837870/maps', async (c) => {
  try {
    const user = await getUser(c.req.raw);
    if (!user) {
      return c.json({ error: 'Unauthorized' }, 401);
    }

    const requestData = await c.req.json();
    const validationError = validateRequiredFields(requestData, ['title', 'visibility']);
    
    if (validationError) {
      return c.json({ error: validationError }, 400);
    }
    
    const { title, description, visibility, tags, centerCoords } = requestData;
    
    // Validate visibility
    if (!['public', 'private', 'unlisted'].includes(visibility)) {
      return c.json({ error: 'Invalid visibility option' }, 400);
    }
    
    const mapId = crypto.randomUUID();
    
    const map = {
      id: mapId,
      title: title.trim(),
      description: description?.trim() || '',
      visibility,
      tags: tags || [],
      centerCoords: centerCoords || { lat: 0, lng: 0 },
      createdBy: user.id,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      markers: [],
      stats: {
        views: 0,
        likes: 0,
        forks: 0
      },
      settings: {
        allowComments: true,
        allowForks: visibility === 'public',
        showCreator: true
      }
    };

    await kv.set(`map:${mapId}`, map);
    
    // Add to user's maps list
    const userMapsKey = `user_maps:${user.id}`;
    const userMaps = await kv.get(userMapsKey) || [];
    userMaps.unshift(mapId); // Add to beginning for recent first
    await kv.set(userMapsKey, userMaps);

    // Update user stats with level calculation
    const profile = await kv.get(`user:${user.id}`);
    if (profile) {
      profile.mapsContributed += 1;
      profile.xp += 50; // XP for creating a map
      profile.level = calculateLevel(profile.xp);
      profile.updatedAt = new Date().toISOString();
      await kv.set(`user:${user.id}`, profile);
    }
    
    // Add activity
    await addActivity(user.id, 'created_map', title, {
      mapId,
      visibility,
      xpGained: 50
    });

    return c.json({ 
      map,
      message: 'Map created successfully!',
      xpGained: 50
    });
  } catch (error) {
    console.log('Create map error:', error);
    return c.json({ error: `Create map error: ${error.message}` }, 500);
  }
});

app.get('/make-server-52837870/maps', async (c) => {
  try {
    const user = await getUser(c.req.raw);
    const query = c.req.query();
    
    // Get pagination parameters
    const page = parseInt(query.page || '1');
    const limit = Math.min(parseInt(query.limit || '20'), 50); // Max 50 maps per request
    const search = query.search?.toLowerCase();
    const tag = query.tag;
    const sortBy = query.sortBy || 'created'; // created, updated, popular
    
    let maps = await kv.getByPrefix('map:');
    
    // Filter maps based on visibility and user access
    maps = maps.filter(map => {
      if (map.visibility === 'public') return true;
      if (map.visibility === 'unlisted') return true; // Anyone with link can view
      if (user && map.createdBy === user.id) return true; // Owner can always see
      return false;
    });
    
    // Apply search filter
    if (search) {
      maps = maps.filter(map => 
        map.title.toLowerCase().includes(search) ||
        map.description?.toLowerCase().includes(search) ||
        map.tags?.some(tag => tag.toLowerCase().includes(search))
      );
    }
    
    // Apply tag filter
    if (tag) {
      maps = maps.filter(map => 
        map.tags?.some(mapTag => mapTag.toLowerCase() === tag.toLowerCase())
      );
    }
    
    // Sort maps
    maps.sort((a, b) => {
      switch (sortBy) {
        case 'updated':
          return new Date(b.updatedAt || b.createdAt).getTime() - new Date(a.updatedAt || a.createdAt).getTime();
        case 'popular':
          return (b.stats?.views || 0) + (b.stats?.likes || 0) - ((a.stats?.views || 0) + (a.stats?.likes || 0));
        case 'created':
        default:
          return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
      }
    });
    
    // Pagination
    const startIndex = (page - 1) * limit;
    const endIndex = startIndex + limit;
    const paginatedMaps = maps.slice(startIndex, endIndex);
    
    // Enhance map data with creator info
    const enhancedMaps = await Promise.all(
      paginatedMaps.map(async (map) => {
        const creator = await kv.get(`user:${map.createdBy}`);
        return {
          ...map,
          creator: creator ? {
            id: creator.id,
            name: creator.name,
            level: creator.level
          } : null,
          markerCount: map.markers?.length || 0
        };
      })
    );
    
    return c.json({
      maps: enhancedMaps,
      pagination: {
        page,
        limit,
        total: maps.length,
        totalPages: Math.ceil(maps.length / limit),
        hasNext: endIndex < maps.length,
        hasPrev: page > 1
      },
      filters: {
        search,
        tag,
        sortBy
      }
    });
  } catch (error) {
    console.log('Get maps error:', error);
    return c.json({ error: `Get maps error: ${error.message}` }, 500);
  }
});

app.get('/make-server-52837870/maps/:id', async (c) => {
  try {
    const mapId = c.req.param('id');
    const map = await kv.get(`map:${mapId}`);
    
    if (!map) {
      return c.json({ error: 'Map not found' }, 404);
    }

    // Check if user can access this map
    const user = await getUser(c.req.raw);
    if (map.visibility === 'private' && (!user || map.createdBy !== user.id)) {
      return c.json({ error: 'Access denied' }, 403);
    }
    
    // Increment view count (only if not the owner)
    if (!user || map.createdBy !== user.id) {
      map.stats = map.stats || { views: 0, likes: 0, forks: 0 };
      map.stats.views += 1;
      await kv.set(`map:${mapId}`, map);
    }
    
    // Get creator information
    const creator = await kv.get(`user:${map.createdBy}`);
    
    // Get user's interaction with this map
    let userInteraction = null;
    if (user) {
      const userInteractionKey = `user_map_interaction:${user.id}:${mapId}`;
      userInteraction = await kv.get(userInteractionKey);
    }

    const enhancedMap = {
      ...map,
      creator: creator ? {
        id: creator.id,
        name: creator.name,
        level: creator.level
      } : null,
      userInteraction: userInteraction || {
        liked: false,
        bookmarked: false,
        visited: false
      },
      markerCount: map.markers?.length || 0
    };

    return c.json(enhancedMap);
  } catch (error) {
    console.log('Get map error:', error);
    return c.json({ error: `Get map error: ${error.message}` }, 500);
  }
});

// Map interaction routes (like, bookmark, etc.)
app.post('/make-server-52837870/maps/:id/like', async (c) => {
  try {
    const user = await getUser(c.req.raw);
    if (!user) {
      return c.json({ error: 'Unauthorized' }, 401);
    }
    
    const mapId = c.req.param('id');
    const map = await kv.get(`map:${mapId}`);
    
    if (!map) {
      return c.json({ error: 'Map not found' }, 404);
    }
    
    const interactionKey = `user_map_interaction:${user.id}:${mapId}`;
    const interaction = await kv.get(interactionKey) || {};
    
    const wasLiked = interaction.liked || false;
    interaction.liked = !wasLiked;
    
    // Update map stats
    map.stats = map.stats || { views: 0, likes: 0, forks: 0 };
    map.stats.likes += wasLiked ? -1 : 1;
    
    await kv.set(interactionKey, interaction);
    await kv.set(`map:${mapId}`, map);
    
    // Add activity if liked (not for unlike)
    if (!wasLiked) {
      await addActivity(user.id, 'liked_map', map.title, {
        mapId,
        createdBy: map.createdBy
      });
    }
    
    return c.json({ 
      liked: interaction.liked,
      totalLikes: map.stats.likes,
      message: interaction.liked ? 'Map liked!' : 'Map unliked'
    });
  } catch (error) {
    console.log('Like map error:', error);
    return c.json({ error: `Like map error: ${error.message}` }, 500);
  }
});

// Update map route
app.put('/make-server-52837870/maps/:id', async (c) => {
  try {
    const user = await getUser(c.req.raw);
    if (!user) {
      return c.json({ error: 'Unauthorized' }, 401);
    }
    
    const mapId = c.req.param('id');
    const map = await kv.get(`map:${mapId}`);
    
    if (!map) {
      return c.json({ error: 'Map not found' }, 404);
    }
    
    if (map.createdBy !== user.id) {
      return c.json({ error: 'Permission denied' }, 403);
    }
    
    const updates = await c.req.json();
    const allowedFields = ['title', 'description', 'visibility', 'tags', 'centerCoords', 'settings'];
    
    const sanitizedUpdates = {};
    for (const [key, value] of Object.entries(updates)) {
      if (allowedFields.includes(key)) {
        sanitizedUpdates[key] = value;
      }
    }
    
    const updatedMap = {
      ...map,
      ...sanitizedUpdates,
      updatedAt: new Date().toISOString()
    };
    
    await kv.set(`map:${mapId}`, updatedMap);
    
    await addActivity(user.id, 'updated_map', map.title, {
      mapId,
      changes: Object.keys(sanitizedUpdates)
    });
    
    return c.json({ 
      map: updatedMap,
      message: 'Map updated successfully!'
    });
  } catch (error) {
    console.log('Update map error:', error);
    return c.json({ error: `Update map error: ${error.message}` }, 500);
  }
});

// Markers Routes
app.post('/make-server-52837870/maps/:id/markers', async (c) => {
  try {
    const user = await getUser(c.req.raw);
    if (!user) {
      return c.json({ error: 'Unauthorized' }, 401);
    }

    const mapId = c.req.param('id');
    const requestData = await c.req.json();
    
    const validationError = validateRequiredFields(requestData, ['category', 'title', 'lat', 'lng']);
    if (validationError) {
      return c.json({ error: validationError }, 400);
    }
    
    const { category, title, notes, lat, lng, address, tags } = requestData;
    
    // Validate coordinates
    if (typeof lat !== 'number' || typeof lng !== 'number' ||
        lat < -90 || lat > 90 || lng < -180 || lng > 180) {
      return c.json({ error: 'Invalid coordinates' }, 400);
    }
    
    // Validate category
    const validCategories = ['food', 'toilets', 'attractions', 'notes', 'transport', 'accommodation', 'shopping'];
    if (!validCategories.includes(category)) {
      return c.json({ error: 'Invalid category' }, 400);
    }
    
    const map = await kv.get(`map:${mapId}`);
    if (!map) {
      return c.json({ error: 'Map not found' }, 404);
    }
    
    // Check if user can add markers to this map
    if (map.visibility === 'private' && map.createdBy !== user.id) {
      return c.json({ error: 'Permission denied' }, 403);
    }

    const markerId = crypto.randomUUID();
    const marker = {
      id: markerId,
      category,
      title: title.trim(),
      notes: notes?.trim() || '',
      lat,
      lng,
      address: address?.trim() || '',
      tags: tags || [],
      createdBy: user.id,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      interactions: {
        visits: 0,
        likes: 0,
        comments: []
      }
    };

    map.markers = map.markers || [];
    map.markers.push(marker);
    map.updatedAt = new Date().toISOString();
    await kv.set(`map:${mapId}`, map);

    // Update user stats with level calculation
    const profile = await kv.get(`user:${user.id}`);
    if (profile) {
      profile.placesExplored += 1;
      profile.xp += 10; // XP for adding a marker
      profile.level = calculateLevel(profile.xp);
      profile.updatedAt = new Date().toISOString();
      await kv.set(`user:${user.id}`, profile);
    }
    
    // Add activity
    await addActivity(user.id, 'added_marker', `${title} (${category})`, {
      mapId,
      markerId,
      mapTitle: map.title,
      category,
      xpGained: 10
    });

    return c.json({ 
      marker,
      message: 'Marker added successfully!',
      xpGained: 10
    });
  } catch (error) {
    console.log('Create marker error:', error);
    return c.json({ error: `Create marker error: ${error.message}` }, 500);
  }
});

// Update marker route
app.put('/make-server-52837870/maps/:mapId/markers/:markerId', async (c) => {
  try {
    const user = await getUser(c.req.raw);
    if (!user) {
      return c.json({ error: 'Unauthorized' }, 401);
    }
    
    const mapId = c.req.param('mapId');
    const markerId = c.req.param('markerId');
    
    const map = await kv.get(`map:${mapId}`);
    if (!map) {
      return c.json({ error: 'Map not found' }, 404);
    }
    
    const markerIndex = map.markers?.findIndex(m => m.id === markerId);
    if (markerIndex === -1) {
      return c.json({ error: 'Marker not found' }, 404);
    }
    
    const marker = map.markers[markerIndex];
    
    // Check permissions
    if (marker.createdBy !== user.id && map.createdBy !== user.id) {
      return c.json({ error: 'Permission denied' }, 403);
    }
    
    const updates = await c.req.json();
    const allowedFields = ['title', 'notes', 'category', 'tags', 'address'];
    
    const sanitizedUpdates = {};
    for (const [key, value] of Object.entries(updates)) {
      if (allowedFields.includes(key)) {
        sanitizedUpdates[key] = value;
      }
    }
    
    const updatedMarker = {
      ...marker,
      ...sanitizedUpdates,
      updatedAt: new Date().toISOString()
    };
    
    map.markers[markerIndex] = updatedMarker;
    map.updatedAt = new Date().toISOString();
    await kv.set(`map:${mapId}`, map);
    
    await addActivity(user.id, 'updated_marker', updatedMarker.title, {
      mapId,
      markerId,
      mapTitle: map.title,
      changes: Object.keys(sanitizedUpdates)
    });
    
    return c.json({ 
      marker: updatedMarker,
      message: 'Marker updated successfully!'
    });
  } catch (error) {
    console.log('Update marker error:', error);
    return c.json({ error: `Update marker error: ${error.message}` }, 500);
  }
});

// Delete marker route
app.delete('/make-server-52837870/maps/:mapId/markers/:markerId', async (c) => {
  try {
    const user = await getUser(c.req.raw);
    if (!user) {
      return c.json({ error: 'Unauthorized' }, 401);
    }
    
    const mapId = c.req.param('mapId');
    const markerId = c.req.param('markerId');
    
    const map = await kv.get(`map:${mapId}`);
    if (!map) {
      return c.json({ error: 'Map not found' }, 404);
    }
    
    const markerIndex = map.markers?.findIndex(m => m.id === markerId);
    if (markerIndex === -1) {
      return c.json({ error: 'Marker not found' }, 404);
    }
    
    const marker = map.markers[markerIndex];
    
    // Check permissions
    if (marker.createdBy !== user.id && map.createdBy !== user.id) {
      return c.json({ error: 'Permission denied' }, 403);
    }
    
    // Remove marker from map
    map.markers.splice(markerIndex, 1);
    map.updatedAt = new Date().toISOString();
    await kv.set(`map:${mapId}`, map);
    
    await addActivity(user.id, 'deleted_marker', marker.title, {
      mapId,
      markerId,
      mapTitle: map.title,
      category: marker.category
    });
    
    return c.json({ 
      message: 'Marker deleted successfully!' 
    });
  } catch (error) {
    console.log('Delete marker error:', error);
    return c.json({ error: `Delete marker error: ${error.message}` }, 500);
  });
    }
    
    const markerIndex = map.markers?.findIndex(m => m.id === markerId);
    if (markerIndex === -1) {
      return c.json({ error: 'Marker not found' }, 404);
    }
    
    const marker = map.markers[markerIndex];
    
    // Check permissions
    if (marker.createdBy !== user.id && map.createdBy !== user.id) {
      return c.json({ error: 'Permission denied' }, 403);
    }
    
    // Remove marker
    map.markers.splice(markerIndex, 1);
    map.updatedAt = new Date().toISOString();
    await kv.set(`map:${mapId}`, map);
    
    await addActivity(user.id, 'deleted_marker', marker.title, {
      mapId,
      markerId,
      mapTitle: map.title,
      category: marker.category
    });
    
    return c.json({ 
      message: 'Marker deleted successfully!'
    });
  } catch (error) {
    console.log('Delete marker error:', error);
    return c.json({ error: `Delete marker error: ${error.message}` }, 500);
  }
});

// Leaderboard Routes
app.get('/make-server-52837870/leaderboard', async (c) => {
  try {
    const query = c.req.query();
    const timeframe = query.timeframe || 'all'; // all, week, month
    const category = query.category || 'xp'; // xp, maps, places, distance
    const limit = Math.min(parseInt(query.limit || '50'), 100);
    
    const users = await kv.getByPrefix('user:');
    
    // Filter users based on timeframe
    let filteredUsers = users;
    if (timeframe !== 'all') {
      const now = new Date();
      const cutoffDate = new Date();
      
      if (timeframe === 'week') {
        cutoffDate.setDate(now.getDate() - 7);
      } else if (timeframe === 'month') {
        cutoffDate.setMonth(now.getMonth() - 1);
      }
      
      // For now, we'll show all users but in a real implementation
      // you'd track time-based stats
      filteredUsers = users.filter(user => 
        new Date(user.createdAt) >= cutoffDate || 
        new Date(user.updatedAt || user.createdAt) >= cutoffDate
      );
    }
    
    // Sort by different categories
    filteredUsers.sort((a, b) => {
      switch (category) {
        case 'maps':
          return (b.mapsContributed || 0) - (a.mapsContributed || 0);
        case 'places':
          return (b.placesExplored || 0) - (a.placesExplored || 0);
        case 'distance':
          return (b.totalDistance || 0) - (a.totalDistance || 0);
        case 'xp':
        default:
          return (b.xp || 0) - (a.xp || 0);
      }
    });
    
    const leaderboard = filteredUsers
      .slice(0, limit)
      .map((user, index) => ({
        rank: index + 1,
        id: user.id,
        username: user.name,
        level: user.level || 1,
        xp: user.xp || 0,
        placesExplored: user.placesExplored || 0,
        mapsContributed: user.mapsContributed || 0,
        totalDistance: user.totalDistance || 0,
        achievements: user.achievements?.length || 0,
        joinDate: user.createdAt,
        lastActive: user.updatedAt || user.createdAt
      }));

    // Get current user's rank if authenticated
    const currentUser = await getUser(c.req.raw);
    let userRank = null;
    
    if (currentUser) {
      const userIndex = filteredUsers.findIndex(u => u.id === currentUser.id);
      if (userIndex !== -1) {
        userRank = {
          rank: userIndex + 1,
          user: leaderboard.find(u => u.id === currentUser.id)
        };
      }
    }

    return c.json({
      leaderboard,
      userRank,
      filters: {
        timeframe,
        category,
        limit
      },
      stats: {
        totalUsers: users.length,
        totalXP: users.reduce((sum, u) => sum + (u.xp || 0), 0),
        totalMaps: users.reduce((sum, u) => sum + (u.mapsContributed || 0), 0),
        totalPlaces: users.reduce((sum, u) => sum + (u.placesExplored || 0), 0)
      }
    });
  } catch (error) {
    console.log('Get leaderboard error:', error);
    return c.json({ error: `Get leaderboard error: ${error.message}` }, 500);
  }
});

// Activity Feed Routes
app.get('/make-server-52837870/activity/:userId', async (c) => {
  try {
    const userId = c.req.param('userId');
    const query = c.req.query();
    const limit = Math.min(parseInt(query.limit || '20'), 50);
    
    const activities = await kv.get(`activities:${userId}`) || [];
    
    // Enhance activities with additional context
    const enhancedActivities = await Promise.all(
      activities.slice(0, limit).map(async (activity) => {
        const enhanced = { ...activity };
        
        // Add user info if not current user's activity
        if (activity.userId && activity.userId !== userId) {
          const user = await kv.get(`user:${activity.userId}`);
          enhanced.user = user ? {
            id: user.id,
            name: user.name,
            level: user.level
          } : null;
        }
        
        return enhanced;
      })
    );
    
    return c.json({
      activities: enhancedActivities,
      total: activities.length,
      hasMore: activities.length > limit
    });
  } catch (error) {
    console.log('Get activity error:', error);
    return c.json({ error: `Get activity error: ${error.message}` }, 500);
  }
});

// Global activity feed
app.get('/make-server-52837870/activity', async (c) => {
  try {
    const query = c.req.query();
    const limit = Math.min(parseInt(query.limit || '20'), 50);
    const filter = query.filter; // all, maps, markers, social
    
    const activities = await kv.get('global_activities') || [];
    
    // Filter activities by type
    let filteredActivities = activities;
    if (filter && filter !== 'all') {
      const filterMap = {
        maps: ['created_map', 'updated_map', 'deleted_map'],
        markers: ['added_marker', 'updated_marker', 'deleted_marker'],
        social: ['liked_map', 'joined', 'updated_profile']
      };
      
      if (filterMap[filter]) {
        filteredActivities = activities.filter(activity => 
          filterMap[filter].includes(activity.action)
        );
      }
    }
    
    // Enhance with user info
    const enhancedActivities = await Promise.all(
      filteredActivities.slice(0, limit).map(async (activity) => {
        const user = await kv.get(`user:${activity.userId}`);
        return {
          ...activity,
          user: user ? {
            id: user.id,
            name: user.name,
            level: user.level
          } : null
        };
      })
    );
    
    return c.json({
      activities: enhancedActivities,
      total: filteredActivities.length,
      hasMore: filteredActivities.length > limit,
      filter
    });
  } catch (error) {
    console.log('Get global activity error:', error);
    return c.json({ error: `Get global activity error: ${error.message}` }, 500);
  }
});

// Search functionality
app.get('/make-server-52837870/search', async (c) => {
  try {
    const query = c.req.query();
    const searchTerm = query.q?.toLowerCase();
    const type = query.type || 'all'; // all, maps, users, markers
    const limit = Math.min(parseInt(query.limit || '20'), 50);
    
    if (!searchTerm || searchTerm.length < 2) {
      return c.json({ error: 'Search term must be at least 2 characters' }, 400);
    }
    
    const results = {
      maps: [],
      users: [],
      markers: [],
      total: 0
    };
    
    // Search maps
    if (type === 'all' || type === 'maps') {
      const maps = await kv.getByPrefix('map:');
      const publicMaps = maps.filter(map => 
        map.visibility === 'public' && (
          map.title.toLowerCase().includes(searchTerm) ||
          map.description?.toLowerCase().includes(searchTerm) ||
          map.tags?.some(tag => tag.toLowerCase().includes(searchTerm))
        )
      );
      
      results.maps = publicMaps.slice(0, limit).map(map => ({
        id: map.id,
        title: map.title,
        description: map.description,
        markerCount: map.markers?.length || 0,
        visibility: map.visibility,
        createdAt: map.createdAt
      }));
    }
    
    // Search users
    if (type === 'all' || type === 'users') {
      const users = await kv.getByPrefix('user:');
      const matchingUsers = users.filter(user => 
        user.name.toLowerCase().includes(searchTerm)
      );
      
      results.users = matchingUsers.slice(0, limit).map(user => ({
        id: user.id,
        name: user.name,
        level: user.level,
        xp: user.xp,
        mapsContributed: user.mapsContributed
      }));
    }
    
    results.total = results.maps.length + results.users.length;
    
    return c.json({
      results,
      searchTerm,
      type,
      hasMore: results.total >= limit
    });
  } catch (error) {
    console.log('Search error:', error);
    return c.json({ error: `Search error: ${error.message}` }, 500);
  }
});

// File upload route for user avatars and map images
app.post('/make-server-52837870/upload', async (c) => {
  try {
    const user = await getUser(c.req.raw);
    if (!user) {
      return c.json({ error: 'Unauthorized' }, 401);
    }
    
    const formData = await c.req.formData();
    const file = formData.get('file') as File;
    const type = formData.get('type') as string; // avatar, map_image
    
    if (!file) {
      return c.json({ error: 'No file provided' }, 400);
    }
    
    // Validate file type and size
    if (!file.type.startsWith('image/')) {
      return c.json({ error: 'Only image files are allowed' }, 400);
    }
    
    if (file.size > 5 * 1024 * 1024) { // 5MB limit
      return c.json({ error: 'File size too large (max 5MB)' }, 400);
    }
    
    // Generate unique filename
    const fileExt = file.name.split('.').pop();
    const fileName = `${user.id}/${type}/${crypto.randomUUID()}.${fileExt}`;
    
    // Upload to Supabase Storage
    const { data, error } = await supabase.storage
      .from(BUCKET_NAME)
      .upload(fileName, file, {
        cacheControl: '3600',
        upsert: false
      });
    
    if (error) {
      console.log('Upload error:', error);
      return c.json({ error: 'Failed to upload file' }, 500);
    }
    
    // Get signed URL for the uploaded file
    const { data: signedUrl } = await supabase.storage
      .from(BUCKET_NAME)
      .createSignedUrl(fileName, 60 * 60 * 24 * 365); // 1 year
    
    return c.json({
      fileName,
      path: data.path,
      url: signedUrl?.signedUrl,
      message: 'File uploaded successfully'
    });
  } catch (error) {
    console.log('Upload error:', error);
    return c.json({ error: `Upload error: ${error.message}` }, 500);
  }
});

Deno.serve(app.fetch);