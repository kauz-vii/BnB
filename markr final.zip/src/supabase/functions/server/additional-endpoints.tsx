// TravelMapX Additional Server Endpoints
// These endpoints complete the server implementation

// ============================================================================
// LEADERBOARD ROUTES
// ============================================================================

// Leaderboard Routes
app.get('/make-server-52837870/leaderboard', async (c) => {
  try {
    const query = c.req.query();
    const type = query.type || 'xp'; // xp, maps, places, distance
    const limit = Math.min(parseInt(query.limit || '50'), 100);
    
    // Get all user profiles
    const profiles = await kv.getByPrefix('user:');
    
    // Sort by requested metric
    profiles.sort((a, b) => {
      switch (type) {
        case 'maps':
          return (b.mapsContributed || 0) - (a.mapsContributed || 0);
        case 'places':
          return (b.placesExplored || 0) - (a.placesExplored || 0);
        case 'distance':
          return (b.totalDistance || 0) - (a.totalDistance || 0);
        case 'xp':
        default:
          return (b.xp || 0) - (a.xp || 0);
      }
    });
    
    // Create leaderboard entries with ranks
    const leaderboard = profiles.slice(0, limit).map((profile, index) => ({
      rank: index + 1,
      id: profile.id,
      username: profile.name,
      xp: profile.xp || 0,
      level: profile.level || 1,
      placesExplored: profile.placesExplored || 0,
      mapsContributed: profile.mapsContributed || 0,
      totalDistance: profile.totalDistance || 0,
      achievements: profile.achievements?.length || 0,
      badges: profile.badges?.length || 0,
      joinDate: profile.createdAt
    }));
    
    return c.json(leaderboard);
  } catch (error) {
    console.log('Leaderboard error:', error);
    return c.json({ error: `Leaderboard error: ${error.message}` }, 500);
  }
});

// ============================================================================
// USER LOCATION API (Mock GPS/Browser location)
// ============================================================================

app.get('/make-server-52837870/user-location', async (c) => {
  try {
    // In a real implementation, this would integrate with device GPS
    // For now, we'll return a mock location or use IP-based geolocation
    const user = await getUser(c.req.raw);
    
    // Mock locations for demo purposes
    const mockLocations = [
      { lat: 40.7128, lng: -74.0060, name: 'New York City, NY' },
      { lat: 34.0522, lng: -118.2437, name: 'Los Angeles, CA' },
      { lat: 41.8781, lng: -87.6298, name: 'Chicago, IL' },
      { lat: 37.7749, lng: -122.4194, name: 'San Francisco, CA' },
      { lat: 51.5074, lng: -0.1278, name: 'London, UK' },
      { lat: 48.8566, lng: 2.3522, name: 'Paris, France' },
      { lat: 35.6762, lng: 139.6503, name: 'Tokyo, Japan' },
      { lat: -33.8688, lng: 151.2093, name: 'Sydney, Australia' }
    ];
    
    // Select a random location for demo
    const location = mockLocations[Math.floor(Math.random() * mockLocations.length)];
    
    // Add some random variation
    const variation = 0.01; // ~1km radius
    const finalLocation = {
      lat: location.lat + (Math.random() - 0.5) * variation,
      lng: location.lng + (Math.random() - 0.5) * variation,
      accuracy: 10 + Math.random() * 20, // 10-30 meters
      timestamp: new Date().toISOString(),
      source: 'mock_gps',
      address: location.name
    };
    
    // Log user location activity if authenticated
    if (user) {
      await addActivity(user.id, 'location_accessed', location.name, {
        coordinates: finalLocation,
        source: 'user_location_api'
      });
    }
    
    return c.json(finalLocation);
  } catch (error) {
    console.log('User location error:', error);
    return c.json({ error: `Location error: ${error.message}` }, 500);
  }
});

// ============================================================================
// DIRECTIONS API (Mock routing service)
// ============================================================================

app.get('/make-server-52837870/directions', async (c) => {
  try {
    const query = c.req.query();
    const validationError = validateRequiredFields(query, ['origin_lat', 'origin_lng', 'destination_lat', 'destination_lng']);
    
    if (validationError) {
      return c.json({ error: validationError }, 400);
    }
    
    const originLat = parseFloat(query.origin_lat);
    const originLng = parseFloat(query.origin_lng);
    const destLat = parseFloat(query.destination_lat);
    const destLng = parseFloat(query.destination_lng);
    
    // Validate coordinates
    if (isNaN(originLat) || isNaN(originLng) || isNaN(destLat) || isNaN(destLng)) {
      return c.json({ error: 'Invalid coordinate values' }, 400);
    }
    
    // Calculate straight-line distance (Haversine formula)
    const R = 6371; // Earth's radius in kilometers
    const dLat = (destLat - originLat) * Math.PI / 180;
    const dLng = (destLng - originLng) * Math.PI / 180;
    const a = Math.sin(dLat/2) * Math.sin(dLat/2) +
              Math.cos(originLat * Math.PI / 180) * Math.cos(destLat * Math.PI / 180) *
              Math.sin(dLng/2) * Math.sin(dLng/2);
    const c_calc = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
    const distance = R * c_calc; // Distance in kilometers
    
    // Mock routing data
    const routeData = {
      distance: Math.round(distance * 1000), // Convert to meters
      duration: Math.round(distance * 1000 / 1.4 * 60), // ~1.4 m/s walking speed in seconds
      start: {
        lat: originLat,
        lng: originLng
      },
      end: {
        lat: destLat,
        lng: destLng
      },
      // Mock route steps
      steps: [
        {
          instruction: "Head towards your destination",
          distance: Math.round(distance * 1000 * 0.3),
          duration: Math.round(distance * 1000 / 1.4 * 60 * 0.3),
          coordinates: [
            [originLng, originLat],
            [originLng + (destLng - originLng) * 0.3, originLat + (destLat - originLat) * 0.3]
          ]
        },
        {
          instruction: "Continue straight",
          distance: Math.round(distance * 1000 * 0.4),
          duration: Math.round(distance * 1000 / 1.4 * 60 * 0.4),
          coordinates: [
            [originLng + (destLng - originLng) * 0.3, originLat + (destLat - originLat) * 0.3],
            [originLng + (destLng - originLng) * 0.7, originLat + (destLat - originLat) * 0.7]
          ]
        },
        {
          instruction: "Arrive at destination",
          distance: Math.round(distance * 1000 * 0.3),
          duration: Math.round(distance * 1000 / 1.4 * 60 * 0.3),
          coordinates: [
            [originLng + (destLng - originLng) * 0.7, originLat + (destLat - originLat) * 0.7],
            [destLng, destLat]
          ]
        }
      ],
      // Full route polyline (simplified)
      polyline: [
        [originLng, originLat],
        [originLng + (destLng - originLng) * 0.2, originLat + (destLat - originLat) * 0.2],
        [originLng + (destLng - originLng) * 0.5, originLat + (destLat - originLat) * 0.5],
        [originLng + (destLng - originLng) * 0.8, originLat + (destLat - originLat) * 0.8],
        [destLng, destLat]
      ],
      mode: query.mode || 'walking',
      created_at: new Date().toISOString()
    };
    
    // Log directions request if user is authenticated
    const user = await getUser(c.req.raw);
    if (user) {
      await addActivity(user.id, 'requested_directions', 'Route Planning', {
        distance: routeData.distance,
        duration: routeData.duration,
        mode: routeData.mode
      });
    }
    
    return c.json(routeData);
  } catch (error) {
    console.log('Directions error:', error);
    return c.json({ error: `Directions error: ${error.message}` }, 500);
  }
});

// ============================================================================
// ACTIVITY FEED ROUTES
// ============================================================================

app.get('/make-server-52837870/activity', async (c) => {
  try {
    const query = c.req.query();
    const limit = Math.min(parseInt(query.limit || '20'), 100);
    const userId = query.user_id;
    
    let activities = [];
    
    if (userId) {
      // Get specific user's activities
      activities = await kv.get(`activities:${userId}`) || [];
    } else {
      // Get global activity feed
      activities = await kv.get('global_activities') || [];
    }
    
    // Enhance activities with user info
    const enhancedActivities = await Promise.all(
      activities.slice(0, limit).map(async (activity) => {
        const userProfile = await kv.get(`user:${activity.userId}`);
        return {
          ...activity,
          user: userProfile ? {
            id: userProfile.id,
            name: userProfile.name,
            level: userProfile.level
          } : null
        };
      })
    );
    
    return c.json({
      activities: enhancedActivities,
      total: activities.length,
      limit
    });
  } catch (error) {
    console.log('Activity feed error:', error);
    return c.json({ error: `Activity feed error: ${error.message}` }, 500);
  }
});

// ============================================================================
// SEARCH API
// ============================================================================

app.get('/make-server-52837870/search', async (c) => {
  try {
    const query = c.req.query();
    const searchQuery = query.q?.toLowerCase();
    const type = query.type || 'all'; // all, maps, users, markers
    const limit = Math.min(parseInt(query.limit || '20'), 50);
    
    if (!searchQuery || searchQuery.length < 2) {
      return c.json({ error: 'Search query must be at least 2 characters' }, 400);
    }
    
    const results = {
      maps: [],
      users: [],
      markers: [],
      total: 0
    };
    
    // Search maps
    if (type === 'all' || type === 'maps') {
      const maps = await kv.getByPrefix('map:');
      const filteredMaps = maps.filter(map => 
        map.visibility === 'public' &&
        (map.title.toLowerCase().includes(searchQuery) ||
         map.description?.toLowerCase().includes(searchQuery) ||
         map.tags?.some(tag => tag.toLowerCase().includes(searchQuery)))
      ).slice(0, limit);
      
      // Enhance with creator info
      results.maps = await Promise.all(
        filteredMaps.map(async (map) => {
          const creator = await kv.get(`user:${map.createdBy}`);
          return {
            ...map,
            creator: creator ? {
              id: creator.id,
              name: creator.name,
              level: creator.level
            } : null,
            markerCount: map.markers?.length || 0,
            type: 'map'
          };
        })
      );
    }
    
    // Search users
    if (type === 'all' || type === 'users') {
      const users = await kv.getByPrefix('user:');
      results.users = users.filter(user => 
        user.preferences?.privacy !== 'private' &&
        user.name.toLowerCase().includes(searchQuery)
      ).slice(0, limit).map(user => ({
        id: user.id,
        name: user.name,
        level: user.level,
        xp: user.xp,
        mapsContributed: user.mapsContributed,
        placesExplored: user.placesExplored,
        type: 'user'
      }));
    }
    
    // Search markers within public maps
    if (type === 'all' || type === 'markers') {
      const maps = await kv.getByPrefix('map:');
      const publicMaps = maps.filter(map => map.visibility === 'public');
      
      const allMarkers = [];
      for (const map of publicMaps) {
        if (map.markers) {
          map.markers.forEach(marker => {
            if (marker.title.toLowerCase().includes(searchQuery) ||
                marker.notes?.toLowerCase().includes(searchQuery) ||
                marker.tags?.some(tag => tag.toLowerCase().includes(searchQuery))) {
              allMarkers.push({
                ...marker,
                mapId: map.id,
                mapTitle: map.title,
                type: 'marker'
              });
            }
          });
        }
      }
      results.markers = allMarkers.slice(0, limit);
    }
    
    results.total = results.maps.length + results.users.length + results.markers.length;
    
    return c.json(results);
  } catch (error) {
    console.log('Search error:', error);
    return c.json({ error: `Search error: ${error.message}` }, 500);
  }
});

// ============================================================================
// FILE UPLOAD ROUTE
// ============================================================================

app.post('/make-server-52837870/upload', async (c) => {
  try {
    const user = await getUser(c.req.raw);
    if (!user) {
      return c.json({ error: 'Unauthorized' }, 401);
    }
    
    const formData = await c.req.formData();
    const file = formData.get('file') as File;
    const type = formData.get('type') as string;
    
    if (!file) {
      return c.json({ error: 'No file provided' }, 400);
    }
    
    if (!['avatar', 'map_image'].includes(type)) {
      return c.json({ error: 'Invalid file type' }, 400);
    }
    
    // Validate file size (5MB max)
    if (file.size > 5 * 1024 * 1024) {
      return c.json({ error: 'File size too large (max 5MB)' }, 400);
    }
    
    // Validate file type
    if (!file.type.startsWith('image/')) {
      return c.json({ error: 'Only image files are allowed' }, 400);
    }
    
    // Generate unique filename
    const timestamp = Date.now();
    const extension = file.name.split('.').pop() || 'jpg';
    const filename = `${type}/${user.id}/${timestamp}.${extension}`;
    
    // Upload to Supabase Storage
    const { data, error } = await supabase.storage
      .from(BUCKET_NAME)
      .upload(filename, file, {
        contentType: file.type,
        upsert: false
      });
    
    if (error) {
      console.log('Upload error:', error);
      return c.json({ error: 'Upload failed' }, 500);
    }
    
    // Get public URL
    const { data: { publicUrl } } = supabase.storage
      .from(BUCKET_NAME)
      .getPublicUrl(filename);
    
    // Update user profile if avatar
    if (type === 'avatar') {
      const profile = await kv.get(`user:${user.id}`);
      if (profile) {
        profile.avatar_url = publicUrl;
        profile.updatedAt = new Date().toISOString();
        await kv.set(`user:${user.id}`, profile);
      }
    }
    
    await addActivity(user.id, 'uploaded_file', `${type} upload`, {
      filename,
      fileSize: file.size,
      fileType: file.type
    });
    
    return c.json({
      url: publicUrl,
      filename,
      message: 'File uploaded successfully!'
    });
  } catch (error) {
    console.log('Upload error:', error);
    return c.json({ error: `Upload error: ${error.message}` }, 500);
  }
});

// ============================================================================
// HEALTH CHECK ENDPOINT
// ============================================================================

app.get('/make-server-52837870/health', async (c) => {
  return c.json({
    status: 'healthy',
    timestamp: new Date().toISOString(),
    service: 'TravelMapX API Server',
    version: '1.0.0'
  });
});

// ============================================================================
// ERROR HANDLERS
// ============================================================================

// 404 handler
app.notFound((c) => {
  return c.json({ error: 'Endpoint not found' }, 404);
});

// Error handler
app.onError((err, c) => {
  console.error('Server error:', err);
  return c.json({ 
    error: 'Internal server error',
    message: err.message 
  }, 500);
});

// Export the app
export default app;