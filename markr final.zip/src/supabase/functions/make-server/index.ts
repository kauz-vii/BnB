import { Hono } from 'npm:hono';
import { cors } from 'npm:hono/cors';
import { logger } from 'npm:hono/logger';
import { createClient } from 'npm:@supabase/supabase-js@2';

const app = new Hono();

// CORS and logging middleware
app.use('*', cors({
  origin: '*',
  allowMethods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
  allowHeaders: ['Content-Type', 'Authorization'],
}));
app.use('*', logger(console.log));

const supabase = createClient(
  Deno.env.get('SUPABASE_URL')!,
  Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!,
);

// Storage bucket setup for user-generated content
const BUCKET_NAME = 'make-52837870-travel-assets';

// Simple KV store implementation using Supabase database
const kv = {
  async get(key: string) {
    try {
      const { data } = await supabase
        .from('kv_store')
        .select('value')
        .eq('key', key)
        .single();
      return data?.value ? JSON.parse(data.value) : null;
    } catch {
      return null;
    }
  },

  async set(key: string, value: any) {
    const serialized = JSON.stringify(value);
    const { error } = await supabase
      .from('kv_store')
      .upsert({ key, value: serialized });
    if (error) throw error;
    return true;
  },

  async getByPrefix(prefix: string) {
    try {
      const { data } = await supabase
        .from('kv_store')
        .select('value')
        .like('key', `${prefix}%`);
      return data?.map(item => JSON.parse(item.value)) || [];
    } catch {
      return [];
    }
  }
};

// Helper function to get user from access token
async function getUser(request: Request) {
  const accessToken = request.headers.get('Authorization')?.split(' ')[1];
  if (!accessToken) return null;
  
  const { data: { user }, error } = await supabase.auth.getUser(accessToken);
  if (error || !user) return null;
  
  return user;
}

// Helper function to validate request data
function validateRequiredFields(data: any, fields: string[]): string | null {
  for (const field of fields) {
    if (!data[field] || (typeof data[field] === 'string' && data[field].trim() === '')) {
      return `Missing required field: ${field}`;
    }
  }
  return null;
}

// Helper function to calculate user level from XP
function calculateLevel(xp: number): number {
  return Math.floor(xp / 100) + 1;
}

// Helper function to add activity
async function addActivity(userId: string, action: string, location: string, metadata?: any) {
  try {
    const activitiesKey = `activities:${userId}`;
    const activities = await kv.get(activitiesKey) || [];
    
    const activity = {
      id: crypto.randomUUID(),
      action,
      location,
      metadata: metadata || {},
      timestamp: new Date().toISOString(),
      userId
    };
    
    activities.unshift(activity);
    
    if (activities.length > 100) {
      activities.splice(100);
    }
    
    await kv.set(activitiesKey, activities);
    
    const globalKey = 'global_activities';
    const globalActivities = await kv.get(globalKey) || [];
    globalActivities.unshift(activity);
    
    if (globalActivities.length > 500) {
      globalActivities.splice(500);
    }
    
    await kv.set(globalKey, globalActivities);
    
    return activity;
  } catch (error) {
    console.log('Error adding activity:', error);
    return null;
  }
}

// Health Check
app.get('/health', async (c) => {
  return c.json({
    status: 'healthy',
    timestamp: new Date().toISOString(),
    service: 'TravelMapX API Server',
    version: '1.0.0'
  });
});

// Authentication Routes
app.post('/auth/signup', async (c) => {
  try {
    const requestData = await c.req.json();
    const validationError = validateRequiredFields(requestData, ['email', 'password', 'name']);
    
    if (validationError) {
      return c.json({ error: validationError }, 400);
    }
    
    const { email, password, name } = requestData;
    
    if (password.length < 6) {
      return c.json({ error: 'Password must be at least 6 characters long' }, 400);
    }
    
    const { data, error } = await supabase.auth.admin.createUser({
      email,
      password,
      user_metadata: { name },
      email_confirm: true
    });

    if (error) {
      console.log('Signup error:', error);
      return c.json({ error: `Signup error: ${error.message}` }, 400);
    }

    const userId = data.user.id;
    const initialProfile = {
      id: userId,
      name: name.trim(),
      email,
      level: 1,
      xp: 0,
      totalDistance: 0,
      placesExplored: 0,
      mapsContributed: 0,
      achievements: [],
      badges: [],
      preferences: {
        theme: 'light',
        notifications: true,
        privacy: 'public'
      },
      stats: {
        loginStreak: 1,
        lastLogin: new Date().toISOString(),
        totalSessions: 1
      },
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };
    
    await kv.set(`user:${userId}`, initialProfile);
    await addActivity(userId, 'joined', 'TravelMapX Community', {
      welcomeMessage: 'Welcome to TravelMapX!'
    });

    return c.json({ 
      user: data.user,
      profile: initialProfile,
      message: 'Account created successfully! Welcome to TravelMapX!' 
    });
  } catch (error) {
    console.log('Signup error:', error);
    return c.json({ error: `Signup error: ${error.message || 'Unknown error'}` }, 500);
  }
});

app.post('/auth/oauth-profile', async (c) => {
  try {
    const user = await getUser(c.req.raw);
    if (!user) {
      return c.json({ error: 'Unauthorized' }, 401);
    }
    
    const existingProfile = await kv.get(`user:${user.id}`);
    if (existingProfile) {
      return c.json({ profile: existingProfile });
    }
    
    const name = user.user_metadata?.name || user.user_metadata?.full_name || 'Travel Explorer';
    const profile = {
      id: user.id,
      name,
      email: user.email,
      level: 1,
      xp: 0,
      totalDistance: 0,
      placesExplored: 0,
      mapsContributed: 0,
      achievements: [],
      badges: [],
      preferences: {
        theme: 'light',
        notifications: true,
        privacy: 'public'
      },
      stats: {
        loginStreak: 1,
        lastLogin: new Date().toISOString(),
        totalSessions: 1
      },
      authProvider: user.app_metadata?.provider || 'email',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };
    
    await kv.set(`user:${user.id}`, profile);
    await addActivity(user.id, 'joined', 'TravelMapX Community', {
      provider: user.app_metadata?.provider,
      welcomeMessage: 'Welcome to TravelMapX!'
    });
    
    return c.json({ profile });
  } catch (error) {
    console.log('OAuth profile creation error:', error);
    return c.json({ error: 'Failed to create OAuth profile' }, 500);
  }
});

// User Profile Routes
app.get('/profile', async (c) => {
  try {
    const user = await getUser(c.req.raw);
    if (!user) {
      return c.json({ error: 'Unauthorized' }, 401);
    }

    const profile = await kv.get(`user:${user.id}`);
    if (!profile) {
      return c.json({ error: 'Profile not found' }, 404);
    }

    return c.json(profile);
  } catch (error) {
    console.log('Get profile error:', error);
    return c.json({ error: `Get profile error: ${error.message}` }, 500);
  }
});

app.put('/profile', async (c) => {
  try {
    const user = await getUser(c.req.raw);
    if (!user) {
      return c.json({ error: 'Unauthorized' }, 401);
    }

    const updates = await c.req.json();
    const currentProfile = await kv.get(`user:${user.id}`);
    
    if (!currentProfile) {
      return c.json({ error: 'Profile not found' }, 404);
    }

    const allowedFields = ['name', 'preferences', 'privacy'];
    const sanitizedUpdates = {};
    
    for (const [key, value] of Object.entries(updates)) {
      if (allowedFields.includes(key)) {
        sanitizedUpdates[key] = value;
      }
    }
    
    if (currentProfile.xp !== undefined) {
      currentProfile.level = calculateLevel(currentProfile.xp);
    }
    
    const updatedProfile = { 
      ...currentProfile, 
      ...sanitizedUpdates,
      updatedAt: new Date().toISOString()
    };
    
    await kv.set(`user:${user.id}`, updatedProfile);

    return c.json(updatedProfile);
  } catch (error) {
    console.log('Update profile error:', error);
    return c.json({ error: `Update profile error: ${error.message}` }, 500);
  }
});

// Leaderboard Routes
app.get('/leaderboard', async (c) => {
  try {
    const query = c.req.query();
    const type = query.type || 'xp';
    const limit = Math.min(parseInt(query.limit || '50'), 100);
    
    const profiles = await kv.getByPrefix('user:');
    
    profiles.sort((a, b) => {
      switch (type) {
        case 'maps':
          return (b.mapsContributed || 0) - (a.mapsContributed || 0);
        case 'places':
          return (b.placesExplored || 0) - (a.placesExplored || 0);
        case 'distance':
          return (b.totalDistance || 0) - (a.totalDistance || 0);
        case 'xp':
        default:
          return (b.xp || 0) - (a.xp || 0);
      }
    });
    
    const leaderboard = profiles.slice(0, limit).map((profile, index) => ({
      rank: index + 1,
      id: profile.id,
      username: profile.name,
      xp: profile.xp || 0,
      level: profile.level || 1,
      placesExplored: profile.placesExplored || 0,
      mapsContributed: profile.mapsContributed || 0,
      totalDistance: profile.totalDistance || 0,
      achievements: profile.achievements?.length || 0,
      badges: profile.badges?.length || 0,
      joinDate: profile.createdAt
    }));
    
    return c.json(leaderboard);
  } catch (error) {
    console.log('Leaderboard error:', error);
    return c.json({ error: `Leaderboard error: ${error.message}` }, 500);
  }
});

// Maps Routes
app.post('/maps', async (c) => {
  try {
    const user = await getUser(c.req.raw);
    if (!user) {
      return c.json({ error: 'Unauthorized' }, 401);
    }

    const requestData = await c.req.json();
    const validationError = validateRequiredFields(requestData, ['title', 'visibility']);
    
    if (validationError) {
      return c.json({ error: validationError }, 400);
    }
    
    const { title, description, visibility, tags, centerCoords } = requestData;
    
    if (!['public', 'private', 'unlisted'].includes(visibility)) {
      return c.json({ error: 'Invalid visibility option' }, 400);
    }
    
    const mapId = crypto.randomUUID();
    
    const map = {
      id: mapId,
      title: title.trim(),
      description: description?.trim() || '',
      visibility,
      tags: tags || [],
      centerCoords: centerCoords || { lat: 0, lng: 0 },
      createdBy: user.id,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      markers: [],
      stats: {
        views: 0,
        likes: 0,
        forks: 0
      },
      settings: {
        allowComments: true,
        allowForks: visibility === 'public',
        showCreator: true
      }
    };

    await kv.set(`map:${mapId}`, map);
    
    const userMapsKey = `user_maps:${user.id}`;
    const userMaps = await kv.get(userMapsKey) || [];
    userMaps.unshift(mapId);
    await kv.set(userMapsKey, userMaps);

    const profile = await kv.get(`user:${user.id}`);
    if (profile) {
      profile.mapsContributed += 1;
      profile.xp += 50;
      profile.level = calculateLevel(profile.xp);
      profile.updatedAt = new Date().toISOString();
      await kv.set(`user:${user.id}`, profile);
    }
    
    await addActivity(user.id, 'created_map', title, {
      mapId,
      visibility,
      xpGained: 50
    });

    return c.json({ 
      map,
      message: 'Map created successfully!',
      xpGained: 50
    });
  } catch (error) {
    console.log('Create map error:', error);
    return c.json({ error: `Create map error: ${error.message}` }, 500);
  }
});

app.get('/maps', async (c) => {
  try {
    const user = await getUser(c.req.raw);
    const query = c.req.query();
    
    const page = parseInt(query.page || '1');
    const limit = Math.min(parseInt(query.limit || '20'), 50);
    const search = query.search?.toLowerCase();
    const sortBy = query.sortBy || 'created';
    
    let maps = await kv.getByPrefix('map:');
    
    maps = maps.filter(map => {
      if (map.visibility === 'public') return true;
      if (map.visibility === 'unlisted') return true;
      if (user && map.createdBy === user.id) return true;
      return false;
    });
    
    if (search) {
      maps = maps.filter(map => 
        map.title.toLowerCase().includes(search) ||
        map.description?.toLowerCase().includes(search)
      );
    }
    
    maps.sort((a, b) => {
      switch (sortBy) {
        case 'updated':
          return new Date(b.updatedAt || b.createdAt).getTime() - new Date(a.updatedAt || a.createdAt).getTime();
        case 'popular':
          return (b.stats?.views || 0) + (b.stats?.likes || 0) - ((a.stats?.views || 0) + (a.stats?.likes || 0));
        case 'created':
        default:
          return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
      }
    });
    
    const startIndex = (page - 1) * limit;
    const endIndex = startIndex + limit;
    const paginatedMaps = maps.slice(startIndex, endIndex);
    
    const enhancedMaps = await Promise.all(
      paginatedMaps.map(async (map) => {
        const creator = await kv.get(`user:${map.createdBy}`);
        return {
          ...map,
          creator: creator ? {
            id: creator.id,
            name: creator.name,
            level: creator.level
          } : null,
          markerCount: map.markers?.length || 0
        };
      })
    );
    
    return c.json({
      maps: enhancedMaps,
      pagination: {
        page,
        limit,
        total: maps.length,
        totalPages: Math.ceil(maps.length / limit),
        hasNext: endIndex < maps.length,
        hasPrev: page > 1
      }
    });
  } catch (error) {
    console.log('Get maps error:', error);
    return c.json({ error: `Get maps error: ${error.message}` }, 500);
  }
});

// Location & Directions Routes
app.get('/user-location', async (c) => {
  try {
    const user = await getUser(c.req.raw);
    
    const mockLocations = [
      { lat: 40.7128, lng: -74.0060, name: 'New York City, NY' },
      { lat: 34.0522, lng: -118.2437, name: 'Los Angeles, CA' },
      { lat: 41.8781, lng: -87.6298, name: 'Chicago, IL' },
      { lat: 37.7749, lng: -122.4194, name: 'San Francisco, CA' },
      { lat: 51.5074, lng: -0.1278, name: 'London, UK' },
      { lat: 48.8566, lng: 2.3522, name: 'Paris, France' }
    ];
    
    const location = mockLocations[Math.floor(Math.random() * mockLocations.length)];
    
    const variation = 0.01;
    const finalLocation = {
      lat: location.lat + (Math.random() - 0.5) * variation,
      lng: location.lng + (Math.random() - 0.5) * variation,
      accuracy: 10 + Math.random() * 20,
      timestamp: new Date().toISOString(),
      source: 'mock_gps',
      address: location.name
    };
    
    if (user) {
      await addActivity(user.id, 'location_accessed', location.name, {
        coordinates: finalLocation,
        source: 'user_location_api'
      });
    }
    
    return c.json(finalLocation);
  } catch (error) {
    console.log('User location error:', error);
    return c.json({ error: `Location error: ${error.message}` }, 500);
  }
});

app.get('/directions', async (c) => {
  try {
    const query = c.req.query();
    const validationError = validateRequiredFields(query, ['origin_lat', 'origin_lng', 'destination_lat', 'destination_lng']);
    
    if (validationError) {
      return c.json({ error: validationError }, 400);
    }
    
    const originLat = parseFloat(query.origin_lat);
    const originLng = parseFloat(query.origin_lng);
    const destLat = parseFloat(query.destination_lat);
    const destLng = parseFloat(query.destination_lng);
    
    if (isNaN(originLat) || isNaN(originLng) || isNaN(destLat) || isNaN(destLng)) {
      return c.json({ error: 'Invalid coordinate values' }, 400);
    }
    
    // Calculate distance using Haversine formula
    const R = 6371;
    const dLat = (destLat - originLat) * Math.PI / 180;
    const dLng = (destLng - originLng) * Math.PI / 180;
    const a = Math.sin(dLat/2) * Math.sin(dLat/2) +
              Math.cos(originLat * Math.PI / 180) * Math.cos(destLat * Math.PI / 180) *
              Math.sin(dLng/2) * Math.sin(dLng/2);
    const c_calc = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
    const distance = R * c_calc;
    
    const routeData = {
      distance: Math.round(distance * 1000),
      duration: Math.round(distance * 1000 / 1.4 * 60),
      start: { lat: originLat, lng: originLng },
      end: { lat: destLat, lng: destLng },
      steps: [
        {
          instruction: "Head towards your destination",
          distance: Math.round(distance * 1000 * 0.3),
          duration: Math.round(distance * 1000 / 1.4 * 60 * 0.3),
          coordinates: [
            [originLng, originLat],
            [originLng + (destLng - originLng) * 0.3, originLat + (destLat - originLat) * 0.3]
          ]
        },
        {
          instruction: "Continue straight",
          distance: Math.round(distance * 1000 * 0.4),
          duration: Math.round(distance * 1000 / 1.4 * 60 * 0.4),
          coordinates: [
            [originLng + (destLng - originLng) * 0.3, originLat + (destLat - originLat) * 0.3],
            [originLng + (destLng - originLng) * 0.7, originLat + (destLat - originLat) * 0.7]
          ]
        },
        {
          instruction: "Arrive at destination",
          distance: Math.round(distance * 1000 * 0.3),
          duration: Math.round(distance * 1000 / 1.4 * 60 * 0.3),
          coordinates: [
            [originLng + (destLng - originLng) * 0.7, originLat + (destLat - originLat) * 0.7],
            [destLng, destLat]
          ]
        }
      ],
      polyline: [
        [originLng, originLat],
        [originLng + (destLng - originLng) * 0.2, originLat + (destLat - originLat) * 0.2],
        [originLng + (destLng - originLng) * 0.5, originLat + (destLat - originLat) * 0.5],
        [originLng + (destLng - originLng) * 0.8, originLat + (destLat - originLat) * 0.8],
        [destLng, destLat]
      ],
      mode: query.mode || 'walking',
      created_at: new Date().toISOString()
    };
    
    const user = await getUser(c.req.raw);
    if (user) {
      await addActivity(user.id, 'requested_directions', 'Route Planning', {
        distance: routeData.distance,
        duration: routeData.duration,
        mode: routeData.mode
      });
    }
    
    return c.json(routeData);
  } catch (error) {
    console.log('Directions error:', error);
    return c.json({ error: `Directions error: ${error.message}` }, 500);
  }
});

// Activity & Search Routes
app.get('/activity', async (c) => {
  try {
    const query = c.req.query();
    const limit = Math.min(parseInt(query.limit || '20'), 100);
    const userId = query.user_id;
    
    let activities = [];
    
    if (userId) {
      activities = await kv.get(`activities:${userId}`) || [];
    } else {
      activities = await kv.get('global_activities') || [];
    }
    
    const enhancedActivities = await Promise.all(
      activities.slice(0, limit).map(async (activity) => {
        const userProfile = await kv.get(`user:${activity.userId}`);
        return {
          ...activity,
          user: userProfile ? {
            id: userProfile.id,
            name: userProfile.name,
            level: userProfile.level
          } : null
        };
      })
    );
    
    return c.json({
      activities: enhancedActivities,
      total: activities.length,
      limit
    });
  } catch (error) {
    console.log('Activity feed error:', error);
    return c.json({ error: `Activity feed error: ${error.message}` }, 500);
  }
});

app.get('/search', async (c) => {
  try {
    const query = c.req.query();
    const searchQuery = query.q?.toLowerCase();
    const type = query.type || 'all';
    const limit = Math.min(parseInt(query.limit || '20'), 50);
    
    if (!searchQuery || searchQuery.length < 2) {
      return c.json({ error: 'Search query must be at least 2 characters' }, 400);
    }
    
    const results = {
      maps: [],
      users: [],
      markers: [],
      total: 0
    };
    
    // Search maps
    if (type === 'all' || type === 'maps') {
      const maps = await kv.getByPrefix('map:');
      const filteredMaps = maps.filter(map => 
        map.visibility === 'public' &&
        (map.title.toLowerCase().includes(searchQuery) ||
         map.description?.toLowerCase().includes(searchQuery))
      ).slice(0, limit);
      
      results.maps = await Promise.all(
        filteredMaps.map(async (map) => {
          const creator = await kv.get(`user:${map.createdBy}`);
          return {
            ...map,
            creator: creator ? {
              id: creator.id,
              name: creator.name,
              level: creator.level
            } : null,
            markerCount: map.markers?.length || 0,
            type: 'map'
          };
        })
      );
    }
    
    // Search users
    if (type === 'all' || type === 'users') {
      const users = await kv.getByPrefix('user:');
      results.users = users.filter(user => 
        user.preferences?.privacy !== 'private' &&
        user.name.toLowerCase().includes(searchQuery)
      ).slice(0, limit).map(user => ({
        id: user.id,
        name: user.name,
        level: user.level,
        xp: user.xp,
        mapsContributed: user.mapsContributed,
        placesExplored: user.placesExplored,
        type: 'user'
      }));
    }
    
    results.total = results.maps.length + results.users.length + results.markers.length;
    
    return c.json(results);
  } catch (error) {
    console.log('Search error:', error);
    return c.json({ error: `Search error: ${error.message}` }, 500);
  }
});

// Error handlers
app.notFound((c) => {
  return c.json({ error: 'Endpoint not found' }, 404);
});

app.onError((err, c) => {
  console.error('Server error:', err);
  return c.json({ 
    error: 'Internal server error',
    message: err.message 
  }, 500);
});

// Export the app for Supabase Edge Functions
Deno.serve(app.fetch);