# TravelMapX Backend Deployment Guide

## Prerequisites

1. **Supabase CLI installed**: 
   ```bash
   npm install -g supabase
   ```

2. **Project connected**:
   ```bash
   supabase login
   supabase link --project-ref [YOUR_PROJECT_ID]
   ```

## Database Setup

1. **Run the migration to create the KV store table**:
   ```bash
   supabase db reset
   ```
   This will create the `kv_store` table needed for the backend.

## Environment Variables

Make sure these are set in your Supabase project:

- `SUPABASE_URL` - Your project URL (auto-set)
- `SUPABASE_SERVICE_ROLE_KEY` - Your service role key (auto-set)

## Deploy the Edge Function

1. **Deploy the function**:
   ```bash
   supabase functions deploy make-server-52837870
   ```

2. **Verify deployment**:
   Visit: `https://[YOUR_PROJECT_ID].supabase.co/functions/v1/make-server-52837870/health`

## Testing

1. **Health Check**: 
   ```bash
   curl https://[YOUR_PROJECT_ID].supabase.co/functions/v1/make-server-52837870/health
   ```

2. **Get Location**:
   ```bash
   curl https://[YOUR_PROJECT_ID].supabase.co/functions/v1/make-server-52837870/user-location
   ```

3. **Get Leaderboard**:
   ```bash
   curl https://[YOUR_PROJECT_ID].supabase.co/functions/v1/make-server-52837870/leaderboard
   ```

## Troubleshooting

### 403 Error
- Check if your Supabase project has Edge Functions enabled
- Verify you have the correct permissions
- Make sure you're linked to the right project

### 500 Error
- Check the function logs: `supabase functions logs make-server-52837870`
- Verify database migrations ran successfully
- Check environment variables are set

### Function Not Found
- Ensure the function name matches exactly: `make-server-52837870`
- Verify deployment was successful
- Check function exists in Supabase dashboard

## API Endpoints

Once deployed, these endpoints will be available:

- `GET /health` - Health check
- `POST /auth/signup` - User registration
- `GET /profile` - User profile (requires auth)
- `GET /leaderboard` - Leaderboard rankings
- `GET /maps` - List maps
- `POST /maps` - Create map (requires auth)
- `GET /user-location` - Mock GPS location
- `GET /directions` - Route planning
- `GET /search` - Search functionality
- `GET /activity` - Activity feed

All endpoints are prefixed with your function URL:
`https://[YOUR_PROJECT_ID].supabase.co/functions/v1/make-server-52837870`