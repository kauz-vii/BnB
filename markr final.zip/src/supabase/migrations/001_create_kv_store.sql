-- Create KV store table for TravelMapX backend data
CREATE TABLE IF NOT EXISTS kv_store (
  key TEXT PRIMARY KEY,
  value JSONB NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create index for key-based lookups
CREATE INDEX IF NOT EXISTS idx_kv_store_key ON kv_store(key);

-- Create index for prefix-based searches
CREATE INDEX IF NOT EXISTS idx_kv_store_key_prefix ON kv_store(key text_pattern_ops);

-- Enable RLS (Row Level Security)
ALTER TABLE kv_store ENABLE ROW LEVEL SECURITY;

-- Create policy to allow service role full access
CREATE POLICY "Service role can manage all KV data" ON kv_store
FOR ALL USING (auth.role() = 'service_role');

-- Create policy to allow authenticated users to read their own data
CREATE POLICY "Users can read their own data" ON kv_store
FOR SELECT USING (
  key LIKE 'user:' || auth.uid()::text ||
  '%' OR key LIKE 'activities:' || auth.uid()::text ||
  '%' OR key LIKE 'user_maps:' || auth.uid()::text ||
  '%' OR key LIKE 'user_map_interaction:' || auth.uid()::text || '%'
);

-- Update timestamp trigger
CREATE OR REPLACE FUNCTION update_kv_store_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER update_kv_store_updated_at
  BEFORE UPDATE ON kv_store
  FOR EACH ROW
  EXECUTE FUNCTION update_kv_store_updated_at();