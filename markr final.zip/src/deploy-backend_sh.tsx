#!/bin/bash

echo "🗺️  TravelMapX Backend Deployment"
echo "================================="

# Check if Supabase CLI is installed
if ! command -v supabase &> /dev/null; then
    echo "❌ Supabase CLI not found. Install it with:"
    echo "npm install -g supabase"
    exit 1
fi

echo "✅ Supabase CLI found"

# Check if logged in and linked
if ! supabase status > /dev/null 2>&1; then
    echo "❌ Not connected to Supabase project. Run:"
    echo "supabase login"
    echo "supabase link --project-ref YOUR_PROJECT_ID"
    exit 1
fi

echo "✅ Connected to Supabase project"

# Clean up old functions (remove conflicting ones)
echo "🧹 Cleaning up old functions..."
rm -rf supabase/functions/make-server
rm -rf supabase/functions/make-server-52837870 
rm -rf supabase/functions/server

echo "✅ Cleaned up old function files"

# Deploy the new function
echo "🚀 Deploying travel-api function..."
if supabase functions deploy travel-api; then
    echo "✅ Function deployed successfully!"
else
    echo "❌ Function deployment failed"
    exit 1
fi

# Set up database migration
echo "📊 Setting up database..."
if supabase db reset --linked; then
    echo "✅ Database setup complete"
else
    echo "⚠️  Database setup failed (this might be okay if tables already exist)"
fi

# Get project info for testing
PROJECT_REF=$(supabase status | grep "API URL" | cut -d'/' -f3 | cut -d'.' -f1)

if [ -z "$PROJECT_REF" ]; then
    echo "❌ Could not determine project reference"
    exit 1
fi

echo "📍 Project ID: $PROJECT_REF"

# Test the deployment
echo "🧪 Testing deployment..."
HEALTH_URL="https://$PROJECT_REF.supabase.co/functions/v1/travel-api/health"

echo "Testing: $HEALTH_URL"
if curl -s -f "$HEALTH_URL" > /dev/null; then
    echo "✅ Health check passed!"
else
    echo "⚠️  Health check failed (function might still be starting up)"
fi

echo ""
echo "🎉 Deployment Complete!"
echo "======================"
echo ""
echo "Your TravelMapX backend is now live at:"
echo "https://$PROJECT_REF.supabase.co/functions/v1/travel-api"
echo ""
echo "📋 Available Endpoints:"
echo "• GET  /health - Health check"
echo "• POST /auth/signup - User registration"
echo "• GET  /profile - User profile"
echo "• GET  /leaderboard - Rankings"
echo "• GET  /maps - List maps"
echo "• POST /maps - Create map"
echo "• GET  /user-location - Location service"
echo "• GET  /directions - Route planning"
echo "• GET  /search - Search functionality"
echo "• GET  /activity - Activity feed"
echo ""
echo "🧪 Test your backend:"
echo "1. Open your TravelMapX app"
echo "2. Click 'Backend Test' in the sidebar"
echo "3. Run connectivity tests"
echo ""
echo "🔍 Monitor logs:"
echo "supabase functions logs travel-api --follow"