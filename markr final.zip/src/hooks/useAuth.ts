import { useState, useEffect } from 'react';
import { supabase, apiCall, signInWithOAuth } from '../utils/supabase/client';
import type { User } from '@supabase/supabase-js';

interface UserProfile {
  id: string;
  name: string;
  email: string;
  level: number;
  xp: number;
  totalDistance: number;
  placesExplored: number;
  mapsContributed: number;
  achievements: string[];
  badges: string[];
  preferences: {
    theme: 'light' | 'dark';
    notifications: boolean;
    privacy: 'public' | 'private';
  };
  stats: {
    loginStreak: number;
    lastLogin: string;
    totalSessions: number;
  };
  authProvider?: string;
  createdAt: string;
  updatedAt: string;
}

export function useAuth() {
  const [user, setUser] = useState<User | null>(null);
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Get initial session
    supabase.auth.getSession().then(({ data: { session } }) => {
      setUser(session?.user ?? null);
      if (session?.user) {
        fetchProfile();
      } else {
        setLoading(false);
      }
    });

    // Listen for auth changes
    const { data: { subscription } } = supabase.auth.onAuthStateChange(async (event, session) => {
      setUser(session?.user ?? null);
      
      if (session?.user) {
        // Handle OAuth users who might not have a profile yet
        if (event === 'SIGNED_IN' && session.user.app_metadata?.provider !== 'email') {
          try {
            // Try to create/get OAuth profile
            await apiCall('/auth/oauth-profile', { method: 'POST' });
          } catch (error) {
            console.error('Error creating OAuth profile:', error);
          }
        }
        
        fetchProfile();
      } else {
        setProfile(null);
        setLoading(false);
      }
    });

    return () => subscription.unsubscribe();
  }, []);

  const fetchProfile = async () => {
    try {
      const profileData = await apiCall('/profile');
      setProfile(profileData);
    } catch (error) {
      console.error('Error fetching profile:', error);
    } finally {
      setLoading(false);
    }
  };

  const signUp = async (email: string, password: string, name: string) => {
    try {
      const response = await apiCall('/auth/signup', {
        method: 'POST',
        body: JSON.stringify({ email, password, name }),
      });

      // Sign in the user after successful signup
      const { data, error } = await supabase.auth.signInWithPassword({
        email,
        password,
      });

      if (error) throw error;
      return { data, error: null };
    } catch (error: any) {
      return { data: null, error };
    }
  };

  const signIn = async (email: string, password: string) => {
    try {
      const { data, error } = await supabase.auth.signInWithPassword({
        email,
        password,
      });

      if (error) throw error;
      return { data, error: null };
    } catch (error: any) {
      return { data: null, error };
    }
  };

  const signOut = async () => {
    const { error } = await supabase.auth.signOut();
    return { error };
  };

  const signInWithProvider = async (provider: 'google' | 'github' | 'discord') => {
    try {
      const { data, error } = await signInWithOAuth(provider);
      if (error) throw error;
      return { data, error: null };
    } catch (error: any) {
      return { data: null, error };
    }
  };

  const updateProfile = async (updates: Partial<UserProfile>) => {
    try {
      const updatedProfile = await apiCall('/profile', {
        method: 'PUT',
        body: JSON.stringify(updates),
      });
      setProfile(updatedProfile);
      return { data: updatedProfile, error: null };
    } catch (error: any) {
      return { data: null, error };
    }
  };

  const getUserStats = async () => {
    try {
      const stats = await apiCall('/profile/stats');
      return { data: stats, error: null };
    } catch (error: any) {
      return { data: null, error };
    }
  };

  return {
    user,
    profile,
    loading,
    signUp,
    signIn,
    signInWithProvider,
    signOut,
    updateProfile,
    getUserStats,
    refreshProfile: fetchProfile,
  };
}