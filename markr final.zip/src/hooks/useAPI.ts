import { useState, useCallback } from 'react';
import { travelMapAPI } from '../api/backend-endpoints';

export function useAPICall<T = any>() {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [data, setData] = useState<T | null>(null);

  const execute = useCallback(async (apiCall: () => Promise<T>) => {
    try {
      setLoading(true);
      setError(null);
      const result = await apiCall();
      setData(result);
      return result;
    } catch (err: any) {
      const errorMessage = err.message || 'An error occurred';
      setError(errorMessage);
      throw err;
    } finally {
      setLoading(false);
    }
  }, []);

  const reset = useCallback(() => {
    setData(null);
    setError(null);
    setLoading(false);
  }, []);

  return {
    loading,
    error,
    data,
    execute,
    reset,
  };
}

// Maps API hooks
export function useMapsAPI() {
  const { loading, error, data, execute, reset } = useAPICall();

  const createMap = useCallback((mapData: any) => 
    execute(() => travelMapAPI.maps.create(mapData)), [execute]);

  const getMaps = useCallback((params?: any) => 
    execute(() => travelMapAPI.maps.getAll(params)), [execute]);

  const getMap = useCallback((id: string) => 
    execute(() => travelMapAPI.maps.getById(id)), [execute]);

  const updateMap = useCallback((id: string, updates: any) => 
    execute(() => travelMapAPI.maps.update(id, updates)), [execute]);

  const deleteMap = useCallback((id: string) => 
    execute(() => travelMapAPI.maps.delete(id)), [execute]);

  const likeMap = useCallback((id: string) => 
    execute(() => travelMapAPI.maps.like(id)), [execute]);

  return {
    loading,
    error,
    data,
    reset,
    createMap,
    getMaps,
    getMap,
    updateMap,
    deleteMap,
    likeMap,
  };
}

// Markers API hooks
export function useMarkersAPI() {
  const { loading, error, data, execute, reset } = useAPICall();

  const createMarker = useCallback((mapId: string, markerData: any) => 
    execute(() => travelMapAPI.markers.create(mapId, markerData)), [execute]);

  const updateMarker = useCallback((mapId: string, markerId: string, updates: any) => 
    execute(() => travelMapAPI.markers.update(mapId, markerId, updates)), [execute]);

  const deleteMarker = useCallback((mapId: string, markerId: string) => 
    execute(() => travelMapAPI.markers.delete(mapId, markerId)), [execute]);

  return {
    loading,
    error,
    data,
    reset,
    createMarker,
    updateMarker,
    deleteMarker,
  };
}

// Leaderboard API hooks
export function useLeaderboardAPI() {
  const { loading, error, data, execute, reset } = useAPICall();

  const getLeaderboard = useCallback((params?: any) => 
    execute(() => travelMapAPI.leaderboard.get(params)), [execute]);

  return {
    loading,
    error,
    data: data as any[] | null,
    reset,
    getLeaderboard,
  };
}

// Location API hooks
export function useLocationAPI() {
  const { loading, error, data, execute, reset } = useAPICall();

  const getUserLocation = useCallback(() => 
    execute(() => travelMapAPI.location.getUserLocation()), [execute]);

  return {
    loading,
    error,
    data,
    reset,
    getUserLocation,
  };
}

// Directions API hooks
export function useDirectionsAPI() {
  const { loading, error, data, execute, reset } = useAPICall();

  const getDirections = useCallback((params: any) => 
    execute(() => travelMapAPI.directions.getRoute(params)), [execute]);

  return {
    loading,
    error,
    data,
    reset,
    getDirections,
  };
}

// Activity API hooks
export function useActivityAPI() {
  const { loading, error, data, execute, reset } = useAPICall();

  const getActivity = useCallback((params?: any) => 
    execute(() => travelMapAPI.activity.get(params)), [execute]);

  return {
    loading,
    error,
    data,
    reset,
    getActivity,
  };
}

// Search API hooks
export function useSearchAPI() {
  const { loading, error, data, execute, reset } = useAPICall();

  const search = useCallback((params: any) => 
    execute(() => travelMapAPI.search.search(params)), [execute]);

  return {
    loading,
    error,
    data,
    reset,
    search,
  };
}

// Upload API hooks
export function useUploadAPI() {
  const { loading, error, data, execute, reset } = useAPICall();

  const uploadFile = useCallback((file: File, type: 'avatar' | 'map_image') => 
    execute(() => travelMapAPI.upload.uploadFile(file, type)), [execute]);

  return {
    loading,
    error,
    data,
    reset,
    uploadFile,
  };
}