import { useState, useEffect } from 'react';
import { travelMapAPI, LeaderboardEntry } from '../api/backend-endpoints';

export function useLeaderboard(type?: 'xp' | 'maps' | 'places' | 'distance', limit?: number) {
  const [leaderboard, setLeaderboard] = useState<LeaderboardEntry[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchLeaderboard = async () => {
    try {
      setLoading(true);
      const data = await travelMapAPI.leaderboard.get({ type, limit });
      setLeaderboard(data);
      setError(null);
    } catch (err: any) {
      setError(err.message);
      console.error('Error fetching leaderboard:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchLeaderboard();
  }, [type, limit]);

  return {
    leaderboard,
    loading,
    error,
    refresh: fetchLeaderboard,
  };
}