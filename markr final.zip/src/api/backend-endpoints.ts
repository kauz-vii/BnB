// TravelMapX Backend API Integration
// This file provides helper functions for all backend endpoints

import { apiCall } from '../utils/supabase/client';

// ============================================================================
// AUTHENTICATION ENDPOINTS
// ============================================================================

export interface SignUpData {
  email: string;
  password: string;
  name: string;
}

export interface SignInData {
  email: string;
  password: string;
}

export const authAPI = {
  signUp: (data: SignUpData) => 
    apiCall('/auth/signup', {
      method: 'POST',
      body: JSON.stringify(data),
    }),

  initiateOAuth: (provider: 'google' | 'github' | 'discord') =>
    apiCall('/auth/oauth', {
      method: 'POST',
      body: JSON.stringify({ provider }),
    }),

  createOAuthProfile: () =>
    apiCall('/auth/oauth-profile', {
      method: 'POST',
    }),
};

// ============================================================================
// USER PROFILE ENDPOINTS
// ============================================================================

export interface UserProfile {
  id: string;
  name: string;
  email: string;
  level: number;
  xp: number;
  totalDistance: number;
  placesExplored: number;
  mapsContributed: number;
  achievements: string[];
  badges: string[];
  preferences: {
    theme: 'light' | 'dark';
    notifications: boolean;
    privacy: 'public' | 'private';
  };
  stats: {
    loginStreak: number;
    lastLogin: string;
    totalSessions: number;
  };
  authProvider?: string;
  avatar_url?: string;
  createdAt: string;
  updatedAt: string;
}

export const profileAPI = {
  get: (): Promise<UserProfile> => 
    apiCall('/profile'),

  update: (updates: Partial<UserProfile>) =>
    apiCall('/profile', {
      method: 'PUT',
      body: JSON.stringify(updates),
    }),

  getStats: () =>
    apiCall('/profile/stats'),
};

// ============================================================================
// MAPS ENDPOINTS
// ============================================================================

export interface MapData {
  id?: string;
  title: string;
  description?: string;
  visibility: 'public' | 'private' | 'unlisted';
  tags?: string[];
  centerCoords?: { lat: number; lng: number };
  createdBy?: string;
  createdAt?: string;
  updatedAt?: string;
  markers?: MarkerData[];
  stats?: {
    views: number;
    likes: number;
    forks: number;
  };
  settings?: {
    allowComments: boolean;
    allowForks: boolean;
    showCreator: boolean;
  };
}

export interface MapQueryParams {
  page?: number;
  limit?: number;
  search?: string;
  tag?: string;
  sortBy?: 'created' | 'updated' | 'popular';
}

export const mapsAPI = {
  create: (data: MapData) =>
    apiCall('/maps', {
      method: 'POST',
      body: JSON.stringify(data),
    }),

  getAll: (params: MapQueryParams = {}) => {
    const searchParams = new URLSearchParams();
    Object.entries(params).forEach(([key, value]) => {
      if (value !== undefined) {
        searchParams.append(key, value.toString());
      }
    });
    
    const queryString = searchParams.toString();
    return apiCall(`/maps${queryString ? `?${queryString}` : ''}`);
  },

  getById: (id: string) =>
    apiCall(`/maps/${id}`),

  update: (id: string, updates: Partial<MapData>) =>
    apiCall(`/maps/${id}`, {
      method: 'PUT',
      body: JSON.stringify(updates),
    }),

  delete: (id: string) =>
    apiCall(`/maps/${id}`, {
      method: 'DELETE',
    }),

  like: (id: string) =>
    apiCall(`/maps/${id}/like`, {
      method: 'POST',
    }),
};

// ============================================================================
// MARKERS ENDPOINTS
// ============================================================================

export interface MarkerData {
  id?: string;
  category: 'food' | 'toilets' | 'attractions' | 'notes' | 'transport' | 'accommodation' | 'shopping';
  title: string;
  notes?: string;
  lat: number;
  lng: number;
  address?: string;
  tags?: string[];
  createdBy?: string;
  createdAt?: string;
  updatedAt?: string;
  interactions?: {
    visits: number;
    likes: number;
    comments: any[];
  };
}

export const markersAPI = {
  create: (mapId: string, data: MarkerData) =>
    apiCall(`/maps/${mapId}/markers`, {
      method: 'POST',
      body: JSON.stringify(data),
    }),

  update: (mapId: string, markerId: string, updates: Partial<MarkerData>) =>
    apiCall(`/maps/${mapId}/markers/${markerId}`, {
      method: 'PUT',
      body: JSON.stringify(updates),
    }),

  delete: (mapId: string, markerId: string) =>
    apiCall(`/maps/${mapId}/markers/${markerId}`, {
      method: 'DELETE',
    }),
};

// ============================================================================
// LEADERBOARD ENDPOINTS
// ============================================================================

export interface LeaderboardEntry {
  rank: number;
  id: string;
  username: string;
  xp: number;
  level: number;
  placesExplored: number;
  mapsContributed: number;
  totalDistance: number;
  achievements: number;
  badges: number;
  joinDate: string;
}

export interface LeaderboardParams {
  type?: 'xp' | 'maps' | 'places' | 'distance';
  limit?: number;
}

export const leaderboardAPI = {
  get: (params: LeaderboardParams = {}): Promise<LeaderboardEntry[]> => {
    const searchParams = new URLSearchParams();
    Object.entries(params).forEach(([key, value]) => {
      if (value !== undefined) {
        searchParams.append(key, value.toString());
      }
    });
    
    const queryString = searchParams.toString();
    return apiCall(`/leaderboard${queryString ? `?${queryString}` : ''}`);
  },
};

// ============================================================================
// LOCATION ENDPOINTS
// ============================================================================

export interface LocationData {
  lat: number;
  lng: number;
  accuracy: number;
  timestamp: string;
  source: string;
  address?: string;
}

export const locationAPI = {
  getUserLocation: (): Promise<LocationData> =>
    apiCall('/user-location'),
};

// ============================================================================
// DIRECTIONS ENDPOINTS
// ============================================================================

export interface DirectionsParams {
  origin_lat: number;
  origin_lng: number;
  destination_lat: number;
  destination_lng: number;
  mode?: 'walking' | 'driving' | 'cycling';
}

export interface RouteStep {
  instruction: string;
  distance: number;
  duration: number;
  coordinates: [number, number][];
}

export interface DirectionsData {
  distance: number;
  duration: number;
  start: { lat: number; lng: number };
  end: { lat: number; lng: number };
  steps: RouteStep[];
  polyline: [number, number][];
  mode: string;
  created_at: string;
}

export const directionsAPI = {
  getRoute: (params: DirectionsParams): Promise<DirectionsData> => {
    const searchParams = new URLSearchParams();
    Object.entries(params).forEach(([key, value]) => {
      searchParams.append(key, value.toString());
    });
    
    return apiCall(`/directions?${searchParams.toString()}`);
  },
};

// ============================================================================
// ACTIVITY FEED ENDPOINTS
// ============================================================================

export interface Activity {
  id: string;
  action: string;
  location: string;
  metadata: any;
  timestamp: string;
  userId: string;
  user?: {
    id: string;
    name: string;
    level: number;
  };
}

export interface ActivityParams {
  limit?: number;
  user_id?: string;
}

export const activityAPI = {
  get: (params: ActivityParams = {}): Promise<{
    activities: Activity[];
    total: number;
    limit: number;
  }> => {
    const searchParams = new URLSearchParams();
    Object.entries(params).forEach(([key, value]) => {
      if (value !== undefined) {
        searchParams.append(key, value.toString());
      }
    });
    
    const queryString = searchParams.toString();
    return apiCall(`/activity${queryString ? `?${queryString}` : ''}`);
  },
};

// ============================================================================
// SEARCH ENDPOINTS
// ============================================================================

export interface SearchParams {
  q: string;
  type?: 'all' | 'maps' | 'users' | 'markers';
  limit?: number;
}

export interface SearchResults {
  maps: any[];
  users: any[];
  markers: any[];
  total: number;
}

export const searchAPI = {
  search: (params: SearchParams): Promise<SearchResults> => {
    const searchParams = new URLSearchParams();
    Object.entries(params).forEach(([key, value]) => {
      if (value !== undefined) {
        searchParams.append(key, value.toString());
      }
    });
    
    return apiCall(`/search?${searchParams.toString()}`);
  },
};

// ============================================================================
// FILE UPLOAD ENDPOINTS
// ============================================================================

export const uploadAPI = {
  uploadFile: (file: File, type: 'avatar' | 'map_image') => {
    const formData = new FormData();
    formData.append('file', file);
    formData.append('type', type);
    
    return apiCall('/upload', {
      method: 'POST',
      body: formData,
      headers: {}, // Remove Content-Type header to let browser set it for FormData
    });
  },
};

// ============================================================================
// HEALTH CHECK
// ============================================================================

export const healthAPI = {
  check: () => apiCall('/health'),
};

// ============================================================================
// COMBINED API EXPORT
// ============================================================================

export const travelMapAPI = {
  auth: authAPI,
  profile: profileAPI,
  maps: mapsAPI,
  markers: markersAPI,
  leaderboard: leaderboardAPI,
  location: locationAPI,
  directions: directionsAPI,
  activity: activityAPI,
  search: searchAPI,
  upload: uploadAPI,
  health: healthAPI,
};

export default travelMapAPI;