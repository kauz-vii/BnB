import { useState, useEffect } from 'react';
import { Navbar } from './components/Navbar';
import { CleanSidebar } from './components/CleanSidebar';
import { EnhancedMapView } from './components/EnhancedMapView';
import { HowToUse } from './components/HowToUse';
import { Profile } from './components/TravelProfile';
import { Leaderboard } from './components/TravelLeaderboard';
import { PublicMaps } from './components/PublicMaps';
import { NearbyPlaces } from './components/NearbyPlaces';
import { TrendingMaps } from './components/TrendingMaps';
import { MyContributions } from './components/MyContributions';
import { SavedMaps } from './components/SavedMaps';
import { BackendTest } from './components/BackendTest';
import { BackendIntegration } from './components/BackendIntegration';
import { GoogleMapsSetup } from './components/GoogleMapsSetup';
import { ReliefPoints } from './components/ReliefPoints';
import { CreateMapModal } from './components/CreateMapModal';
import { AddMarkerModal } from './components/AddMarkerModal';
import { AuthModal } from './components/AuthModal';
import { GuestBanner } from './components/GuestBanner';
import { ThemeProvider } from './contexts/ThemeContext';
import { useAuth } from './hooks/useAuth';
import { Loader2 } from 'lucide-react';

type ViewType = 'explore' | 'profile' | 'leaderboard' | 'public-maps' | 'nearby-places' | 'trending-maps' | 'my-contributions' | 'saved-maps' | 'backend-test' | 'backend-integration' | 'google-maps-setup' | 'relief-points' | 'how-to-use';

function AppContent() {
  const { user, profile, loading } = useAuth();
  const [currentView, setCurrentView] = useState<ViewType>(() => {
    // Check URL parameters for setup mode
    const urlParams = new URLSearchParams(window.location.search);
    if (urlParams.get('setup') === 'maps') {
      return 'google-maps-setup';
    }
    return 'explore';
  });
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState(true);
  const [isCreateMapModalOpen, setIsCreateMapModalOpen] = useState(false);
  const [isAddMarkerModalOpen, setIsAddMarkerModalOpen] = useState(false);
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);
  const [showGuestBanner, setShowGuestBanner] = useState(true);
  const [isHowToUseOpen, setIsHowToUseOpen] = useState(false);
  const [isFirstTimeUser, setIsFirstTimeUser] = useState(false);
  const [isMobile, setIsMobile] = useState(window.innerWidth < 768);

  // Handle responsive sidebar
  useEffect(() => {
    const handleResize = () => {
      const mobile = window.innerWidth < 768;
      setIsMobile(mobile);
      if (!mobile) {
        setIsSidebarCollapsed(false);
      } else {
        setIsSidebarCollapsed(true);
      }
    };

    // Set initial state
    handleResize();
    
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  // Check for first-time user and show how-to-use
  useEffect(() => {
    if (user) {
      const hasSeenHowToUse = localStorage.getItem(`markr_how_to_use_${user.id}`);
      if (!hasSeenHowToUse) {
        setIsFirstTimeUser(true);
        setIsHowToUseOpen(true);
      }
    }
  }, [user]);

  if (loading) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-blue-600" />
      </div>
    );
  }

  // Show profile and user-specific views only for authenticated users
  const handleViewChange = (view: ViewType) => {
    if ((view === 'profile' || view === 'my-contributions' || view === 'saved-maps') && !user) {
      setIsAuthModalOpen(true);
      return;
    }
    if (view === 'how-to-use') {
      setIsHowToUseOpen(true);
      return;
    }
    setCurrentView(view);
  };

  const handleHowToUseClose = () => {
    setIsHowToUseOpen(false);
    if (user && isFirstTimeUser) {
      localStorage.setItem(`markr_how_to_use_${user.id}`, 'true');
      setIsFirstTimeUser(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-indigo-50 to-emerald-50 dark:from-gray-900 dark:via-gray-800 dark:to-gray-900">
      <Navbar 
        currentView={currentView}
        onViewChange={handleViewChange}
        user={user}
        profile={profile}
        onAuthClick={() => setIsAuthModalOpen(true)}
        onMobileMenuToggle={() => setIsSidebarCollapsed(!isSidebarCollapsed)}
      />
      
      {/* Guest Banner - shown only for non-authenticated users and not overlapping with sidebar on mobile */}
      {!user && showGuestBanner && (isSidebarCollapsed || !isMobile) && (
        <GuestBanner 
          onSignUp={() => setIsAuthModalOpen(true)}
          onDismiss={() => setShowGuestBanner(false)}
        />
      )}
      
      <div className="flex h-[calc(100vh-4rem)] relative">
        {/* Mobile Overlay */}
        {!isSidebarCollapsed && (
          <div 
            className="fixed inset-0 bg-black/50 z-30 md:hidden"
            onClick={() => setIsSidebarCollapsed(true)}
          />
        )}
        
        <CleanSidebar 
          isCollapsed={isSidebarCollapsed}
          onToggleCollapse={() => setIsSidebarCollapsed(!isSidebarCollapsed)}
          onCreateMap={() => user ? setIsCreateMapModalOpen(true) : setIsAuthModalOpen(true)}
          currentView={currentView}
          onViewChange={handleViewChange}
          user={user}
          profile={profile}
        />
        
        <main className="flex-1 overflow-hidden">
          {currentView === 'explore' && (
            <EnhancedMapView 
              onAddMarker={() => user ? setIsAddMarkerModalOpen(true) : setIsAuthModalOpen(true)}
              user={user}
            />
          )}
          {currentView === 'profile' && user && <Profile user={user} profile={profile} />}
          {currentView === 'leaderboard' && <Leaderboard />}
          {currentView === 'public-maps' && <PublicMaps user={user} />}
          {currentView === 'nearby-places' && <NearbyPlaces user={user} />}
          {currentView === 'trending-maps' && <TrendingMaps user={user} />}
          {currentView === 'my-contributions' && user && <MyContributions user={user} profile={profile} />}
          {currentView === 'saved-maps' && user && <SavedMaps user={user} profile={profile} />}
          {currentView === 'backend-test' && <BackendTest />}
          {currentView === 'backend-integration' && <BackendIntegration />}
          {currentView === 'google-maps-setup' && <GoogleMapsSetup />}
          {currentView === 'relief-points' && <ReliefPoints user={user} />}
        </main>
      </div>

      <CreateMapModal 
        isOpen={isCreateMapModalOpen}
        onOpenChange={setIsCreateMapModalOpen}
      />

      <AddMarkerModal
        isOpen={isAddMarkerModalOpen}
        onOpenChange={setIsAddMarkerModalOpen}
      />

      <AuthModal
        isOpen={isAuthModalOpen}
        onOpenChange={setIsAuthModalOpen}
      />

      <HowToUse
        isOpen={isHowToUseOpen}
        onClose={handleHowToUseClose}
        isFirstTime={isFirstTimeUser}
      />
    </div>
  );
}

export default function App() {
  return (
    <ThemeProvider>
      <AppContent />
    </ThemeProvider>
  );
}