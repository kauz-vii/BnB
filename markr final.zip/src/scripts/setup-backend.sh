#!/bin/bash

# TravelMapX Backend Setup Script
# This script sets up the complete backend infrastructure

echo "🗺️  TravelMapX Backend Setup"
echo "============================"

# Check if Supabase CLI is installed
if ! command -v supabase &> /dev/null; then
    echo "❌ Supabase CLI is not installed. Please install it first:"
    echo "npm install -g supabase"
    exit 1
fi

echo "✅ Supabase CLI found"

# Check if we're linked to a project
if ! supabase status > /dev/null 2>&1; then
    echo "❌ Not linked to a Supabase project. Please run:"
    echo "supabase login"
    echo "supabase link --project-ref YOUR_PROJECT_ID"
    exit 1
fi

echo "✅ Supabase project linked"

# Apply database migrations
echo "📊 Setting up database..."
if supabase db reset --linked; then
    echo "✅ Database migrations applied successfully"
else
    echo "❌ Failed to apply database migrations"
    exit 1
fi

# Deploy the Edge Function
echo "🚀 Deploying Edge Function..."
if supabase functions deploy make-server; then
    echo "✅ Edge Function deployed successfully"
else
    echo "❌ Failed to deploy Edge Function"
    exit 1
fi

# Get project reference for testing
PROJECT_REF=$(supabase status | grep "API URL" | cut -d'/' -f3 | cut -d'.' -f1)

if [ -z "$PROJECT_REF" ]; then
    echo "❌ Could not determine project reference"
    exit 1
fi

echo "📍 Project Reference: $PROJECT_REF"

# Test the deployment
echo "🧪 Testing deployment..."

# Test health endpoint
HEALTH_URL="https://$PROJECT_REF.supabase.co/functions/v1/make-server/health"
echo "Testing health endpoint: $HEALTH_URL"

if curl -s -f "$HEALTH_URL" > /dev/null; then
    echo "✅ Health check passed"
else
    echo "❌ Health check failed"
    echo "Function might still be starting up. Check logs with:"
    echo "supabase functions logs make-server"
fi

# Test user location endpoint
LOCATION_URL="https://$PROJECT_REF.supabase.co/functions/v1/make-server/user-location"
echo "Testing location endpoint: $LOCATION_URL"

if curl -s -f "$LOCATION_URL" > /dev/null; then
    echo "✅ Location endpoint working"
else
    echo "⚠️  Location endpoint test failed (this might be normal during initial startup)"
fi

# Test leaderboard endpoint
LEADERBOARD_URL="https://$PROJECT_REF.supabase.co/functions/v1/make-server/leaderboard"
echo "Testing leaderboard endpoint: $LEADERBOARD_URL"

if curl -s -f "$LEADERBOARD_URL" > /dev/null; then
    echo "✅ Leaderboard endpoint working"
else
    echo "⚠️  Leaderboard endpoint test failed (this might be normal during initial startup)"
fi

echo ""
echo "🎉 Backend Setup Complete!"
echo "=========================="
echo ""
echo "Your TravelMapX backend is now deployed and ready to use."
echo ""
echo "📋 Next Steps:"
echo "1. Update your app to use the deployed endpoints"
echo "2. Test the Backend Test component in your app"
echo "3. Start creating maps and exploring!"
echo ""
echo "🔗 API Base URL:"
echo "https://$PROJECT_REF.supabase.co/functions/v1/make-server"
echo ""
echo "📚 Available Endpoints:"
echo "• GET  /health - Health check"
echo "• POST /auth/signup - User registration"
echo "• GET  /profile - User profile"
echo "• GET  /leaderboard - Rankings"
echo "• GET  /maps - List maps"
echo "• POST /maps - Create map"
echo "• GET  /user-location - Mock GPS"
echo "• GET  /directions - Route planning"
echo "• GET  /search - Search content"
echo "• GET  /activity - Activity feed"
echo ""
echo "🔍 Monitor your function:"
echo "supabase functions logs make-server --follow"