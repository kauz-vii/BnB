import { useState, useEffect } from 'react';
import { TrendingUp, MapPin, Users, Star, Calendar, Search, Filter, Grid, List, Heart, Share, Eye, Flame, Award, Clock, Zap } from 'lucide-react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Badge } from './ui/badge';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import type { User } from '@supabase/supabase-js';

interface TrendingMap {
  id: string;
  title: string;
  description: string;
  creator: string;
  creatorId: string;
  creatorLevel: number;
  category: string;
  location: string;
  rating: number;
  reviewCount: number;
  markerCount: number;
  views: number;
  likes: number;
  shares: number;
  trendingScore: number;
  trendingRank: number;
  tags: string[];
  createdAt: string;
  lastUpdated: string;
  recentActivity: {
    dailyViews: number;
    dailyLikes: number;
    dailyShares: number;
    weeklyGrowth: number;
  };
  thumbnail?: string;
  distance?: number;
  isFeatured: boolean;
  isLiked: boolean;
  isSaved: boolean;
  hotness: 'fire' | 'hot' | 'trending' | 'rising';
}

interface TrendingMapsProps {
  user: User | null;
}

export function TrendingMaps({ user }: TrendingMapsProps) {
  const [trendingMaps, setTrendingMaps] = useState<TrendingMap[]>([]);
  const [filteredMaps, setFilteredMaps] = useState<TrendingMap[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('all');
  const [timeFilter, setTimeFilter] = useState('24h');
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const [activeTab, setActiveTab] = useState('all');
  const [loading, setLoading] = useState(true);

  // Mock data - will be replaced with Supabase queries
  const mockTrendingMaps: TrendingMap[] = [
    {
      id: '1',
      title: 'Winter Pop-up Markets NYC',
      description: 'Seasonal holiday markets and pop-up shops across Manhattan and Brooklyn',
      creator: 'HolidayHunter',
      creatorId: 'user1',
      creatorLevel: 16,
      category: 'Seasonal Events',
      location: 'New York City',
      rating: 4.9,
      reviewCount: 423,
      markerCount: 18,
      views: 25430,
      likes: 3245,
      shares: 567,
      trendingScore: 98,
      trendingRank: 1,
      tags: ['holiday', 'markets', 'seasonal', 'shopping', 'nyc'],
      createdAt: '2024-01-15T10:00:00Z',
      lastUpdated: '2024-01-20T16:30:00Z',
      recentActivity: {
        dailyViews: 2340,
        dailyLikes: 234,
        dailyShares: 45,
        weeklyGrowth: 156
      },
      distance: 1.2,
      isFeatured: true,
      isLiked: false,
      isSaved: false,
      hotness: 'fire'
    },
    {
      id: '2',
      title: 'Viral TikTok Food Spots',
      description: 'All the trending food spots from TikTok and Instagram that you need to try',
      creator: 'SocialFoodie',
      creatorId: 'user2',
      creatorLevel: 13,
      category: 'Food & Trending',
      location: 'Multiple Cities',
      rating: 4.7,
      reviewCount: 1834,
      markerCount: 42,
      views: 48230,
      likes: 5623,
      shares: 892,
      trendingScore: 95,
      trendingRank: 2,
      tags: ['tiktok', 'viral', 'food', 'instagram', 'trendy'],
      createdAt: '2024-01-12T14:20:00Z',
      lastUpdated: '2024-01-21T12:15:00Z',
      recentActivity: {
        dailyViews: 3420,
        dailyLikes: 345,
        dailyShares: 67,
        weeklyGrowth: 234
      },
      distance: 0.8,
      isFeatured: true,
      isLiked: true,
      isSaved: true,
      hotness: 'fire'
    },
    {
      id: '3',
      title: 'Cozy Study Cafes',
      description: 'Perfect spots for remote work and studying with great WiFi and atmosphere',
      creator: 'StudySpotFinder',
      creatorId: 'user3',
      creatorLevel: 11,
      category: 'Work & Study',
      location: 'Manhattan, NY',
      rating: 4.6,
      reviewCount: 678,
      markerCount: 25,
      views: 18340,
      likes: 2134,
      shares: 234,
      trendingScore: 87,
      trendingRank: 3,
      tags: ['study', 'wifi', 'coffee', 'quiet', 'remote work'],
      createdAt: '2024-01-10T09:30:00Z',
      lastUpdated: '2024-01-19T11:45:00Z',
      recentActivity: {
        dailyViews: 1560,
        dailyLikes: 187,
        dailyShares: 23,
        weeklyGrowth: 98
      },
      distance: 2.1,
      isFeatured: false,
      isLiked: false,
      isSaved: false,
      hotness: 'hot'
    },
    {
      id: '4',
      title: 'Brooklyn Street Art Evolution',
      description: 'New murals and street art pieces that have appeared in Brooklyn this month',
      creator: 'StreetArtTracker',
      creatorId: 'user4',
      creatorLevel: 18,
      category: 'Art & Culture',
      location: 'Brooklyn, NY',
      rating: 4.8,
      reviewCount: 345,
      markerCount: 31,
      views: 12450,
      likes: 1678,
      shares: 156,
      trendingScore: 82,
      trendingRank: 4,
      tags: ['street art', 'murals', 'brooklyn', 'new', 'culture'],
      createdAt: '2024-01-08T16:00:00Z',
      lastUpdated: '2024-01-20T10:20:00Z',
      recentActivity: {
        dailyViews: 890,
        dailyLikes: 145,
        dailyShares: 18,
        weeklyGrowth: 67
      },
      distance: 3.5,
      isFeatured: false,
      isLiked: false,
      isSaved: true,
      hotness: 'trending'
    },
    {
      id: '5',
      title: 'Late Night Ramen Quest',
      description: 'The best ramen spots open after midnight for those late night cravings',
      creator: 'NightEater',
      creatorId: 'user5',
      creatorLevel: 9,
      category: 'Food & Dining',
      location: 'NYC & Brooklyn',
      rating: 4.5,
      reviewCount: 234,
      markerCount: 16,
      views: 9230,
      likes: 987,
      shares: 89,
      trendingScore: 75,
      trendingRank: 5,
      tags: ['ramen', 'late night', 'noodles', 'authentic', 'comfort food'],
      createdAt: '2024-01-06T22:30:00Z',
      lastUpdated: '2024-01-18T20:15:00Z',
      recentActivity: {
        dailyViews: 567,
        dailyLikes: 89,
        dailyShares: 12,
        weeklyGrowth: 45
      },
      distance: 1.9,
      isFeatured: false,
      isLiked: true,
      isSaved: false,
      hotness: 'rising'
    }
  ];

  useEffect(() => {
    // Simulate API call
    setTimeout(() => {
      setTrendingMaps(mockTrendingMaps);
      setFilteredMaps(mockTrendingMaps);
      setLoading(false);
    }, 1000);
  }, []);

  useEffect(() => {
    let filtered = trendingMaps;

    // Tab filter
    switch (activeTab) {
      case 'fire':
        filtered = filtered.filter(map => map.hotness === 'fire');
        break;
      case 'rising':
        filtered = filtered.filter(map => map.hotness === 'rising');
        break;
      case 'new':
        const oneDayAgo = Date.now() - (24 * 60 * 60 * 1000);
        filtered = filtered.filter(map => new Date(map.createdAt).getTime() > oneDayAgo);
        break;
    }

    // Search filter
    if (searchQuery) {
      filtered = filtered.filter(map => 
        map.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        map.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
        map.creator.toLowerCase().includes(searchQuery.toLowerCase()) ||
        map.tags.some(tag => tag.toLowerCase().includes(searchQuery.toLowerCase()))
      );
    }

    // Category filter
    if (categoryFilter !== 'all') {
      filtered = filtered.filter(map => map.category === categoryFilter);
    }

    // Time filter for trending calculation
    switch (timeFilter) {
      case '1h':
        // Would filter by last hour activity
        break;
      case '24h':
        // Default - already sorted by trending score
        break;
      case '7d':
        // Sort by weekly growth
        filtered.sort((a, b) => b.recentActivity.weeklyGrowth - a.recentActivity.weeklyGrowth);
        break;
    }

    // Default sort by trending score
    if (timeFilter === '24h') {
      filtered.sort((a, b) => b.trendingScore - a.trendingScore);
    }

    setFilteredMaps(filtered);
  }, [trendingMaps, activeTab, searchQuery, categoryFilter, timeFilter]);

  const categories = [
    'all', 'Food & Trending', 'Seasonal Events', 'Work & Study', 
    'Art & Culture', 'Food & Dining', 'Entertainment', 'Shopping'
  ];

  const handleLikeMap = (mapId: string) => {
    setTrendingMaps(maps => 
      maps.map(map => 
        map.id === mapId 
          ? { ...map, isLiked: !map.isLiked, likes: map.isLiked ? map.likes - 1 : map.likes + 1 }
          : map
      )
    );
  };

  const handleSaveMap = (mapId: string) => {
    setTrendingMaps(maps => 
      maps.map(map => 
        map.id === mapId 
          ? { ...map, isSaved: !map.isSaved }
          : map
      )
    );
  };

  const getHotnessIcon = (hotness: string) => {
    switch (hotness) {
      case 'fire':
        return <Flame className="w-4 h-4 text-red-500" />;
      case 'hot':
        return <TrendingUp className="w-4 h-4 text-orange-500" />;
      case 'trending':
        return <Zap className="w-4 h-4 text-yellow-500" />;
      case 'rising':
        return <TrendingUp className="w-4 h-4 text-green-500" />;
      default:
        return <MapPin className="w-4 h-4" />;
    }
  };

  const getHotnessBadge = (hotness: string) => {
    switch (hotness) {
      case 'fire':
        return 'bg-red-100 text-red-700 border-red-200';
      case 'hot':
        return 'bg-orange-100 text-orange-700 border-orange-200';
      case 'trending':
        return 'bg-yellow-100 text-yellow-700 border-yellow-200';
      case 'rising':
        return 'bg-green-100 text-green-700 border-green-200';
      default:
        return 'bg-gray-100 text-gray-700 border-gray-200';
    }
  };

  const getCreatorBadge = (level: number) => {
    if (level >= 15) return { text: 'Expert', color: 'bg-purple-100 text-purple-700 border-purple-200' };
    if (level >= 10) return { text: 'Advanced', color: 'bg-blue-100 text-blue-700 border-blue-200' };
    if (level >= 5) return { text: 'Explorer', color: 'bg-emerald-100 text-emerald-700 border-emerald-200' };
    return { text: 'New', color: 'bg-gray-100 text-gray-700 border-gray-200' };
  };

  return (
    <div className="h-full bg-gradient-to-br from-blue-50 via-indigo-50 to-emerald-50 dark:from-gray-900 dark:via-gray-800 dark:to-gray-900 p-6 overflow-y-auto">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Header */}
        <div className="glassmorphism rounded-2xl shadow-xl p-6 border border-white/20 dark:border-gray-700/20">
          <div className="flex items-center justify-between mb-6">
            <div>
              <h1 className="text-3xl font-bold bg-gradient-to-r from-blue-600 to-emerald-500 bg-clip-text text-transparent flex items-center space-x-3">
                <TrendingUp className="w-8 h-8 text-emerald-500" />
                <span>Trending Maps</span>
              </h1>
              <p className="text-slate-600 dark:text-gray-300 mt-2">Discover what's hot right now in the TravelMapX community</p>
            </div>
            <div className="flex items-center space-x-2">
              <Badge className="bg-gradient-to-r from-orange-500 to-red-500 text-white text-lg px-4 py-2 animate-pulse">
                <Flame className="w-4 h-4 mr-2" />
                Live Trending
              </Badge>
            </div>
          </div>

          {/* Tabs */}
          <Tabs value={activeTab} onValueChange={setActiveTab} className="mb-6">
            <TabsList className="grid w-full grid-cols-4 bg-slate-100 dark:bg-gray-700">
              <TabsTrigger value="all" className="flex items-center space-x-2">
                <TrendingUp className="w-4 h-4" />
                <span>All Trending</span>
              </TabsTrigger>
              <TabsTrigger value="fire" className="flex items-center space-x-2">
                <Flame className="w-4 h-4" />
                <span>On Fire</span>
              </TabsTrigger>
              <TabsTrigger value="rising" className="flex items-center space-x-2">
                <Zap className="w-4 h-4" />
                <span>Rising</span>
              </TabsTrigger>
              <TabsTrigger value="new" className="flex items-center space-x-2">
                <Clock className="w-4 h-4" />
                <span>New Today</span>
              </TabsTrigger>
            </TabsList>
          </Tabs>

          {/* Search and Filters */}
          <div className="flex flex-col md:flex-row gap-4 items-center">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400 w-5 h-5" />
              <Input
                placeholder="Search trending maps..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10 bg-white/70 border-white/30 focus:bg-white"
              />
            </div>
            
            <Select value={categoryFilter} onValueChange={setCategoryFilter}>
              <SelectTrigger className="w-full md:w-48 bg-white/70 border-white/30">
                <SelectValue placeholder="Category" />
              </SelectTrigger>
              <SelectContent>
                {categories.map(category => (
                  <SelectItem key={category} value={category}>
                    {category === 'all' ? 'All Categories' : category}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>

            <Select value={timeFilter} onValueChange={setTimeFilter}>
              <SelectTrigger className="w-full md:w-32 bg-white/70 border-white/30">
                <SelectValue placeholder="Time" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="1h">1 Hour</SelectItem>
                <SelectItem value="24h">24 Hours</SelectItem>
                <SelectItem value="7d">7 Days</SelectItem>
              </SelectContent>
            </Select>

            <div className="flex bg-white/70 rounded-lg border border-white/30">
              <Button
                variant={viewMode === 'grid' ? 'default' : 'ghost'}
                size="sm"
                onClick={() => setViewMode('grid')}
                className="rounded-r-none"
              >
                <Grid className="w-4 h-4" />
              </Button>
              <Button
                variant={viewMode === 'list' ? 'default' : 'ghost'}
                size="sm"
                onClick={() => setViewMode('list')}
                className="rounded-l-none"
              >
                <List className="w-4 h-4" />
              </Button>
            </div>
          </div>
        </div>

        {/* Trending Maps Grid/List */}
        <div className="glassmorphism rounded-2xl shadow-xl border border-white/20 dark:border-gray-700/20 p-6">
          {loading ? (
            <div className={`grid ${viewMode === 'grid' ? 'grid-cols-1 md:grid-cols-2 lg:grid-cols-3' : 'grid-cols-1'} gap-6`}>
              {[1, 2, 3, 4, 5, 6].map((i) => (
                <div key={i} className="animate-pulse">
                  <div className="h-64 bg-slate-200 rounded-xl"></div>
                </div>
              ))}
            </div>
          ) : (
            <>
              {filteredMaps.length > 0 ? (
                <div className={`grid ${viewMode === 'grid' ? 'grid-cols-1 md:grid-cols-2 lg:grid-cols-3' : 'grid-cols-1'} gap-6`}>
                  {filteredMaps.map((map, index) => (
                    <Card key={map.id} className={`hover-lift transition-all duration-200 hover:shadow-xl bg-white/60 backdrop-blur-sm border border-white/30 relative ${viewMode === 'list' ? 'flex flex-row' : ''}`}>
                      {/* Trending Rank Badge */}
                      <div className="absolute top-3 left-3 z-10">
                        <Badge className="bg-gradient-to-r from-blue-600 to-emerald-500 text-white font-bold">
                          #{map.trendingRank}
                        </Badge>
                      </div>

                      {/* Hotness Badge */}
                      <div className="absolute top-3 right-3 z-10">
                        <Badge className={`${getHotnessBadge(map.hotness)} flex items-center space-x-1`}>
                          {getHotnessIcon(map.hotness)}
                          <span className="capitalize">{map.hotness}</span>
                        </Badge>
                      </div>
                      
                      {viewMode === 'grid' ? (
                        <>
                          <CardHeader className="pb-3 pt-12">
                            <div className="flex items-start justify-between">
                              <div className="flex-1">
                                <CardTitle className="text-lg font-bold text-slate-800 line-clamp-1 pr-2">
                                  {map.title}
                                </CardTitle>
                                <div className="flex items-center space-x-2 mt-1">
                                  <p className="text-sm text-slate-600">by {map.creator}</p>
                                  <Badge className={`text-xs ${getCreatorBadge(map.creatorLevel).color}`}>
                                    {getCreatorBadge(map.creatorLevel).text}
                                  </Badge>
                                </div>
                              </div>
                            </div>
                          </CardHeader>
                          <CardContent className="pt-0">
                            <p className="text-sm text-slate-600 line-clamp-2 mb-4">
                              {map.description}
                            </p>
                            
                            <div className="space-y-3">
                              <div className="flex items-center justify-between text-sm">
                                <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-200">
                                  {map.category}
                                </Badge>
                                <div className="flex items-center space-x-1 text-yellow-600">
                                  <Star className="w-4 h-4 fill-current" />
                                  <span className="font-medium">{map.rating}</span>
                                  <span className="text-slate-500">({map.reviewCount})</span>
                                </div>
                              </div>
                              
                              {/* Trending Stats */}
                              <div className="bg-gradient-to-r from-blue-50 to-emerald-50 rounded-lg p-3 space-y-2">
                                <div className="text-xs font-semibold text-slate-700 mb-1">Trending Stats</div>
                                <div className="grid grid-cols-3 gap-2 text-xs text-slate-600">
                                  <div className="flex items-center space-x-1">
                                    <Eye className="w-3 h-3" />
                                    <span>{map.recentActivity.dailyViews.toLocaleString()}</span>
                                  </div>
                                  <div className="flex items-center space-x-1">
                                    <Heart className="w-3 h-3" />
                                    <span>{map.recentActivity.dailyLikes}</span>
                                  </div>
                                  <div className="flex items-center space-x-1">
                                    <Share className="w-3 h-3" />
                                    <span>{map.recentActivity.dailyShares}</span>
                                  </div>
                                </div>
                                <div className="text-xs text-emerald-600 font-medium">
                                  +{map.recentActivity.weeklyGrowth}% this week
                                </div>
                              </div>
                              
                              <div className="flex items-center justify-between text-sm text-slate-500">
                                <div className="flex items-center space-x-1">
                                  <MapPin className="w-4 h-4" />
                                  <span>{map.markerCount} markers</span>
                                </div>
                                {map.distance && (
                                  <div className="flex items-center space-x-1">
                                    <span>{map.distance} km away</span>
                                  </div>
                                )}
                              </div>
                              
                              <div className="flex flex-wrap gap-1 mt-2">
                                {map.tags.slice(0, 3).map(tag => (
                                  <Badge key={tag} variant="secondary" className="text-xs bg-slate-100 text-slate-600">
                                    #{tag}
                                  </Badge>
                                ))}
                                {map.tags.length > 3 && (
                                  <Badge variant="secondary" className="text-xs bg-slate-100 text-slate-600">
                                    +{map.tags.length - 3}
                                  </Badge>
                                )}
                              </div>

                              <div className="flex items-center justify-between pt-2 border-t border-slate-200">
                                <div className="flex space-x-2">
                                  <Button
                                    variant="ghost"
                                    size="sm"
                                    onClick={() => handleLikeMap(map.id)}
                                    className={`p-2 ${map.isLiked ? 'text-red-500' : 'text-slate-500'}`}
                                  >
                                    <Heart className={`w-4 h-4 ${map.isLiked ? 'fill-current' : ''}`} />
                                    <span className="ml-1">{map.likes.toLocaleString()}</span>
                                  </Button>
                                  <Button variant="ghost" size="sm" className="p-2 text-slate-500">
                                    <Share className="w-4 h-4" />
                                    <span className="ml-1">{map.shares}</span>
                                  </Button>
                                </div>
                                <Button
                                  variant="outline"
                                  size="sm"
                                  onClick={() => handleSaveMap(map.id)}
                                  className={`${map.isSaved ? 'bg-blue-100 text-blue-700 border-blue-300' : ''}`}
                                >
                                  {map.isSaved ? 'Saved' : 'Save'}
                                </Button>
                              </div>
                            </div>
                          </CardContent>
                        </>
                      ) : (
                        <CardContent className="p-6 flex items-center space-x-6 w-full pt-12">
                          <div className="flex-1">
                            <div className="flex items-start justify-between mb-2">
                              <div>
                                <h3 className="font-bold text-lg text-slate-800">{map.title}</h3>
                                <div className="flex items-center space-x-2 mt-1">
                                  <p className="text-sm text-slate-600">by {map.creator}</p>
                                  <Badge className={`text-xs ${getCreatorBadge(map.creatorLevel).color}`}>
                                    {getCreatorBadge(map.creatorLevel).text}
                                  </Badge>
                                </div>
                              </div>
                              <div className="flex items-center space-x-2">
                                <div className="flex items-center space-x-1 text-yellow-600">
                                  <Star className="w-4 h-4 fill-current" />
                                  <span className="font-medium">{map.rating}</span>
                                </div>
                                <Button
                                  variant="outline"
                                  size="sm"
                                  onClick={() => handleSaveMap(map.id)}
                                  className={`${map.isSaved ? 'bg-blue-100 text-blue-700 border-blue-300' : ''}`}
                                >
                                  {map.isSaved ? 'Saved' : 'Save'}
                                </Button>
                              </div>
                            </div>
                            
                            <p className="text-slate-600 mb-3 line-clamp-2">{map.description}</p>
                            
                            <div className="flex items-center justify-between">
                              <div className="flex items-center space-x-4 text-sm text-slate-500">
                                <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-200">
                                  {map.category}
                                </Badge>
                                <div className="flex items-center space-x-1">
                                  <MapPin className="w-4 h-4" />
                                  <span>{map.markerCount} markers</span>
                                </div>
                                <div className="text-emerald-600 font-medium text-xs">
                                  +{map.recentActivity.weeklyGrowth}% growth
                                </div>
                              </div>
                              
                              <div className="flex items-center space-x-2">
                                <Button
                                  variant="ghost"
                                  size="sm"
                                  onClick={() => handleLikeMap(map.id)}
                                  className={`p-2 ${map.isLiked ? 'text-red-500' : 'text-slate-500'}`}
                                >
                                  <Heart className={`w-4 h-4 ${map.isLiked ? 'fill-current' : ''}`} />
                                  <span className="ml-1">{map.likes.toLocaleString()}</span>
                                </Button>
                                <div className="flex items-center space-x-1 text-slate-500 text-sm">
                                  <Eye className="w-4 h-4" />
                                  <span>{map.views.toLocaleString()}</span>
                                </div>
                              </div>
                            </div>
                          </div>
                        </CardContent>
                      )}
                    </Card>
                  ))}
                </div>
              ) : (
                <div className="text-center py-12">
                  <div className="w-16 h-16 bg-slate-200 rounded-full flex items-center justify-center mx-auto mb-4">
                    <TrendingUp className="w-8 h-8 text-slate-400" />
                  </div>
                  <h3 className="font-semibold text-slate-600 mb-2">No trending maps found</h3>
                  <p className="text-slate-500 mb-4">
                    {searchQuery || categoryFilter !== 'all' 
                      ? 'Try adjusting your search or filters'
                      : 'Check back later for trending content'
                    }
                  </p>
                  <Button className="bg-gradient-to-r from-blue-600 to-emerald-500 hover:from-blue-700 hover:to-emerald-600">
                    Explore All Maps
                  </Button>
                </div>
              )}
            </>
          )}
        </div>
      </div>
    </div>
  );
}