import { 
  Globe, 
  TrendingUp, 
  Users, 
  Star,
  MapPin,
  Plus,
  HelpCircle,
  Settings,
  Shield,
  Database,
  Bookmark,
  Target,
  Award,
  BarChart3,
  Menu,
  X
} from 'lucide-react';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import type { User } from '@supabase/supabase-js';

interface UserProfile {
  id: string;
  name: string;
  email: string;
  level: number;
  xp: number;
  totalDistance: number;
  placesExplored: number;
  mapsContributed: number;
  achievements: string[];
  createdAt: string;
}

type ViewType = 'explore' | 'profile' | 'leaderboard' | 'public-maps' | 'nearby-places' | 'trending-maps' | 'my-contributions' | 'saved-maps' | 'backend-test' | 'backend-integration' | 'google-maps-setup' | 'relief-points' | 'how-to-use';

interface CleanSidebarProps {
  isCollapsed: boolean;
  onToggleCollapse: () => void;
  onCreateMap: () => void;
  currentView: ViewType;
  onViewChange: (view: ViewType) => void;
  user: User | null;
  profile: UserProfile | null;
}

export function CleanSidebar({ 
  isCollapsed, 
  onToggleCollapse, 
  onCreateMap,
  currentView,
  onViewChange,
  user,
  profile
}: CleanSidebarProps) {
  const sidebarWidth = isCollapsed ? 'w-16' : 'w-80';

  // Main discovery items - always visible
  const discoveryItems = [
    { 
      icon: Globe, 
      label: 'Public Maps', 
      action: () => onViewChange('public-maps'),
      description: 'Explore community-created maps',
      count: '2.4k',
      color: 'bg-blue-500',
      active: currentView === 'public-maps'
    },
    { 
      icon: TrendingUp, 
      label: 'Featured Maps', 
      action: () => onViewChange('trending-maps'),
      description: 'Trending and popular maps',
      count: '156',
      color: 'bg-emerald-500',
      active: currentView === 'trending-maps'
    },
    { 
      icon: Users, 
      label: 'Explorers', 
      action: () => onViewChange('leaderboard'),
      description: 'Top community contributors',
      count: '4.2k',
      color: 'bg-purple-500',
      active: currentView === 'leaderboard'
    }
  ];

  // Feature items - collapsed into menu
  const featureItems = [
    { 
      icon: Shield, 
      label: 'Relief Points', 
      action: () => onViewChange('relief-points'),
      active: currentView === 'relief-points'
    },
    { 
      icon: Target, 
      label: 'Nearby Places', 
      action: () => onViewChange('nearby-places'),
      active: currentView === 'nearby-places'
    },
    ...(user ? [
      { 
        icon: MapPin, 
        label: 'My Contributions', 
        action: () => onViewChange('my-contributions'),
        active: currentView === 'my-contributions'
      },
      { 
        icon: Bookmark, 
        label: 'Saved Maps', 
        action: () => onViewChange('saved-maps'),
        active: currentView === 'saved-maps'
      },
      { 
        icon: Award, 
        label: 'Profile & XP', 
        action: () => onViewChange('profile'),
        active: currentView === 'profile'
      },
    ] : []),
    { 
      icon: HelpCircle, 
      label: 'How to Use', 
      action: () => onViewChange('how-to-use'),
      active: currentView === 'how-to-use'
    },
    { 
      icon: Settings, 
      label: 'Google Maps Setup', 
      action: () => onViewChange('google-maps-setup'),
      active: currentView === 'google-maps-setup'
    },
    { 
      icon: Database, 
      label: 'Backend Integration', 
      action: () => onViewChange('backend-integration'),
      active: currentView === 'backend-integration'
    }
  ];

  return (
    <aside className={`${sidebarWidth} glassmorphism border-r border-white/20 dark:border-gray-700/20 transition-all duration-300 ease-in-out flex flex-col shadow-xl md:relative fixed md:translate-x-0 ${isCollapsed ? '-translate-x-full md:translate-x-0' : 'translate-x-0'} z-40 h-full`}>
      {/* Header */}
      <div className="flex items-center justify-between p-4 border-b border-white/20 dark:border-gray-700/20">
        {!isCollapsed && (
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-gradient-to-r from-blue-600 to-emerald-500 rounded-xl flex items-center justify-center">
              <MapPin className="w-5 h-5 text-white" />
            </div>
            <div>
              <h2 className="font-bold text-slate-800 dark:text-white">Markr</h2>
              <p className="text-xs text-slate-600 dark:text-gray-400">Community Maps</p>
            </div>
          </div>
        )}
        <Button
          variant="ghost"
          size="sm"
          onClick={onToggleCollapse}
          className="p-2 h-10 w-10 hover:bg-blue-50 dark:hover:bg-gray-700 rounded-xl transition-all duration-200 hover-lift"
        >
          {isCollapsed ? (
            <Menu className="w-5 h-5 text-blue-600" />
          ) : (
            <X className="w-5 h-5 text-blue-600" />
          )}
        </Button>
      </div>

      {/* Main Discovery Section */}
      <div className="p-4 space-y-3">
        {!isCollapsed && (
          <h3 className="text-sm font-bold text-slate-600 dark:text-gray-300 uppercase tracking-wider">
            Discover
          </h3>
        )}
        <div className="space-y-2">
          {discoveryItems.map((item, index) => (
            <button
              key={index}
              onClick={item.action}
              className={`w-full flex items-center space-x-4 px-4 py-4 rounded-xl text-left transition-all duration-200 hover:bg-gradient-to-r hover:from-blue-50 hover:to-emerald-50 dark:hover:from-gray-700 dark:hover:to-gray-600 hover:shadow-md hover-lift group ${
                isCollapsed ? 'justify-center' : ''
              } ${item.active ? 'bg-blue-100 dark:bg-gray-700 border-l-4 border-blue-500' : ''}`}
              title={isCollapsed ? item.label : undefined}
            >
              <div className={`w-10 h-10 ${item.color} rounded-xl flex items-center justify-center flex-shrink-0`}>
                <item.icon className="w-5 h-5 text-white" />
              </div>
              {!isCollapsed && (
                <div className="flex-1">
                  <div className="flex items-center justify-between">
                    <span className="font-medium text-slate-700 dark:text-gray-300 group-hover:text-slate-900 dark:group-hover:text-white">
                      {item.label}
                    </span>
                    <Badge variant="secondary" className="text-xs">
                      {item.count}
                    </Badge>
                  </div>
                  <p className="text-xs text-slate-500 dark:text-gray-400 mt-1">
                    {item.description}
                  </p>
                </div>
              )}
            </button>
          ))}
        </div>
      </div>

      {/* Create Map Button */}
      {user && (
        <div className="px-4 mb-4">
          <Button
            onClick={onCreateMap}
            className="w-full bg-gradient-to-r from-blue-500 to-emerald-500 hover:from-blue-600 hover:to-emerald-600 text-white rounded-xl py-3 h-auto"
          >
            <Plus className="w-5 h-5 mr-2" />
            {!isCollapsed && 'Create New Map'}
          </Button>
        </div>
      )}

      {/* Features Section - Collapsible */}
      <div className="flex-1 overflow-y-auto">
        <div className="p-4 space-y-3">
          {!isCollapsed && (
            <h3 className="text-sm font-bold text-slate-600 dark:text-gray-300 uppercase tracking-wider">
              Features
            </h3>
          )}
          <div className="space-y-1">
            {featureItems.map((item, index) => (
              <button
                key={index}
                onClick={item.action}
                className={`w-full flex items-center space-x-3 px-3 py-2 rounded-lg text-left transition-all duration-200 hover:bg-blue-50 dark:hover:bg-gray-700 hover:shadow-sm group ${
                  isCollapsed ? 'justify-center' : ''
                } ${item.active ? 'bg-blue-100 dark:bg-gray-700 border-l-2 border-blue-500' : ''}`}
                title={isCollapsed ? item.label : undefined}
              >
                <item.icon className="w-4 h-4 text-slate-600 dark:text-gray-300 group-hover:text-blue-600 flex-shrink-0" />
                {!isCollapsed && (
                  <span className="text-sm font-medium text-slate-700 dark:text-gray-300 group-hover:text-slate-900 dark:group-hover:text-white">
                    {item.label}
                  </span>
                )}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* User XP Progress (bottom) */}
      {!isCollapsed && user && profile && (
        <div className="p-4 border-t border-white/20 dark:border-gray-700/20 bg-gradient-to-r from-blue-50/80 to-emerald-50/80 dark:from-blue-900/20 dark:to-emerald-900/20 backdrop-blur-md">
          <div className="space-y-3">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-gradient-to-r from-blue-600 to-emerald-500 rounded-full flex items-center justify-center">
                <Star className="w-5 h-5 text-white" />
              </div>
              <div className="flex-1">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-slate-800 dark:text-white text-sm">
                    Level {profile.level}
                  </span>
                  <span className="text-xs font-semibold text-slate-600 dark:text-gray-300 bg-white/70 dark:bg-gray-800/70 px-2 py-1 rounded-lg">
                    {profile.xp.toLocaleString()} XP
                  </span>
                </div>
                <div className="w-full bg-white/50 dark:bg-gray-700/50 rounded-full h-2 mt-2">
                  <div 
                    className="bg-gradient-to-r from-blue-600 to-emerald-500 h-2 rounded-full transition-all duration-500"
                    style={{ width: `${Math.min(100, (profile.xp % 1000) / 10)}%` }}
                  ></div>
                </div>
                <p className="text-xs text-slate-600 dark:text-gray-400 mt-1">
                  {1000 - (profile.xp % 1000)} XP to next level
                </p>
              </div>
            </div>
          </div>
        </div>
      )}
    </aside>
  );
}