import { useState } from 'react';
import { Home, HelpCircle, Tags, Users, TrendingUp, Star, Clock, MessageSquare, Award, Settings } from 'lucide-react';
import { motion } from 'framer-motion';
import { useAuth } from '../contexts/DataProvider';
import { Badge } from './ui/badge';

interface SidebarProps {
  onNavigate: (view: 'feed' | 'question' | 'ask' | 'profile' | 'auth') => void;
  currentView: string;
}

export default function Sidebar({ onNavigate, currentView }: SidebarProps) {
  const { user } = useAuth();
  const [selectedFilter, setSelectedFilter] = useState('hot');

  const navigationItems = [
    { id: 'feed', icon: Home, label: 'Home', view: 'feed' as const },
    { id: 'ask', icon: HelpCircle, label: 'Ask Question', view: 'ask' as const },
    { id: 'tags', icon: Tags, label: 'Tags', view: 'feed' as const },
    { id: 'users', icon: Users, label: 'Users', view: 'feed' as const },
  ];

  const feedFilters = [
    { id: 'hot', icon: TrendingUp, label: 'Hot', count: 156 },
    { id: 'new', icon: Clock, label: 'New', count: 42 },
    { id: 'unanswered', icon: MessageSquare, label: 'Unanswered', count: 23 },
    { id: 'trending', icon: Star, label: 'Trending', count: 8 },
  ];

  const myActivity = [
    { id: 'questions', label: 'My Questions', count: 12 },
    { id: 'answers', label: 'My Answers', count: 34 },
    { id: 'bookmarks', label: 'Bookmarks', count: 7 },
    { id: 'reputation', label: 'Reputation', count: user?.reputation || 0 },
  ];

  const topTags = [
    { name: 'javascript', count: 1234, color: 'bg-yellow-500' },
    { name: 'react', count: 987, color: 'bg-blue-500' },
    { name: 'python', count: 856, color: 'bg-green-500' },
    { name: 'typescript', count: 743, color: 'bg-blue-600' },
    { name: 'node.js', count: 654, color: 'bg-green-600' },
  ];

  return (
    <aside className="fixed left-0 top-16 h-[calc(100vh-4rem)] w-64 bg-iron-card border-r border-iron-dark-gray overflow-y-auto z-40">
      <div className="p-4 space-y-6">
        {/* Navigation */}
        <div>
          <h3 className="text-sm font-semibold text-iron-gray uppercase tracking-wider mb-3">
            Navigation
          </h3>
          <nav className="space-y-1">
            {navigationItems.map((item) => (
              <motion.button
                key={item.id}
                whileHover={{ x: 4 }}
                className={`w-full flex items-center space-x-3 px-3 py-2 rounded-lg text-left transition-colors ${
                  currentView === item.view
                    ? 'bg-iron-gold text-iron-black font-semibold'
                    : 'text-iron-white hover:bg-iron-black/30 hover:text-iron-gold'
                }`}
                onClick={() => onNavigate(item.view)}
              >
                <item.icon className="w-5 h-5" />
                <span>{item.label}</span>
              </motion.button>
            ))}
          </nav>
        </div>

        {/* Feed Filters */}
        {currentView === 'feed' && (
          <div>
            <h3 className="text-sm font-semibold text-iron-gray uppercase tracking-wider mb-3">
              Questions
            </h3>
            <div className="space-y-1">
              {feedFilters.map((filter) => (
                <motion.button
                  key={filter.id}
                  whileHover={{ x: 4 }}
                  className={`w-full flex items-center justify-between px-3 py-2 rounded-lg text-left transition-colors ${
                    selectedFilter === filter.id
                      ? 'bg-iron-red text-iron-white'
                      : 'text-iron-light-gray hover:bg-iron-black/30 hover:text-iron-white'
                  }`}
                  onClick={() => setSelectedFilter(filter.id)}
                >
                  <div className="flex items-center space-x-3">
                    <filter.icon className="w-4 h-4" />
                    <span>{filter.label}</span>
                  </div>
                  <Badge variant="secondary" className="bg-iron-dark-gray text-iron-light-gray text-xs">
                    {filter.count}
                  </Badge>
                </motion.button>
              ))}
            </div>
          </div>
        )}

        {/* My Activity */}
        <div>
          <h3 className="text-sm font-semibold text-iron-gray uppercase tracking-wider mb-3">
            My Activity
          </h3>
          <div className="space-y-1">
            {myActivity.map((item) => (
              <div
                key={item.id}
                className="flex items-center justify-between px-3 py-2 text-iron-light-gray hover:bg-iron-black/30 hover:text-iron-white rounded-lg cursor-pointer transition-colors"
              >
                <span className="text-sm">{item.label}</span>
                <Badge variant="outline" className="border-iron-dark-gray text-iron-gold text-xs">
                  {item.count}
                </Badge>
              </div>
            ))}
          </div>
        </div>

        {/* Top Tags */}
        <div>
          <h3 className="text-sm font-semibold text-iron-gray uppercase tracking-wider mb-3">
            Popular Tags
          </h3>
          <div className="space-y-2">
            {topTags.map((tag, index) => (
              <motion.div
                key={tag.name}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: index * 0.1 }}
                className="flex items-center justify-between p-2 rounded-lg bg-iron-black/30 hover:bg-iron-black/50 cursor-pointer transition-colors"
              >
                <div className="flex items-center space-x-2">
                  <div className={`w-3 h-3 rounded-full ${tag.color}`}></div>
                  <span className="text-sm text-iron-white font-medium">{tag.name}</span>
                </div>
                <span className="text-xs text-iron-gray">{tag.count}</span>
              </motion.div>
            ))}
          </div>
        </div>

        {/* User Level Progress */}
        {user && (
          <div className="p-4 bg-iron-black/30 rounded-lg">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm font-semibold text-iron-white">Level Progress</span>
              <Award className="w-4 h-4 text-iron-gold" />
            </div>
            <div className="mb-2">
              <div className="flex justify-between text-xs text-iron-gray mb-1">
                <span>Level {user.level}</span>
                <span>Next: Level {user.level + 1}</span>
              </div>
              <div className="w-full bg-iron-dark-gray rounded-full h-2">
                <div
                  className="bg-gradient-to-r from-iron-red to-iron-gold h-2 rounded-full transition-all duration-300"
                  style={{ width: '65%' }}
                ></div>
              </div>
            </div>
            <p className="text-xs text-iron-gray">
              {Math.max(0, 400 - user.reputation)} more reputation to reach Level {user.level + 1}
            </p>
          </div>
        )}

        {/* Quick Actions */}
        <div className="pt-4 border-t border-iron-dark-gray">
          <motion.button
            whileHover={{ scale: 1.02 }}
            className="w-full flex items-center space-x-2 px-3 py-2 rounded-lg text-iron-light-gray hover:bg-iron-black/30 hover:text-iron-white transition-colors"
          >
            <Settings className="w-4 h-4" />
            <span className="text-sm">Settings</span>
          </motion.button>
        </div>
      </div>
    </aside>
  );
}