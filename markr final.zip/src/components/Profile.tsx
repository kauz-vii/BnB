import { useState } from 'react';
import { motion } from 'framer-motion';
import { User, Star, Award, Calendar, MapPin, Link as LinkIcon, Edit, MessageSquare, TrendingUp, HelpCircle, CheckCircle } from 'lucide-react';
import { useAuth, useQuestions, useAnswers } from '../contexts/DataProvider';
import { getUserById } from '../contexts/AuthContext';
import { ReputationActivity } from '../types';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Card } from './ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';

interface ProfileProps {
  userId: string;
}

export default function Profile({ userId }: ProfileProps) {
  const { user: currentUser } = useAuth();
  const { getQuestionsByAuthor } = useQuestions();
  const { getAnswersByAuthor } = useAnswers();
  const [activeTab, setActiveTab] = useState('overview');

  const profileUser = getUserById(userId);
  const questions = profileUser ? getQuestionsByAuthor(profileUser.id) : [];
  const answers = profileUser ? getAnswersByAuthor(profileUser.id) : [];

  // Mock reputation history
  const mockReputationHistory: ReputationActivity[] = [
    {
      id: '1',
      userId,
      type: 'ANSWER_ACCEPTED',
      points: 15,
      description: 'Answer accepted for "JWT authentication best practices"',
      createdAt: new Date(Date.now() - 43200000)
    },
    {
      id: '2',
      userId,
      type: 'ANSWER_UPVOTE',
      points: 10,
      description: 'Answer upvoted on "Rate limiting strategies"',
      createdAt: new Date(Date.now() - 86400000)
    },
    {
      id: '3',
      userId,
      type: 'QUESTION_UPVOTE',
      points: 5,
      description: 'Question upvoted: "OAuth 2.0 with PKCE implementation"',
      createdAt: new Date(Date.now() - 129600000)
    }
  ];

  const formatTimeAgo = (date: Date) => {
    const now = new Date();
    const diff = now.getTime() - date.getTime();
    const days = Math.floor(diff / (1000 * 60 * 60 * 24));
    
    if (days === 0) return 'today';
    if (days === 1) return '1 day ago';
    if (days < 30) return `${days} days ago`;
    if (days < 365) return `${Math.floor(days / 30)} months ago`;
    return `${Math.floor(days / 365)} years ago`;
  };

  const getUserLevel = (reputation: number) => {
    if (reputation >= 1600) return { name: 'Moderator', color: 'bg-gradient-to-r from-iron-red to-iron-gold', level: 6 };
    if (reputation >= 900) return { name: 'Guru', color: 'bg-gradient-to-r from-iron-gold to-iron-bright-gold', level: 5 };
    if (reputation >= 400) return { name: 'Expert', color: 'bg-iron-bright-gold', level: 4 };
    if (reputation >= 150) return { name: 'Helpful', color: 'bg-iron-gold', level: 3 };
    if (reputation >= 50) return { name: 'Contributor', color: 'bg-iron-red', level: 2 };
    return { name: 'Newbie', color: 'bg-iron-gray', level: 1 };
  };

  const getNextLevelRequirement = (currentRep: number) => {
    const levels = [50, 150, 400, 900, 1600];
    const nextLevel = levels.find(level => level > currentRep);
    return nextLevel ? nextLevel - currentRep : 0;
  };

  if (!profileUser) {
    return (
      <div className="p-6">
        <div className="max-w-6xl mx-auto">
          <div className="text-center py-12">
            <div className="text-iron-gray mb-4">
              <User className="w-16 h-16 mx-auto mb-4 opacity-50" />
              <h3 className="text-xl font-semibold mb-2">User not found</h3>
              <p>The user profile you're looking for doesn't exist.</p>
            </div>
          </div>
        </div>
      </div>
    );
  }

  const isOwnProfile = currentUser?.id === profileUser.id;
  const userLevel = getUserLevel(profileUser.reputation);
  const nextLevelPoints = getNextLevelRequirement(profileUser.reputation);

  return (
    <div className="p-6">
      <div className="max-w-6xl mx-auto space-y-6">
        {/* Profile Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
        >
          <Card className="p-8 bg-iron-card border-iron-dark-gray">
            <div className="flex items-start justify-between">
              <div className="flex items-start space-x-6">
                {/* Avatar */}
                <div className="w-24 h-24 bg-iron-gold rounded-full flex items-center justify-center">
                  <User className="w-12 h-12 text-iron-black" />
                </div>

                {/* User Info */}
                <div>
                  <h1 className="text-3xl font-poppins font-black text-iron-white mb-2 heading-shadow">
                    {profileUser.username}
                  </h1>
                  
                  {/* Level and Reputation */}
                  <div className="flex items-center space-x-4 mb-4">
                    <div className="flex items-center space-x-2">
                      <div className={`w-4 h-4 rounded-full ${userLevel.color}`}></div>
                      <span className="text-iron-gold font-semibold">{userLevel.name}</span>
                      <span className="text-iron-gray">•</span>
                      <span className="text-iron-white font-semibold">{profileUser.reputation}</span>
                      <span className="text-iron-gray">reputation</span>
                    </div>
                  </div>

                  {/* Bio */}
                  {profileUser.bio && (
                    <p className="text-iron-light-gray max-w-2xl mb-4">
                      {profileUser.bio}
                    </p>
                  )}

                  {/* Meta Info */}
                  <div className="flex items-center space-x-4 text-sm text-iron-gray">
                    <div className="flex items-center space-x-1">
                      <Calendar className="w-4 h-4" />
                      <span>Member since {formatTimeAgo(profileUser.createdAt)}</span>
                    </div>
                    <div className="flex items-center space-x-1">
                      <Award className="w-4 h-4" />
                      <span>Level {userLevel.level}</span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex space-x-2">
                {isOwnProfile ? (
                  <Button
                    variant="outline"
                    className="border-iron-dark-gray text-iron-white hover:bg-iron-black/30"
                  >
                    <Edit className="w-4 h-4 mr-2" />
                    Edit Profile
                  </Button>
                ) : (
                  <>
                    <Button
                      variant="outline"
                      className="border-iron-dark-gray text-iron-white hover:bg-iron-black/30"
                    >
                      <MessageSquare className="w-4 h-4 mr-2" />
                      Message
                    </Button>
                    <Button
                      variant="outline"
                      className="border-iron-dark-gray text-iron-white hover:bg-iron-black/30"
                    >
                      Follow
                    </Button>
                  </>
                )}
              </div>
            </div>

            {/* Progress to Next Level */}
            {nextLevelPoints > 0 && (
              <div className="mt-6 p-4 bg-iron-black/30 rounded-lg">
                <div className="flex justify-between items-center mb-2">
                  <span className="text-sm text-iron-white">Progress to next level</span>
                  <span className="text-sm text-iron-gold">{nextLevelPoints} points needed</span>
                </div>
                <div className="w-full bg-iron-dark-gray rounded-full h-2">
                  <div
                    className="bg-gradient-to-r from-iron-red to-iron-gold h-2 rounded-full transition-all duration-300"
                    style={{ 
                      width: `${Math.max(20, 100 - (nextLevelPoints / 100) * 100)}%` 
                    }}
                  ></div>
                </div>
              </div>
            )}
          </Card>
        </motion.div>

        {/* Stats Cards */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="grid grid-cols-1 md:grid-cols-4 gap-4"
        >
          <Card className="p-4 bg-iron-card border-iron-dark-gray text-center">
            <div className="text-2xl font-bold text-iron-gold mb-1">{questions.length}</div>
            <div className="text-sm text-iron-gray flex items-center justify-center">
              <HelpCircle className="w-4 h-4 mr-1" />
              Questions Asked
            </div>
          </Card>
          
          <Card className="p-4 bg-iron-card border-iron-dark-gray text-center">
            <div className="text-2xl font-bold text-iron-gold mb-1">{answers.length}</div>
            <div className="text-sm text-iron-gray flex items-center justify-center">
              <MessageSquare className="w-4 h-4 mr-1" />
              Answers Given
            </div>
          </Card>
          
          <Card className="p-4 bg-iron-card border-iron-dark-gray text-center">
            <div className="text-2xl font-bold text-iron-gold mb-1">
              {answers.filter(a => a.isAccepted).length}
            </div>
            <div className="text-sm text-iron-gray flex items-center justify-center">
              <CheckCircle className="w-4 h-4 mr-1" />
              Accepted Answers
            </div>
          </Card>
          
          <Card className="p-4 bg-iron-card border-iron-dark-gray text-center">
            <div className="text-2xl font-bold text-iron-gold mb-1">{profileUser.reputation}</div>
            <div className="text-sm text-iron-gray flex items-center justify-center">
              <TrendingUp className="w-4 h-4 mr-1" />
              Total Reputation
            </div>
          </Card>
        </motion.div>

        {/* Content Tabs */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
        >
          <Tabs value={activeTab} onValueChange={setActiveTab}>
            <TabsList className="bg-iron-black/30 border-iron-dark-gray">
              <TabsTrigger value="overview" className="data-[state=active]:bg-iron-gold data-[state=active]:text-iron-black">
                Overview
              </TabsTrigger>
              <TabsTrigger value="questions" className="data-[state=active]:bg-iron-gold data-[state=active]:text-iron-black">
                Questions ({questions.length})
              </TabsTrigger>
              <TabsTrigger value="answers" className="data-[state=active]:bg-iron-gold data-[state=active]:text-iron-black">
                Answers ({answers.length})
              </TabsTrigger>
              <TabsTrigger value="reputation" className="data-[state=active]:bg-iron-gold data-[state=active]:text-iron-black">
                Reputation
              </TabsTrigger>
            </TabsList>

            {/* Overview Tab */}
            <TabsContent value="overview" className="space-y-6">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                {/* Recent Questions */}
                <Card className="p-6 bg-iron-card border-iron-dark-gray">
                  <h3 className="text-lg font-poppins font-bold text-iron-white mb-4 heading-shadow">
                    Recent Questions
                  </h3>
                  <div className="space-y-3">
                    {questions.slice(0, 3).map((question) => (
                      <div key={question.id} className="p-3 bg-iron-black/30 rounded-lg">
                        <div className="font-medium text-iron-white text-sm mb-1">
                          {question.title}
                        </div>
                        <div className="flex items-center justify-between text-xs text-iron-gray">
                          <div className="flex items-center space-x-2">
                            <span>{question.score} votes</span>
                            <span>•</span>
                            <span>{question.views} views</span>
                          </div>
                          <span>{formatTimeAgo(question.createdAt)}</span>
                        </div>
                      </div>
                    ))}
                    {questions.length === 0 && (
                      <p className="text-iron-gray text-sm">No questions asked yet.</p>
                    )}
                  </div>
                </Card>

                {/* Recent Answers */}
                <Card className="p-6 bg-iron-card border-iron-dark-gray">
                  <h3 className="text-lg font-poppins font-bold text-iron-white mb-4 heading-shadow">
                    Recent Answers
                  </h3>
                  <div className="space-y-3">
                    {answers.slice(0, 3).map((answer) => (
                      <div key={answer.id} className="p-3 bg-iron-black/30 rounded-lg">
                        <div className="text-iron-light-gray text-sm mb-2 line-clamp-2">
                          {answer.body.slice(0, 100)}...
                        </div>
                        <div className="flex items-center justify-between text-xs text-iron-gray">
                          <div className="flex items-center space-x-2">
                            <span>{answer.score} votes</span>
                            {answer.isAccepted && (
                              <>
                                <span>•</span>
                                <CheckCircle className="w-3 h-3 text-iron-gold" />
                                <span className="text-iron-gold">Accepted</span>
                              </>
                            )}
                          </div>
                          <span>{formatTimeAgo(answer.createdAt)}</span>
                        </div>
                      </div>
                    ))}
                    {answers.length === 0 && (
                      <p className="text-iron-gray text-sm">No answers provided yet.</p>
                    )}
                  </div>
                </Card>
              </div>
            </TabsContent>

            {/* Questions Tab */}
            <TabsContent value="questions" className="space-y-4">
              {questions.map((question) => (
                <Card key={question.id} className="p-6 bg-iron-card border-iron-dark-gray">
                  <div className="flex justify-between items-start mb-3">
                    <h4 className="text-lg font-semibold text-iron-white">
                      {question.title}
                    </h4>
                    <div className="flex items-center space-x-2 text-sm text-iron-gray">
                      <span>{question.score} votes</span>
                      <span>•</span>
                      <span>{question.views} views</span>
                    </div>
                  </div>
                  
                  <div className="flex flex-wrap gap-2 mb-3">
                    {question.tags.map((tag) => (
                      <Badge
                        key={tag}
                        variant="secondary"
                        className="bg-iron-black/50 text-iron-gold border-iron-dark-gray"
                      >
                        {tag}
                      </Badge>
                    ))}
                  </div>
                  
                  <div className="text-sm text-iron-gray">
                    Asked {formatTimeAgo(question.createdAt)}
                    {question.acceptedAnswerId && (
                      <span className="ml-3 text-iron-gold">• Has accepted answer</span>
                    )}
                  </div>
                </Card>
              ))}
              {questions.length === 0 && (
                <div className="text-center py-8 text-iron-gray">
                  No questions asked yet.
                </div>
              )}
            </TabsContent>

            {/* Answers Tab */}
            <TabsContent value="answers" className="space-y-4">
              {answers.map((answer) => (
                <Card key={answer.id} className="p-6 bg-iron-card border-iron-dark-gray">
                  <div className="flex justify-between items-start mb-3">
                    <div className="flex items-center space-x-2">
                      <span className="text-lg font-semibold text-iron-white">{answer.score}</span>
                      <span className="text-iron-gray">votes</span>
                      {answer.isAccepted && (
                        <Badge className="bg-iron-gold text-iron-black">
                          <CheckCircle className="w-3 h-3 mr-1" />
                          Accepted
                        </Badge>
                      )}
                    </div>
                    <span className="text-sm text-iron-gray">
                      {formatTimeAgo(answer.createdAt)}
                    </span>
                  </div>
                  
                  <div className="text-iron-light-gray">
                    {answer.body.slice(0, 200)}...
                  </div>
                </Card>
              ))}
              {answers.length === 0 && (
                <div className="text-center py-8 text-iron-gray">
                  No answers provided yet.
                </div>
              )}
            </TabsContent>

            {/* Reputation Tab */}
            <TabsContent value="reputation" className="space-y-4">
              <Card className="p-6 bg-iron-card border-iron-dark-gray">
                <h3 className="text-lg font-poppins font-bold text-iron-white mb-4 heading-shadow">
                  Reputation History
                </h3>
                <div className="space-y-3">
                  {mockReputationHistory.map((activity) => (
                    <div key={activity.id} className="flex items-center justify-between p-3 bg-iron-black/30 rounded-lg">
                      <div>
                        <div className="text-iron-white text-sm">
                          {activity.description}
                        </div>
                        <div className="text-xs text-iron-gray">
                          {formatTimeAgo(activity.createdAt)}
                        </div>
                      </div>
                      <div className={`font-semibold ${activity.points > 0 ? 'text-iron-gold' : 'text-iron-red'}`}>
                        {activity.points > 0 ? '+' : ''}{activity.points}
                      </div>
                    </div>
                  ))}
                </div>
              </Card>
            </TabsContent>
          </Tabs>
        </motion.div>
      </div>
    </div>
  );
}