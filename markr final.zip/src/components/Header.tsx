import { useState } from 'react';
import { Search, Bell, MessageSquare, User, Settings, LogOut, Plus } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { useAuth, useNotifications } from '../contexts/DataProvider';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Badge } from './ui/badge';

interface HeaderProps {
  onNavigate: (view: 'feed' | 'question' | 'ask' | 'profile' | 'auth') => void;
  onNavigateToProfile: (userId: string) => void;
  currentView: string;
}

export default function Header({ onNavigate, onNavigateToProfile, currentView }: HeaderProps) {
  const { user, logout } = useAuth();
  const { getNotificationsByUser, getUnreadCount } = useNotifications();
  const [searchQuery, setSearchQuery] = useState('');
  const [showUserMenu, setShowUserMenu] = useState(false);
  const [showNotifications, setShowNotifications] = useState(false);

  const notifications = user ? getNotificationsByUser(user.id) : [];
  const unreadCount = user ? getUnreadCount(user.id) : 0;

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      // Implement search functionality
      console.log('Searching for:', searchQuery);
    }
  };

  const getUserLevel = () => {
    if (!user) return null;
    const levels = [
      { min: 0, name: 'Newbie', color: 'bg-iron-gray' },
      { min: 50, name: 'Contributor', color: 'bg-iron-red' },
      { min: 150, name: 'Helpful', color: 'bg-iron-gold' },
      { min: 400, name: 'Expert', color: 'bg-iron-bright-gold' },
      { min: 900, name: 'Guru', color: 'bg-gradient-to-r from-iron-gold to-iron-bright-gold' },
      { min: 1600, name: 'Moderator', color: 'bg-gradient-to-r from-iron-red to-iron-gold' },
    ];
    
    const userLevel = levels.reverse().find(level => user.reputation >= level.min) || levels[0];
    return userLevel;
  };

  const userLevel = getUserLevel();

  const formatTimeAgo = (date: Date) => {
    const now = new Date();
    const diff = now.getTime() - date.getTime();
    const hours = Math.floor(diff / (1000 * 60 * 60));
    
    if (hours < 1) return 'just now';
    if (hours === 1) return '1 hour ago';
    if (hours < 24) return `${hours} hours ago`;
    
    const days = Math.floor(hours / 24);
    if (days === 1) return '1 day ago';
    return `${days} days ago`;
  };

  return (
    <header className="bg-iron-card border-b border-iron-dark-gray sticky top-0 z-50 backdrop-blur-md">
      <div className="max-w-7xl mx-auto px-6 py-4">
        <div className="flex items-center justify-between">
          {/* Logo and Brand */}
          <div className="flex items-center space-x-4">
            <motion.div
              whileHover={{ scale: 1.05 }}
              className="flex items-center space-x-2 cursor-pointer"
              onClick={() => onNavigate('feed')}
            >
              <div className="w-8 h-8 bg-gradient-to-br from-iron-red to-iron-gold rounded-lg flex items-center justify-center">
                <div className="w-4 h-4 bg-iron-white rounded-full"></div>
              </div>
              <span className="text-2xl font-poppins font-black text-iron-white">
                TechQ&A
              </span>
            </motion.div>

            {/* Navigation */}
            <nav className="hidden md:flex items-center space-x-1 ml-8">
              <Button
                variant="ghost"
                className={`text-iron-white hover:text-iron-gold transition-colors ${
                  currentView === 'feed' ? 'text-iron-gold bg-iron-red/20' : ''
                }`}
                onClick={() => onNavigate('feed')}
              >
                Questions
              </Button>
              <Button
                variant="ghost"
                className="text-iron-white hover:text-iron-gold transition-colors"
              >
                Tags
              </Button>
              <Button
                variant="ghost"
                className="text-iron-white hover:text-iron-gold transition-colors"
              >
                Users
              </Button>
            </nav>
          </div>

          {/* Search Bar */}
          <form onSubmit={handleSearch} className="flex-1 max-w-md mx-8">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-iron-gray" />
              <Input
                type="text"
                placeholder="Search questions, tags, users..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10 bg-iron-black/50 border-iron-dark-gray text-iron-white placeholder-iron-gray focus:border-iron-gold"
              />
            </div>
          </form>

          {/* User Actions */}
          <div className="flex items-center space-x-3">
            {/* Ask Question Button */}
            <Button
              onClick={() => onNavigate('ask')}
              className="bg-iron-gold hover:bg-iron-bright-gold text-iron-black font-semibold"
            >
              <Plus className="w-4 h-4 mr-1" />
              Ask Question
            </Button>

            {/* Notifications */}
            <div className="relative">
              <Button
                variant="ghost"
                size="sm"
                className="text-iron-white hover:text-iron-gold relative"
                onClick={() => setShowNotifications(!showNotifications)}
              >
                <Bell className="w-5 h-5" />
                {unreadCount > 0 && (
                  <Badge className="absolute -top-1 -right-1 w-5 h-5 text-xs bg-iron-red text-iron-white border-0 p-0 flex items-center justify-center">
                    {unreadCount}
                  </Badge>
                )}
              </Button>

              <AnimatePresence>
                {showNotifications && (
                  <motion.div
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: 10 }}
                    className="absolute right-0 top-full mt-2 w-80 bg-iron-card border border-iron-dark-gray rounded-lg shadow-lg z-50"
                  >
                    <div className="p-4 border-b border-iron-dark-gray">
                      <h3 className="font-poppins font-bold text-iron-white">Notifications</h3>
                    </div>
                    <div className="max-h-96 overflow-y-auto">
                      {notifications.slice(0, 5).map((notification) => (
                        <div
                          key={notification.id}
                          className={`p-4 border-b border-iron-dark-gray/50 hover:bg-iron-black/30 cursor-pointer ${
                            !notification.read ? 'bg-iron-red/10' : ''
                          }`}
                        >
                          <p className="text-iron-white text-sm">
                            {notification.type === 'ANSWER_POSTED' && `New answer on "${notification.data.questionTitle}"`}
                            {notification.type === 'RATING_RECEIVED' && `You received a ${notification.data.stars}-star rating!`}
                            {notification.type === 'ANSWER_ACCEPTED' && `Your answer was accepted!`}
                          </p>
                          <p className="text-iron-gray text-xs mt-1">{formatTimeAgo(notification.createdAt)}</p>
                        </div>
                      ))}
                      {notifications.length === 0 && (
                        <div className="p-4 text-center text-iron-gray">
                          No notifications yet
                        </div>
                      )}
                    </div>
                    <div className="p-3 border-t border-iron-dark-gray">
                      <Button variant="ghost" className="w-full text-iron-gold hover:text-iron-bright-gold text-sm">
                        View All Notifications
                      </Button>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>

            {/* Messages */}
            <Button
              variant="ghost"
              size="sm"
              className="text-iron-white hover:text-iron-gold"
            >
              <MessageSquare className="w-5 h-5" />
            </Button>

            {/* User Menu */}
            <div className="relative">
              <Button
                variant="ghost"
                className="flex items-center space-x-2 text-iron-white hover:text-iron-gold"
                onClick={() => setShowUserMenu(!showUserMenu)}
              >
                <div className="flex items-center space-x-2">
                  <div className="w-8 h-8 bg-iron-gold rounded-full flex items-center justify-center">
                    <User className="w-4 h-4 text-iron-black" />
                  </div>
                  <div className="text-left hidden md:block">
                    <div className="text-sm font-semibold">{user?.username}</div>
                    <div className="text-xs text-iron-gray flex items-center">
                      <div className={`w-2 h-2 rounded-full ${userLevel?.color} mr-1`}></div>
                      {user?.reputation} rep
                    </div>
                  </div>
                </div>
              </Button>

              <AnimatePresence>
                {showUserMenu && (
                  <motion.div
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: 10 }}
                    className="absolute right-0 top-full mt-2 w-64 bg-iron-card border border-iron-dark-gray rounded-lg shadow-lg z-50"
                  >
                    <div className="p-4 border-b border-iron-dark-gray">
                      <div className="flex items-center space-x-3">
                        <div className="w-12 h-12 bg-iron-gold rounded-full flex items-center justify-center">
                          <User className="w-6 h-6 text-iron-black" />
                        </div>
                        <div>
                          <div className="font-semibold text-iron-white">{user?.username}</div>
                          <div className="text-sm text-iron-gray">{user?.email}</div>
                          <div className="flex items-center mt-1">
                            <div className={`w-3 h-3 rounded-full ${userLevel?.color} mr-2`}></div>
                            <span className="text-sm text-iron-gold font-semibold">
                              {userLevel?.name} • {user?.reputation} rep
                            </span>
                          </div>
                        </div>
                      </div>
                    </div>

                    <div className="py-2">
                      <button
                        className="w-full px-4 py-2 text-left text-iron-white hover:bg-iron-black/30 flex items-center space-x-2"
                        onClick={() => {
                          onNavigateToProfile(user?.id || '');
                          setShowUserMenu(false);
                        }}
                      >
                        <User className="w-4 h-4" />
                        <span>Profile</span>
                      </button>
                      <button className="w-full px-4 py-2 text-left text-iron-white hover:bg-iron-black/30 flex items-center space-x-2">
                        <Settings className="w-4 h-4" />
                        <span>Settings</span>
                      </button>
                      <div className="border-t border-iron-dark-gray my-1"></div>
                      <button
                        className="w-full px-4 py-2 text-left text-iron-red hover:bg-iron-red/10 flex items-center space-x-2"
                        onClick={() => {
                          logout();
                          setShowUserMenu(false);
                        }}
                      >
                        <LogOut className="w-4 h-4" />
                        <span>Sign Out</span>
                      </button>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          </div>
        </div>
      </div>
    </header>
  );
}