import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Alert, AlertDescription } from './ui/alert';
import { Loader2, CheckCircle, XCircle, AlertCircle, Globe, Database } from 'lucide-react';
import { config } from '../config';

interface BackendStatus {
  connected: boolean;
  version?: string;
  endpoints?: string[];
  latency?: number;
  error?: string;
}

interface EndpointTest {
  name: string;
  url: string;
  method: string;
  status: 'pending' | 'success' | 'error';
  response?: any;
  latency?: number;
  error?: string;
}

export function BackendIntegration() {
  const [backendStatus, setBackendStatus] = useState<BackendStatus>({ connected: false });
  const [testing, setTesting] = useState(false);
  const [endpointTests, setEndpointTests] = useState<EndpointTest[]>([]);

  const testEndpoints = [
    { name: 'Health Check', url: '/health', method: 'GET' },
    { name: 'API Info', url: '/api', method: 'GET' },
    { name: 'Maps List', url: '/api/maps', method: 'GET' },
    { name: 'Leaderboard', url: '/api/leaderboard', method: 'GET' },
    { name: 'Public Data', url: '/api/public', method: 'GET' },
    { name: 'Relief Points', url: '/api/relief-points', method: 'GET' },
  ];

  const testBackendConnection = async () => {
    setTesting(true);
    const baseUrl = config.backend.baseUrl;
    
    try {
      const start = Date.now();
      const response = await fetch(`${baseUrl}/health`, {
        method: 'GET',
        headers: {
          'Content-Type': 'application/json',
        },
      });
      
      const latency = Date.now() - start;
      
      if (response.ok) {
        const data = await response.json();
        setBackendStatus({
          connected: true,
          version: data.version || '1.0.0',
          latency,
        });
      } else {
        setBackendStatus({
          connected: false,
          error: `HTTP ${response.status}: ${response.statusText}`,
        });
      }
    } catch (error: any) {
      setBackendStatus({
        connected: false,
        error: error.message || 'Connection failed',
      });
    } finally {
      setTesting(false);
    }
  };

  const testAllEndpoints = async () => {
    setTesting(true);
    const baseUrl = config.backend.baseUrl;
    const tests: EndpointTest[] = testEndpoints.map(endpoint => ({
      ...endpoint,
      status: 'pending',
    }));
    
    setEndpointTests(tests);

    for (let i = 0; i < testEndpoints.length; i++) {
      const endpoint = testEndpoints[i];
      const start = Date.now();
      
      try {
        const response = await fetch(`${baseUrl}${endpoint.url}`, {
          method: endpoint.method,
          headers: {
            'Content-Type': 'application/json',
          },
        });
        
        const latency = Date.now() - start;
        let responseData;
        
        try {
          responseData = await response.json();
        } catch {
          responseData = await response.text();
        }

        setEndpointTests(prev => prev.map((test, index) => 
          index === i ? {
            ...test,
            status: response.ok ? 'success' : 'error',
            response: responseData,
            latency,
            error: response.ok ? undefined : `HTTP ${response.status}`,
          } : test
        ));
      } catch (error: any) {
        setEndpointTests(prev => prev.map((test, index) => 
          index === i ? {
            ...test,
            status: 'error',
            error: error.message,
            latency: Date.now() - start,
          } : test
        ));
      }

      // Small delay between requests
      await new Promise(resolve => setTimeout(resolve, 300));
    }
    
    setTesting(false);
  };

  const getStatusIcon = (status: 'pending' | 'success' | 'error') => {
    switch (status) {
      case 'pending':
        return <Loader2 className="w-4 h-4 animate-spin text-blue-500" />;
      case 'success':
        return <CheckCircle className="w-4 h-4 text-green-500" />;
      case 'error':
        return <XCircle className="w-4 h-4 text-red-500" />;
    }
  };

  const getStatusBadge = (status: 'pending' | 'success' | 'error') => {
    const variants = {
      pending: 'secondary' as const,
      success: 'default' as const,
      error: 'destructive' as const,
    };

    return (
      <Badge variant={variants[status]} className="ml-auto">
        {status === 'pending' ? 'Testing' : status === 'success' ? 'Success' : 'Failed'}
      </Badge>
    );
  };

  // Test connection on component mount
  useEffect(() => {
    testBackendConnection();
  }, []);

  const successCount = endpointTests.filter(test => test.status === 'success').length;
  const errorCount = endpointTests.filter(test => test.status === 'error').length;
  const totalTests = endpointTests.length;

  return (
    <div className="p-6 max-w-6xl mx-auto space-y-6">
      {/* Backend Status Card */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Database className="w-5 h-5 text-blue-500" />
            Backend Connection Status
          </CardTitle>
          <CardDescription>
            Connection status for Markr backend at {config.backend.baseUrl}
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-3">
              {backendStatus.connected ? (
                <CheckCircle className="w-6 h-6 text-green-500" />
              ) : (
                <XCircle className="w-6 h-6 text-red-500" />
              )}
              <div>
                <p className="font-medium">
                  {backendStatus.connected ? 'Connected' : 'Disconnected'}
                </p>
                <p className="text-sm text-muted-foreground">
                  {backendStatus.connected 
                    ? `Version ${backendStatus.version} • ${backendStatus.latency}ms`
                    : backendStatus.error
                  }
                </p>
              </div>
            </div>
            <Button
              onClick={testBackendConnection}
              disabled={testing}
              variant="outline"
              size="sm"
            >
              {testing ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : null}
              Test Connection
            </Button>
          </div>

          {!backendStatus.connected && backendStatus.error && (
            <Alert>
              <AlertCircle className="h-4 w-4" />
              <AlertDescription>
                {backendStatus.error}
              </AlertDescription>
            </Alert>
          )}
        </CardContent>
      </Card>

      {/* Endpoint Tests Card */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Globe className="w-5 h-5 text-emerald-500" />
            Endpoint Testing
          </CardTitle>
          <CardDescription>
            Test individual API endpoints to ensure full functionality
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between">
            <Button
              onClick={testAllEndpoints}
              disabled={testing || !backendStatus.connected}
              className="flex items-center gap-2"
            >
              {testing && <Loader2 className="w-4 h-4 animate-spin" />}
              {testing ? 'Testing Endpoints...' : 'Test All Endpoints'}
            </Button>

            {totalTests > 0 && (
              <div className="text-sm text-muted-foreground">
                {successCount} passed, {errorCount} failed, {totalTests} total
              </div>
            )}
          </div>

          {endpointTests.length > 0 && (
            <div className="space-y-2">
              {endpointTests.map((test, index) => (
                <div
                  key={index}
                  className="flex items-center gap-3 p-3 border rounded-lg bg-card"
                >
                  {getStatusIcon(test.status)}
                  
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <span className="font-medium">{test.name}</span>
                      <span className="text-xs text-muted-foreground">
                        {test.method} {test.url}
                      </span>
                      {test.latency && (
                        <span className="text-xs text-muted-foreground">
                          ({test.latency}ms)
                        </span>
                      )}
                    </div>
                    {test.error && (
                      <p className="text-sm text-red-600 dark:text-red-400">
                        {test.error}
                      </p>
                    )}
                    {test.response && test.status === 'success' && (
                      <p className="text-sm text-green-600 dark:text-green-400">
                        Response received successfully
                      </p>
                    )}
                  </div>

                  {getStatusBadge(test.status)}
                </div>
              ))}
            </div>
          )}

          {/* Summary */}
          {totalTests > 0 && !testing && (
            <div className="mt-6 p-4 border rounded-lg bg-muted/50">
              <h4 className="font-medium mb-2">Endpoint Test Summary</h4>
              <div className="grid grid-cols-3 gap-4 text-sm">
                <div className="text-center">
                  <div className="text-2xl font-bold text-green-600">{successCount}</div>
                  <div className="text-muted-foreground">Passed</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-red-600">{errorCount}</div>
                  <div className="text-muted-foreground">Failed</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-blue-600">
                    {totalTests > 0 ? Math.round((successCount / totalTests) * 100) : 0}%
                  </div>
                  <div className="text-muted-foreground">Success Rate</div>
                </div>
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Configuration Info */}
      <Card>
        <CardHeader>
          <CardTitle>Backend Configuration</CardTitle>
          <CardDescription>
            Current backend configuration for Markr application
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            <div className="flex justify-between items-center py-2 border-b">
              <span className="font-medium">Backend URL</span>
              <span className="text-muted-foreground font-mono text-sm">
                {config.backend.baseUrl}
              </span>
            </div>
            <div className="flex justify-between items-center py-2 border-b">
              <span className="font-medium">API Version</span>
              <span className="text-muted-foreground">
                {config.backend.apiVersion}
              </span>
            </div>
            <div className="flex justify-between items-center py-2 border-b">
              <span className="font-medium">Application</span>
              <span className="text-muted-foreground">
                {config.app.name} v{config.app.version}
              </span>
            </div>
            <div className="flex justify-between items-center py-2">
              <span className="font-medium">Default Location</span>
              <span className="text-muted-foreground">
                India ({config.app.defaultLocation.lat}, {config.app.defaultLocation.lng})
              </span>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}