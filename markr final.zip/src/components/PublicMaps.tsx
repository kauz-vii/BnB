import { useState, useEffect } from 'react';
import { Globe, MapPin, Users, Star, Calendar, Search, Filter, Grid, List, Heart, Share, Eye, TrendingUp, Clock, Award } from 'lucide-react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Badge } from './ui/badge';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import type { User } from '@supabase/supabase-js';

interface PublicMap {
  id: string;
  title: string;
  description: string;
  creator: string;
  creatorId: string;
  creatorLevel: number;
  category: string;
  location: string;
  rating: number;
  reviewCount: number;
  markerCount: number;
  views: number;
  likes: number;
  tags: string[];
  createdAt: string;
  lastUpdated: string;
  thumbnail?: string;
  distance?: number;
  isFeatured: boolean;
  isLiked: boolean;
  isSaved: boolean;
}

interface PublicMapsProps {
  user: User | null;
}

export function PublicMaps({ user }: PublicMapsProps) {
  const [publicMaps, setPublicMaps] = useState<PublicMap[]>([]);
  const [filteredMaps, setFilteredMaps] = useState<PublicMap[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('all');
  const [sortBy, setSortBy] = useState('trending');
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const [activeTab, setActiveTab] = useState('all');
  const [loading, setLoading] = useState(true);

  // Mock data - will be replaced with Supabase queries
  const mockPublicMaps: PublicMap[] = [
    {
      id: '1',
      title: 'NYC Street Art Tour',
      description: 'Discover amazing street art and murals across all five boroughs of New York City',
      creator: 'ArtExplorer',
      creatorId: 'user1',
      creatorLevel: 15,
      category: 'Art & Culture',
      location: 'New York City',
      rating: 4.9,
      reviewCount: 342,
      markerCount: 45,
      views: 12540,
      likes: 1834,
      tags: ['street art', 'murals', 'culture', 'nyc', 'walking tour'],
      createdAt: '2024-01-10T08:00:00Z',
      lastUpdated: '2024-01-18T16:30:00Z',
      distance: 2.1,
      isFeatured: true,
      isLiked: false,
      isSaved: false
    },
    {
      id: '2',
      title: 'Food Truck Paradise',
      description: 'The ultimate guide to the best food trucks in Manhattan, from gourmet burgers to authentic tacos',
      creator: 'FoodieGuide',
      creatorId: 'user2',
      creatorLevel: 12,
      category: 'Food & Dining',
      location: 'Manhattan, NY',
      rating: 4.7,
      reviewCount: 298,
      markerCount: 28,
      views: 8934,
      likes: 1245,
      tags: ['food trucks', 'street food', 'manhattan', 'lunch', 'affordable'],
      createdAt: '2024-01-08T12:15:00Z',
      lastUpdated: '2024-01-20T10:45:00Z',
      distance: 1.5,
      isFeatured: false,
      isLiked: true,
      isSaved: true
    },
    {
      id: '3',
      title: 'Secret Rooftop Gardens',
      description: 'Hidden oases in the concrete jungle - discover beautiful rooftop gardens and terraces',
      creator: 'GreenThumb',
      creatorId: 'user3',
      creatorLevel: 18,
      category: 'Nature & Parks',
      location: 'Brooklyn, NY',
      rating: 4.8,
      reviewCount: 187,
      markerCount: 16,
      views: 6723,
      likes: 892,
      tags: ['rooftops', 'gardens', 'nature', 'brooklyn', 'peaceful'],
      createdAt: '2024-01-05T14:30:00Z',
      lastUpdated: '2024-01-15T09:20:00Z',
      distance: 3.2,
      isFeatured: true,
      isLiked: false,
      isSaved: false
    },
    {
      id: '4',
      title: 'Indie Bookstore Crawl',
      description: 'Support local business while discovering unique bookshops and literary cafes',
      creator: 'BookwormNYC',
      creatorId: 'user4',
      creatorLevel: 9,
      category: 'Shopping & Books',
      location: 'Various NYC',
      rating: 4.6,
      reviewCount: 156,
      markerCount: 22,
      views: 4521,
      likes: 634,
      tags: ['bookstores', 'indie', 'literature', 'coffee', 'quiet'],
      createdAt: '2024-01-03T11:00:00Z',
      lastUpdated: '2024-01-12T15:15:00Z',
      distance: 2.8,
      isFeatured: false,
      isLiked: false,
      isSaved: true
    },
    {
      id: '5',
      title: 'Night Photography Spots',
      description: 'Capture the magic of NYC after dark with these incredible night photography locations',
      creator: 'NightShooter',
      creatorId: 'user5',
      creatorLevel: 14,
      category: 'Photography',
      location: 'New York City',
      rating: 4.9,
      reviewCount: 203,
      markerCount: 18,
      views: 7845,
      likes: 1156,
      tags: ['night photography', 'cityscape', 'long exposure', 'instagram'],
      createdAt: '2024-01-01T20:00:00Z',
      lastUpdated: '2024-01-19T22:30:00Z',
      distance: 1.9,
      isFeatured: true,
      isLiked: true,
      isSaved: false
    },
    {
      id: '6',
      title: 'Craft Beer Trail',
      description: 'Explore the best craft breweries and beer bars across NYC boroughs',
      creator: 'BeerExplorer',
      creatorId: 'user6',
      creatorLevel: 11,
      category: 'Food & Dining',
      location: 'NYC Metro Area',
      rating: 4.5,
      reviewCount: 189,
      markerCount: 35,
      views: 5432,
      likes: 723,
      tags: ['craft beer', 'breweries', 'nightlife', 'social', 'weekend'],
      createdAt: '2023-12-28T18:00:00Z',
      lastUpdated: '2024-01-16T20:15:00Z',
      distance: 3.5,
      isFeatured: false,
      isLiked: false,
      isSaved: false
    },
    {
      id: '7',
      title: 'Free WiFi Spots',
      description: 'Digital nomad-friendly locations with reliable free WiFi and power outlets',
      creator: 'DigitalNomad',
      creatorId: 'user7',
      creatorLevel: 7,
      category: 'Entertainment',
      location: 'Manhattan, NY',
      rating: 4.4,
      reviewCount: 167,
      markerCount: 42,
      views: 6789,
      likes: 934,
      tags: ['wifi', 'coworking', 'digital nomad', 'remote work', 'productivity'],
      createdAt: '2024-01-07T10:30:00Z',
      lastUpdated: '2024-01-21T14:00:00Z',
      distance: 1.3,
      isFeatured: false,
      isLiked: true,
      isSaved: true
    },
    {
      id: '8',
      title: 'Dog-Friendly Adventures',
      description: 'Pet-friendly parks, restaurants, and activities for you and your furry friend',
      creator: 'PetLover',
      creatorId: 'user8',
      creatorLevel: 13,
      category: 'Nature & Parks',
      location: 'Various NYC',
      rating: 4.8,
      reviewCount: 278,
      markerCount: 26,
      views: 4567,
      likes: 1123,
      tags: ['dog friendly', 'pets', 'parks', 'outdoor', 'family'],
      createdAt: '2024-01-02T12:00:00Z',
      lastUpdated: '2024-01-14T16:30:00Z',
      distance: 2.7,
      isFeatured: true,
      isLiked: false,
      isSaved: true
    },
    {
      id: '9',
      title: 'Vintage Shopping Guide',
      description: 'Curated collection of vintage stores, thrift shops, and antique markets',
      creator: 'VintageHunter',
      creatorId: 'user9',
      creatorLevel: 10,
      category: 'Shopping & Books',
      location: 'Brooklyn & Manhattan',
      rating: 4.3,
      reviewCount: 145,
      markerCount: 19,
      views: 3456,
      likes: 567,
      tags: ['vintage', 'thrift', 'antiques', 'shopping', 'unique finds'],
      createdAt: '2023-12-30T14:45:00Z',
      lastUpdated: '2024-01-11T11:20:00Z',
      distance: 4.1,
      isFeatured: false,
      isLiked: false,
      isSaved: false
    },
    {
      id: '10',
      title: 'Fitness Parks & Outdoor Gyms',
      description: 'Free outdoor fitness equipment and calisthenics parks throughout the city',
      creator: 'FitnessFreak',
      creatorId: 'user10',
      creatorLevel: 16,
      category: 'Sports & Fitness',
      location: 'All 5 Boroughs',
      rating: 4.6,
      reviewCount: 223,
      markerCount: 31,
      views: 7890,
      likes: 1456,
      tags: ['fitness', 'outdoor gym', 'calisthenics', 'free', 'exercise'],
      createdAt: '2024-01-06T08:15:00Z',
      lastUpdated: '2024-01-22T07:30:00Z',
      distance: 2.4,
      isFeatured: true,
      isLiked: true,
      isSaved: false
    }
  ];

  useEffect(() => {
    // Simulate API call
    setTimeout(() => {
      setPublicMaps(mockPublicMaps);
      setFilteredMaps(mockPublicMaps);
      setLoading(false);
    }, 1000);
  }, []);

  useEffect(() => {
    let filtered = publicMaps;

    // Tab filter
    switch (activeTab) {
      case 'featured':
        filtered = filtered.filter(map => map.isFeatured);
        break;
      case 'liked':
        filtered = filtered.filter(map => map.isLiked);
        break;
      case 'recent':
        filtered = filtered.filter(map => {
          const daysSinceCreated = (Date.now() - new Date(map.createdAt).getTime()) / (1000 * 60 * 60 * 24);
          return daysSinceCreated <= 7;
        });
        break;
    }

    // Search filter
    if (searchQuery) {
      filtered = filtered.filter(map => 
        map.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        map.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
        map.creator.toLowerCase().includes(searchQuery.toLowerCase()) ||
        map.tags.some(tag => tag.toLowerCase().includes(searchQuery.toLowerCase()))
      );
    }

    // Category filter
    if (categoryFilter !== 'all') {
      filtered = filtered.filter(map => map.category === categoryFilter);
    }

    // Sort
    switch (sortBy) {
      case 'trending':
        // Sort by a combination of recent likes, views, and rating
        filtered.sort((a, b) => {
          const aScore = (a.likes * 0.3) + (a.views * 0.1) + (a.rating * 50);
          const bScore = (b.likes * 0.3) + (b.views * 0.1) + (b.rating * 50);
          return bScore - aScore;
        });
        break;
      case 'rating':
        filtered.sort((a, b) => b.rating - a.rating);
        break;
      case 'recent':
        filtered.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
        break;
      case 'popular':
        filtered.sort((a, b) => b.views - a.views);
        break;
      case 'distance':
        filtered.sort((a, b) => (a.distance || 0) - (b.distance || 0));
        break;
    }

    setFilteredMaps(filtered);
  }, [publicMaps, activeTab, searchQuery, categoryFilter, sortBy]);

  const categories = [
    'all', 'Art & Culture', 'Food & Dining', 'Nature & Parks', 
    'Photography', 'Shopping & Books', 'Entertainment', 'Sports & Fitness'
  ];

  const handleLikeMap = (mapId: string) => {
    setPublicMaps(maps => 
      maps.map(map => 
        map.id === mapId 
          ? { ...map, isLiked: !map.isLiked, likes: map.isLiked ? map.likes - 1 : map.likes + 1 }
          : map
      )
    );
  };

  const handleSaveMap = (mapId: string) => {
    setPublicMaps(maps => 
      maps.map(map => 
        map.id === mapId 
          ? { ...map, isSaved: !map.isSaved }
          : map
      )
    );
  };

  const getCreatorBadge = (level: number) => {
    if (level >= 15) return { text: 'Expert', color: 'bg-purple-100 text-purple-700 border-purple-200' };
    if (level >= 10) return { text: 'Advanced', color: 'bg-blue-100 text-blue-700 border-blue-200' };
    if (level >= 5) return { text: 'Explorer', color: 'bg-emerald-100 text-emerald-700 border-emerald-200' };
    return { text: 'New', color: 'bg-gray-100 text-gray-700 border-gray-200' };
  };

  return (
    <div className="h-full bg-gradient-to-br from-blue-50 via-indigo-50 to-emerald-50 dark:from-gray-900 dark:via-gray-800 dark:to-gray-900 p-6 overflow-y-auto">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Header */}
        <div className="glassmorphism rounded-2xl shadow-xl p-6 border border-white/20 dark:border-gray-700/20">
          <div className="flex items-center justify-between mb-6">
            <div>
              <h1 className="text-3xl font-bold bg-gradient-to-r from-blue-600 to-emerald-500 bg-clip-text text-transparent">
                Explore Public Maps
              </h1>
              <p className="text-slate-600 dark:text-gray-300 mt-2">Discover amazing places shared by the community</p>
            </div>
            <div className="flex items-center space-x-2">
              <Badge className="bg-gradient-to-r from-blue-500 to-emerald-500 text-white text-lg px-4 py-2">
                {publicMaps.length} Maps Available
              </Badge>
            </div>
          </div>

          {/* Tabs */}
          <Tabs value={activeTab} onValueChange={setActiveTab} className="mb-6">
            <TabsList className="grid w-full grid-cols-4 bg-slate-100 dark:bg-gray-700">
              <TabsTrigger value="all" className="flex items-center space-x-2">
                <Globe className="w-4 h-4" />
                <span>All Maps</span>
              </TabsTrigger>
              <TabsTrigger value="featured" className="flex items-center space-x-2">
                <Award className="w-4 h-4" />
                <span>Featured</span>
              </TabsTrigger>
              <TabsTrigger value="recent" className="flex items-center space-x-2">
                <Clock className="w-4 h-4" />
                <span>New This Week</span>
              </TabsTrigger>
              <TabsTrigger value="liked" className="flex items-center space-x-2">
                <Heart className="w-4 h-4" />
                <span>Liked by You</span>
              </TabsTrigger>
            </TabsList>
          </Tabs>

          {/* Search and Filters */}
          <div className="flex flex-col md:flex-row gap-4 items-center">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400 w-5 h-5" />
              <Input
                placeholder="Search maps, creators, or tags..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10 bg-white/70 border-white/30 focus:bg-white"
              />
            </div>
            
            <Select value={categoryFilter} onValueChange={setCategoryFilter}>
              <SelectTrigger className="w-full md:w-48 bg-white/70 border-white/30">
                <SelectValue placeholder="Category" />
              </SelectTrigger>
              <SelectContent>
                {categories.map(category => (
                  <SelectItem key={category} value={category}>
                    {category === 'all' ? 'All Categories' : category}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>

            <Select value={sortBy} onValueChange={setSortBy}>
              <SelectTrigger className="w-full md:w-48 bg-white/70 border-white/30">
                <SelectValue placeholder="Sort by" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="trending">Trending</SelectItem>
                <SelectItem value="rating">Highest Rated</SelectItem>
                <SelectItem value="recent">Most Recent</SelectItem>
                <SelectItem value="popular">Most Viewed</SelectItem>
                <SelectItem value="distance">Nearest</SelectItem>
              </SelectContent>
            </Select>

            <div className="flex bg-white/70 rounded-lg border border-white/30">
              <Button
                variant={viewMode === 'grid' ? 'default' : 'ghost'}
                size="sm"
                onClick={() => setViewMode('grid')}
                className="rounded-r-none"
              >
                <Grid className="w-4 h-4" />
              </Button>
              <Button
                variant={viewMode === 'list' ? 'default' : 'ghost'}
                size="sm"
                onClick={() => setViewMode('list')}
                className="rounded-l-none"
              >
                <List className="w-4 h-4" />
              </Button>
            </div>
          </div>
        </div>

        {/* Maps Grid/List */}
        <div className="glassmorphism rounded-2xl shadow-xl border border-white/20 dark:border-gray-700/20 p-6">
          {loading ? (
            <div className={`grid ${viewMode === 'grid' ? 'grid-cols-1 md:grid-cols-2 lg:grid-cols-3' : 'grid-cols-1'} gap-6`}>
              {[1, 2, 3, 4, 5, 6].map((i) => (
                <div key={i} className="animate-pulse">
                  <div className="h-64 bg-slate-200 rounded-xl"></div>
                </div>
              ))}
            </div>
          ) : (
            <>
              {filteredMaps.length > 0 ? (
                <div className={`grid ${viewMode === 'grid' ? 'grid-cols-1 md:grid-cols-2 lg:grid-cols-3' : 'grid-cols-1'} gap-6`}>
                  {filteredMaps.map((map) => (
                    <Card key={map.id} className={`hover-lift transition-all duration-200 hover:shadow-xl bg-white/60 backdrop-blur-sm border border-white/30 relative ${viewMode === 'list' ? 'flex flex-row' : ''}`}>
                      {map.isFeatured && (
                        <div className="absolute top-3 right-3 z-10">
                          <Badge className="bg-gradient-to-r from-yellow-400 to-orange-500 text-white">
                            <Award className="w-3 h-3 mr-1" />
                            Featured
                          </Badge>
                        </div>
                      )}
                      
                      {viewMode === 'grid' ? (
                        <>
                          <CardHeader className="pb-3">
                            <div className="flex items-start justify-between">
                              <div className="flex-1">
                                <CardTitle className="text-lg font-bold text-slate-800 line-clamp-1 pr-2">
                                  {map.title}
                                </CardTitle>
                                <div className="flex items-center space-x-2 mt-1">
                                  <p className="text-sm text-slate-600">by {map.creator}</p>
                                  <Badge className={`text-xs ${getCreatorBadge(map.creatorLevel).color}`}>
                                    {getCreatorBadge(map.creatorLevel).text}
                                  </Badge>
                                </div>
                              </div>
                            </div>
                          </CardHeader>
                          <CardContent className="pt-0">
                            <p className="text-sm text-slate-600 line-clamp-2 mb-4">
                              {map.description}
                            </p>
                            
                            <div className="space-y-3">
                              <div className="flex items-center justify-between text-sm">
                                <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-200">
                                  {map.category}
                                </Badge>
                                <div className="flex items-center space-x-1 text-yellow-600">
                                  <Star className="w-4 h-4 fill-current" />
                                  <span className="font-medium">{map.rating}</span>
                                  <span className="text-slate-500">({map.reviewCount})</span>
                                </div>
                              </div>
                              
                              <div className="grid grid-cols-2 gap-2 text-sm text-slate-500">
                                <div className="flex items-center space-x-1">
                                  <MapPin className="w-4 h-4" />
                                  <span>{map.markerCount} markers</span>
                                </div>
                                <div className="flex items-center space-x-1">
                                  <Eye className="w-4 h-4" />
                                  <span>{map.views.toLocaleString()}</span>
                                </div>
                                {map.distance && (
                                  <div className="flex items-center space-x-1">
                                    <span>{map.distance} km away</span>
                                  </div>
                                )}
                                <div className="flex items-center space-x-1">
                                  <Calendar className="w-4 h-4" />
                                  <span>{new Date(map.createdAt).toLocaleDateString()}</span>
                                </div>
                              </div>
                              
                              <div className="flex flex-wrap gap-1 mt-2">
                                {map.tags.slice(0, 3).map(tag => (
                                  <Badge key={tag} variant="secondary" className="text-xs bg-slate-100 text-slate-600">
                                    #{tag}
                                  </Badge>
                                ))}
                                {map.tags.length > 3 && (
                                  <Badge variant="secondary" className="text-xs bg-slate-100 text-slate-600">
                                    +{map.tags.length - 3}
                                  </Badge>
                                )}
                              </div>

                              <div className="flex items-center justify-between pt-2 border-t border-slate-200">
                                <div className="flex space-x-2">
                                  <Button
                                    variant="ghost"
                                    size="sm"
                                    onClick={() => handleLikeMap(map.id)}
                                    className={`p-2 ${map.isLiked ? 'text-red-500' : 'text-slate-500'}`}
                                  >
                                    <Heart className={`w-4 h-4 ${map.isLiked ? 'fill-current' : ''}`} />
                                    <span className="ml-1">{map.likes}</span>
                                  </Button>
                                  <Button variant="ghost" size="sm" className="p-2 text-slate-500">
                                    <Share className="w-4 h-4" />
                                  </Button>
                                </div>
                                <Button
                                  variant="outline"
                                  size="sm"
                                  onClick={() => handleSaveMap(map.id)}
                                  className={`${map.isSaved ? 'bg-blue-100 text-blue-700 border-blue-300' : ''}`}
                                >
                                  {map.isSaved ? 'Saved' : 'Save'}
                                </Button>
                              </div>
                            </div>
                          </CardContent>
                        </>
                      ) : (
                        <CardContent className="p-6 flex items-center space-x-6 w-full">
                          <div className="flex-1">
                            <div className="flex items-start justify-between mb-2">
                              <div>
                                <h3 className="font-bold text-lg text-slate-800">{map.title}</h3>
                                <div className="flex items-center space-x-2 mt-1">
                                  <p className="text-sm text-slate-600">by {map.creator}</p>
                                  <Badge className={`text-xs ${getCreatorBadge(map.creatorLevel).color}`}>
                                    {getCreatorBadge(map.creatorLevel).text}
                                  </Badge>
                                </div>
                              </div>
                              <div className="flex items-center space-x-2">
                                <div className="flex items-center space-x-1 text-yellow-600">
                                  <Star className="w-4 h-4 fill-current" />
                                  <span className="font-medium">{map.rating}</span>
                                </div>
                                <Button
                                  variant="outline"
                                  size="sm"
                                  onClick={() => handleSaveMap(map.id)}
                                  className={`${map.isSaved ? 'bg-blue-100 text-blue-700 border-blue-300' : ''}`}
                                >
                                  {map.isSaved ? 'Saved' : 'Save'}
                                </Button>
                              </div>
                            </div>
                            
                            <p className="text-slate-600 mb-3 line-clamp-2">{map.description}</p>
                            
                            <div className="flex items-center justify-between">
                              <div className="flex items-center space-x-4 text-sm text-slate-500">
                                <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-200">
                                  {map.category}
                                </Badge>
                                <div className="flex items-center space-x-1">
                                  <MapPin className="w-4 h-4" />
                                  <span>{map.markerCount} markers</span>
                                </div>
                                <div className="flex items-center space-x-1">
                                  <Eye className="w-4 h-4" />
                                  <span>{map.views.toLocaleString()} views</span>
                                </div>
                                {map.distance && <span>{map.distance} km away</span>}
                              </div>
                              
                              <div className="flex items-center space-x-2">
                                <Button
                                  variant="ghost"
                                  size="sm"
                                  onClick={() => handleLikeMap(map.id)}
                                  className={`p-2 ${map.isLiked ? 'text-red-500' : 'text-slate-500'}`}
                                >
                                  <Heart className={`w-4 h-4 ${map.isLiked ? 'fill-current' : ''}`} />
                                  <span className="ml-1">{map.likes}</span>
                                </Button>
                                <Button variant="ghost" size="sm" className="p-2 text-slate-500">
                                  <Share className="w-4 h-4" />
                                </Button>
                              </div>
                            </div>
                          </div>
                        </CardContent>
                      )}
                    </Card>
                  ))}
                </div>
              ) : (
                <div className="text-center py-12">
                  <div className="w-16 h-16 bg-slate-200 rounded-full flex items-center justify-center mx-auto mb-4">
                    <Globe className="w-8 h-8 text-slate-400" />
                  </div>
                  <h3 className="font-semibold text-slate-600 mb-2">No maps found</h3>
                  <p className="text-slate-500 mb-4">
                    {searchQuery || categoryFilter !== 'all' 
                      ? 'Try adjusting your search or filters'
                      : 'Be the first to create a public map'
                    }
                  </p>
                  <Button className="bg-gradient-to-r from-blue-600 to-emerald-500 hover:from-blue-700 hover:to-emerald-600">
                    Create Map
                  </Button>
                </div>
              )}
            </>
          )}
        </div>
      </div>
    </div>
  );
}