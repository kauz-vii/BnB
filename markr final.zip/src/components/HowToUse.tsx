import { useState } from 'react';
import { Button } from './ui/button';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { 
  MapPin, 
  Users, 
  Star, 
  Shield, 
  Search, 
  Plus, 
  Navigation,
  Trophy,
  Heart,
  AlertTriangle,
  Camera,
  Coffee,
  Home,
  Hospital,
  ShoppingBag,
  X,
  ChevronLeft,
  ChevronRight,
  Lightbulb,
  Target,
  Globe
} from 'lucide-react';

interface HowToUseProps {
  isOpen: boolean;
  onClose: () => void;
  isFirstTime?: boolean;
}

export function HowToUse({ isOpen, onClose, isFirstTime = false }: HowToUseProps) {
  const [currentSlide, setCurrentSlide] = useState(0);

  if (!isOpen) return null;

  const slides = [
    {
      title: "Welcome to Markr",
      subtitle: "Your Community-Driven Map Platform",
      icon: <MapPin className="w-12 h-12 text-blue-500" />,
      content: (
        <div className="space-y-6">
          <div className="text-center">
            <div className="w-20 h-20 bg-gradient-to-r from-blue-500 to-emerald-500 rounded-full mx-auto mb-4 flex items-center justify-center">
              <MapPin className="w-10 h-10 text-white" />
            </div>
            <p className="text-gray-600 dark:text-gray-300 leading-relaxed">
              Imagine you're a tourist visiting a new city. You've just reached a huge park near a university, but you're clueless—
              <br /><br />
              <span className="text-orange-600 font-medium">Where are the food stalls?</span>
              <br />
              <span className="text-blue-600 font-medium">Where's the clean drinking water?</span>
              <br />
              <span className="text-purple-600 font-medium">Is there a toilet nearby?</span>
            </p>
          </div>
          <div className="bg-yellow-50 dark:bg-yellow-900/20 p-4 rounded-lg border border-yellow-200 dark:border-yellow-800">
            <div className="flex items-start gap-3">
              <Lightbulb className="w-6 h-6 text-yellow-600 flex-shrink-0 mt-1" />
              <div>
                <h4 className="font-medium text-yellow-800 dark:text-yellow-200 mb-2">The Problem</h4>
                <p className="text-yellow-700 dark:text-yellow-300 text-sm">
                  You open Google Maps, but all you see are big landmarks. The small things—the things that actually matter—are missing.
                </p>
              </div>
            </div>
          </div>
        </div>
      )
    },
    {
      title: "Emergency Situations",
      subtitle: "When Every Second Counts",
      icon: <Shield className="w-12 h-12 text-red-500" />,
      content: (
        <div className="space-y-6">
          <div className="text-center">
            <div className="w-20 h-20 bg-gradient-to-r from-red-500 to-orange-500 rounded-full mx-auto mb-4 flex items-center justify-center">
              <AlertTriangle className="w-10 h-10 text-white" />
            </div>
            <p className="text-gray-600 dark:text-gray-300 leading-relaxed">
              Now imagine you're in an emergency situation. A flood just hit your city. Roads are blocked, electricity is gone, and nobody knows where to find safe shelters or relief camps.
            </p>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div className="bg-red-50 dark:bg-red-900/20 p-4 rounded-lg border border-red-200 dark:border-red-800">
              <div className="flex items-center gap-2 mb-2">
                <Shield className="w-5 h-5 text-red-600" />
                <h4 className="font-medium text-red-800 dark:text-red-200">Safe Shelters</h4>
              </div>
              <p className="text-red-700 dark:text-red-300 text-sm">Find emergency shelters and safe gathering points</p>
            </div>
            <div className="bg-blue-50 dark:bg-blue-900/20 p-4 rounded-lg border border-blue-200 dark:border-blue-800">
              <div className="flex items-center gap-2 mb-2">
                <Heart className="w-5 h-5 text-blue-600" />
                <h4 className="font-medium text-blue-800 dark:text-blue-200">Medical Help</h4>
              </div>
              <p className="text-blue-700 dark:text-blue-300 text-sm">Locate medical camps and emergency services</p>
            </div>
            <div className="bg-green-50 dark:bg-green-900/20 p-4 rounded-lg border border-green-200 dark:border-green-800">
              <div className="flex items-center gap-2 mb-2">
                <Coffee className="w-5 h-5 text-green-600" />
                <h4 className="font-medium text-green-800 dark:text-green-200">Food & Water</h4>
              </div>
              <p className="text-green-700 dark:text-green-300 text-sm">Find free food centers and clean water sources</p>
            </div>
            <div className="bg-purple-50 dark:bg-purple-900/20 p-4 rounded-lg border border-purple-200 dark:border-purple-800">
              <div className="flex items-center gap-2 mb-2">
                <Navigation className="w-5 h-5 text-purple-600" />
                <h4 className="font-medium text-purple-800 dark:text-purple-200">Safe Routes</h4>
              </div>
              <p className="text-purple-700 dark:text-purple-300 text-sm">Real-time updates on blocked roads</p>
            </div>
          </div>
        </div>
      )
    },
    {
      title: "Our Solution",
      subtitle: "A Decentralized Social Map Platform",
      icon: <Globe className="w-12 h-12 text-emerald-500" />,
      content: (
        <div className="space-y-6">
          <div className="text-center">
            <div className="w-20 h-20 bg-gradient-to-r from-emerald-500 to-blue-500 rounded-full mx-auto mb-4 flex items-center justify-center">
              <Users className="w-10 h-10 text-white" />
            </div>
            <p className="text-gray-600 dark:text-gray-300 leading-relaxed mb-6">
              What if there was one single platform where everyday people—locals, travelers, volunteers—could contribute real-time information and help others immediately?
            </p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="bg-gradient-to-br from-blue-50 to-blue-100 dark:from-blue-900/20 dark:to-blue-800/20 p-4 rounded-lg border border-blue-200 dark:border-blue-700">
              <div className="flex items-center gap-2 mb-3">
                <Plus className="w-5 h-5 text-blue-600" />
                <h4 className="font-medium text-blue-800 dark:text-blue-200">Create Custom Maps</h4>
              </div>
              <p className="text-blue-700 dark:text-blue-300 text-sm">Mark spots like food stalls, shops, toilets, hiking spots, or hidden gems in your area</p>
            </div>
            <div className="bg-gradient-to-br from-emerald-50 to-emerald-100 dark:from-emerald-900/20 dark:to-emerald-800/20 p-4 rounded-lg border border-emerald-200 dark:border-emerald-700">
              <div className="flex items-center gap-2 mb-3">
                <Globe className="w-5 h-5 text-emerald-600" />
                <h4 className="font-medium text-emerald-800 dark:text-emerald-200">Share Publicly</h4>
              </div>
              <p className="text-emerald-700 dark:text-emerald-300 text-sm">Share your maps publicly or keep them private for personal use</p>
            </div>
            <div className="bg-gradient-to-br from-purple-50 to-purple-100 dark:from-purple-900/20 dark:to-purple-800/20 p-4 rounded-lg border border-purple-200 dark:border-purple-700">
              <div className="flex items-center gap-2 mb-3">
                <Star className="w-5 h-5 text-purple-600" />
                <h4 className="font-medium text-purple-800 dark:text-purple-200">Rate & Review</h4>
              </div>
              <p className="text-purple-700 dark:text-purple-300 text-sm">Rate and review other maps to maintain authenticity and quality</p>
            </div>
            <div className="bg-gradient-to-br from-orange-50 to-orange-100 dark:from-orange-900/20 dark:to-orange-800/20 p-4 rounded-lg border border-orange-200 dark:border-orange-700">
              <div className="flex items-center gap-2 mb-3">
                <Shield className="w-5 h-5 text-orange-600" />
                <h4 className="font-medium text-orange-800 dark:text-orange-200">Emergency Response</h4>
              </div>
              <p className="text-orange-700 dark:text-orange-300 text-sm">Instantly mark safe shelters, medical camps, and relief centers during disasters</p>
            </div>
          </div>
        </div>
      )
    },
    {
      title: "Key Features",
      subtitle: "How Markr Works",
      icon: <Target className="w-12 h-12 text-indigo-500" />,
      content: (
        <div className="space-y-6">
          <div className="grid grid-cols-1 gap-4">
            <div className="bg-gradient-to-r from-blue-50 to-indigo-50 dark:from-blue-900/20 dark:to-indigo-900/20 p-4 rounded-lg border border-blue-200 dark:border-blue-700">
              <div className="flex items-start gap-4">
                <div className="w-10 h-10 bg-blue-500 rounded-full flex items-center justify-center flex-shrink-0">
                  <Search className="w-5 h-5 text-white" />
                </div>
                <div>
                  <h4 className="font-medium text-blue-800 dark:text-blue-200 mb-2">Search Locations</h4>
                  <p className="text-blue-700 dark:text-blue-300 text-sm">Use the search bar on the map to find any location quickly and navigate with ease</p>
                </div>
              </div>
            </div>
            <div className="bg-gradient-to-r from-emerald-50 to-green-50 dark:from-emerald-900/20 dark:to-green-900/20 p-4 rounded-lg border border-emerald-200 dark:border-emerald-700">
              <div className="flex items-start gap-4">
                <div className="w-10 h-10 bg-emerald-500 rounded-full flex items-center justify-center flex-shrink-0">
                  <MapPin className="w-5 h-5 text-white" />
                </div>
                <div>
                  <h4 className="font-medium text-emerald-800 dark:text-emerald-200 mb-2">Add Markers</h4>
                  <p className="text-emerald-700 dark:text-emerald-300 text-sm">Click anywhere on the map to add markers for food, shelter, attractions, or any point of interest</p>
                </div>
              </div>
            </div>
            <div className="bg-gradient-to-r from-purple-50 to-pink-50 dark:from-purple-900/20 dark:to-pink-900/20 p-4 rounded-lg border border-purple-200 dark:border-purple-700">
              <div className="flex items-start gap-4">
                <div className="w-10 h-10 bg-purple-500 rounded-full flex items-center justify-center flex-shrink-0">
                  <Trophy className="w-5 h-5 text-white" />
                </div>
                <div>
                  <h4 className="font-medium text-purple-800 dark:text-purple-200 mb-2">Earn XP & Achievements</h4>
                  <p className="text-purple-700 dark:text-purple-300 text-sm">Level up and earn achievements as you explore, contribute maps, and help the community</p>
                </div>
              </div>
            </div>
            <div className="bg-gradient-to-r from-red-50 to-orange-50 dark:from-red-900/20 dark:to-orange-900/20 p-4 rounded-lg border border-red-200 dark:border-red-700">
              <div className="flex items-start gap-4">
                <div className="w-10 h-10 bg-red-500 rounded-full flex items-center justify-center flex-shrink-0">
                  <Shield className="w-5 h-5 text-white" />
                </div>
                <div>
                  <h4 className="font-medium text-red-800 dark:text-red-200 mb-2">Relief Points</h4>
                  <p className="text-red-700 dark:text-red-300 text-sm">Access emergency relief points across major Indian cities with real-time disaster management info</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      )
    },
    {
      title: "Disaster Response Examples",
      subtitle: "Real-World Applications",
      icon: <Shield className="w-12 h-12 text-orange-500" />,
      content: (
        <div className="space-y-6">
          <div className="text-center mb-6">
            <div className="w-20 h-20 bg-gradient-to-r from-orange-500 to-red-500 rounded-full mx-auto mb-4 flex items-center justify-center">
              <AlertTriangle className="w-10 h-10 text-white" />
            </div>
            <p className="text-gray-600 dark:text-gray-300">
              During disasters, information saves lives. Here's how Markr helps:
            </p>
          </div>
          <div className="grid grid-cols-1 gap-4">
            <div className="bg-blue-50 dark:bg-blue-900/20 p-4 rounded-lg border-l-4 border-blue-500">
              <div className="flex items-start gap-3">
                <div className="w-8 h-8 bg-blue-500 rounded-full flex items-center justify-center flex-shrink-0">
                  <Navigation className="w-4 h-4 text-white" />
                </div>
                <div>
                  <h4 className="font-medium text-blue-800 dark:text-blue-200 mb-1">During Floods</h4>
                  <p className="text-blue-700 dark:text-blue-300 text-sm">Volunteers can mark where boats are available for rescue and safe evacuation routes</p>
                </div>
              </div>
            </div>
            <div className="bg-red-50 dark:bg-red-900/20 p-4 rounded-lg border-l-4 border-red-500">
              <div className="flex items-start gap-3">
                <div className="w-8 h-8 bg-red-500 rounded-full flex items-center justify-center flex-shrink-0">
                  <Home className="w-4 h-4 text-white" />
                </div>
                <div>
                  <h4 className="font-medium text-red-800 dark:text-red-200 mb-1">During Earthquakes</h4>
                  <p className="text-red-700 dark:text-red-300 text-sm">People can mark safe gathering spots and temporary shelter locations</p>
                </div>
              </div>
            </div>
            <div className="bg-green-50 dark:bg-green-900/20 p-4 rounded-lg border-l-4 border-green-500">
              <div className="flex items-start gap-3">
                <div className="w-8 h-8 bg-green-500 rounded-full flex items-center justify-center flex-shrink-0">
                  <Coffee className="w-4 h-4 text-white" />
                </div>
                <div>
                  <h4 className="font-medium text-green-800 dark:text-green-200 mb-1">Community Langars</h4>
                  <p className="text-green-700 dark:text-green-300 text-sm">During community efforts, users can mark where free food is being served</p>
                </div>
              </div>
            </div>
          </div>
          <div className="bg-gradient-to-r from-amber-50 to-orange-50 dark:from-amber-900/20 dark:to-orange-900/20 p-4 rounded-lg border border-amber-200 dark:border-amber-700">
            <div className="flex items-start gap-3">
              <Lightbulb className="w-6 h-6 text-amber-600 flex-shrink-0 mt-1" />
              <div>
                <h4 className="font-medium text-amber-800 dark:text-amber-200 mb-2">Dynamic Disaster Map</h4>
                <p className="text-amber-700 dark:text-amber-300 text-sm">
                  This creates a living disaster map, updated by the people, for the people—providing real-time ground-level information when it matters most.
                </p>
              </div>
            </div>
          </div>
        </div>
      )
    },
    {
      title: "Why It Matters",
      subtitle: "Building a Better Community",
      icon: <Heart className="w-12 h-12 text-pink-500" />,
      content: (
        <div className="space-y-6">
          <div className="text-center mb-6">
            <div className="w-20 h-20 bg-gradient-to-r from-pink-500 to-purple-500 rounded-full mx-auto mb-4 flex items-center justify-center">
              <Heart className="w-10 h-10 text-white" />
            </div>
          </div>
          <div className="grid grid-cols-1 gap-4">
            <div className="bg-gradient-to-r from-blue-50 to-indigo-50 dark:from-blue-900/20 dark:to-indigo-900/20 p-6 rounded-xl border border-blue-200 dark:border-blue-700">
              <div className="flex items-start gap-4">
                <Camera className="w-8 h-8 text-blue-600 flex-shrink-0" />
                <div>
                  <h4 className="font-medium text-blue-800 dark:text-blue-200 mb-2">For Travelers</h4>
                  <p className="text-blue-700 dark:text-blue-300 text-sm">No more struggling to find hidden gems or essentials. Discover places through local eyes.</p>
                </div>
              </div>
            </div>
            <div className="bg-gradient-to-r from-emerald-50 to-green-50 dark:from-emerald-900/20 dark:to-green-900/20 p-6 rounded-xl border border-emerald-200 dark:border-emerald-700">
              <div className="flex items-start gap-4">
                <Home className="w-8 h-8 text-emerald-600 flex-shrink-0" />
                <div>
                  <h4 className="font-medium text-emerald-800 dark:text-emerald-200 mb-2">For Locals</h4>
                  <p className="text-emerald-700 dark:text-emerald-300 text-sm">Share your knowledge of your city and help others while earning recognition.</p>
                </div>
              </div>
            </div>
            <div className="bg-gradient-to-r from-red-50 to-orange-50 dark:from-red-900/20 dark:to-orange-900/20 p-6 rounded-xl border border-red-200 dark:border-red-700">
              <div className="flex items-start gap-4">
                <Shield className="w-8 h-8 text-red-600 flex-shrink-0" />
                <div>
                  <h4 className="font-medium text-red-800 dark:text-red-200 mb-2">For Disaster Management</h4>
                  <p className="text-red-700 dark:text-red-300 text-sm">A people-powered safety net during crises with real-time ground updates.</p>
                </div>
              </div>
            </div>
          </div>
          <div className="bg-gradient-to-r from-purple-100 to-pink-100 dark:from-purple-900/30 dark:to-pink-900/30 p-6 rounded-xl border-2 border-purple-200 dark:border-purple-700">
            <div className="text-center">
              <h4 className="font-bold text-purple-800 dark:text-purple-200 mb-3 text-lg">Our Vision</h4>
              <p className="text-purple-700 dark:text-purple-300 italic leading-relaxed">
                "Maps should not just show us where we are. They should guide us to what we truly need—whether it's an adventure, a hidden food stall, or a safe shelter in the middle of a disaster. And that's exactly what Markr does."
              </p>
            </div>
          </div>
        </div>
      )
    }
  ];

  const totalSlides = slides.length;

  const nextSlide = () => {
    setCurrentSlide((prev) => (prev + 1) % totalSlides);
  };

  const prevSlide = () => {
    setCurrentSlide((prev) => (prev - 1 + totalSlides) % totalSlides);
  };

  const goToSlide = (index: number) => {
    setCurrentSlide(index);
  };

  return (
    <div className="fixed inset-0 z-[9999] bg-black/60 backdrop-blur-sm flex items-center justify-center p-4">
      <Card className="w-full max-w-4xl max-h-[90vh] overflow-hidden glassmorphism border-white/20 dark:border-gray-700/20 shadow-2xl">
        <CardHeader className="relative border-b border-white/20 dark:border-gray-700/20 bg-gradient-to-r from-blue-50/80 to-emerald-50/80 dark:from-blue-900/20 dark:to-emerald-900/20">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              {slides[currentSlide].icon}
              <div>
                <CardTitle className="text-xl text-gray-900 dark:text-gray-100">
                  {slides[currentSlide].title}
                </CardTitle>
                <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">
                  {slides[currentSlide].subtitle}
                </p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              {isFirstTime && (
                <Badge variant="secondary" className="bg-yellow-100 text-yellow-800 dark:bg-yellow-900/30 dark:text-yellow-200">
                  First Time Setup
                </Badge>
              )}
              <Button
                onClick={onClose}
                variant="ghost"
                size="sm"
                className="h-8 w-8 p-0 hover:bg-red-100 dark:hover:bg-red-900/20"
              >
                <X className="w-4 h-4" />
              </Button>
            </div>
          </div>
        </CardHeader>
        
        <CardContent className="p-0 flex-1 overflow-auto">
          <div className="p-6 min-h-[400px]">
            {slides[currentSlide].content}
          </div>
          
          {/* Slide indicators */}
          <div className="flex justify-center gap-2 p-4 bg-gray-50/50 dark:bg-gray-800/50">
            {slides.map((_, index) => (
              <button
                key={index}
                onClick={() => goToSlide(index)}
                className={`w-3 h-3 rounded-full transition-all duration-200 ${
                  index === currentSlide 
                    ? 'bg-blue-500 w-8' 
                    : 'bg-gray-300 dark:bg-gray-600 hover:bg-gray-400 dark:hover:bg-gray-500'
                }`}
              />
            ))}
          </div>
        </CardContent>
        
        <div className="border-t border-white/20 dark:border-gray-700/20 p-4 bg-gradient-to-r from-blue-50/50 to-emerald-50/50 dark:from-blue-900/20 dark:to-emerald-900/20">
          <div className="flex items-center justify-between">
            <Button
              onClick={prevSlide}
              variant="outline"
              size="sm"
              disabled={currentSlide === 0}
              className="flex items-center gap-2"
            >
              <ChevronLeft className="w-4 h-4" />
              Previous
            </Button>
            
            <div className="text-sm text-gray-600 dark:text-gray-400">
              {currentSlide + 1} of {totalSlides}
            </div>
            
            {currentSlide === totalSlides - 1 ? (
              <Button
                onClick={onClose}
                className="bg-gradient-to-r from-blue-600 to-emerald-500 hover:from-blue-700 hover:to-emerald-600 text-white flex items-center gap-2"
              >
                {isFirstTime ? 'Start Exploring' : 'Got It'}
                <Target className="w-4 h-4" />
              </Button>
            ) : (
              <Button
                onClick={nextSlide}
                variant="outline"
                size="sm"
                className="flex items-center gap-2"
              >
                Next
                <ChevronRight className="w-4 h-4" />
              </Button>
            )}
          </div>
        </div>
      </Card>
    </div>
  );
}