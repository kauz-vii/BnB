import { 
  ChevronLeft, 
  ChevronRight, 
  Plus, 
  MapPin, 
  Bookmark, 
  Globe, 
  Compass, 
  TrendingUp,
  Award,
  BarChart3,
  Target,
  Shield,
  Database
} from 'lucide-react';
import { Button } from './ui/button';
import type { User } from '@supabase/supabase-js';

interface UserProfile {
  id: string;
  name: string;
  email: string;
  level: number;
  xp: number;
  totalDistance: number;
  placesExplored: number;
  mapsContributed: number;
  achievements: string[];
  createdAt: string;
}

type ViewType = 'explore' | 'profile' | 'leaderboard' | 'public-maps' | 'nearby-places' | 'trending-maps' | 'my-contributions' | 'saved-maps' | 'backend-test' | 'backend-integration' | 'relief-points';

interface SidebarProps {
  isCollapsed: boolean;
  onToggleCollapse: () => void;
  onCreateMap: () => void;
  currentView: ViewType;
  onViewChange: (view: ViewType) => void;
  user: User | null;
  profile: UserProfile | null;
}

export function Sidebar({ 
  isCollapsed, 
  onToggleCollapse, 
  onCreateMap,
  currentView,
  onViewChange,
  user,
  profile
}: SidebarProps) {
  const sidebarWidth = isCollapsed ? 'w-16' : 'w-72 md:w-72 w-full max-w-xs';

  const sections = [
    {
      title: user ? 'My Maps' : 'Get Started',
      items: user ? [
        { icon: Plus, label: 'Create Map', action: onCreateMap },
        { icon: MapPin, label: 'My Contributions', action: () => onViewChange('my-contributions') },
        { icon: Bookmark, label: 'Saved Maps', action: () => onViewChange('saved-maps') },
      ] : [
        { icon: Plus, label: 'Sign Up to Create', action: onCreateMap, disabled: true },
      ]
    },
    {
      title: 'Discover',
      items: [
        { icon: Globe, label: 'Public Maps', action: () => onViewChange('public-maps') },
        { icon: Compass, label: 'Nearby Places', action: () => onViewChange('nearby-places') },
        { icon: TrendingUp, label: 'Trending Maps', action: () => onViewChange('trending-maps') },
        { icon: Shield, label: 'Relief Points', action: () => onViewChange('relief-points') },
        { icon: Globe, label: 'Backend Test', action: () => onViewChange('backend-test') },
        { icon: Database, label: 'Backend Integration', action: () => onViewChange('backend-integration') },
      ]
    },
    {
      title: user ? 'Gamification' : 'Join Community',
      items: user ? [
        { icon: Award, label: 'Achievements', action: () => onViewChange('profile') },
        { icon: BarChart3, label: 'XP Progress', action: () => onViewChange('profile') },
        { icon: Target, label: 'Levels', action: () => onViewChange('profile') },
      ] : [
        { icon: Award, label: 'Unlock Achievements', action: () => onViewChange('profile'), disabled: true },
        { icon: BarChart3, label: 'Track Your Progress', action: () => onViewChange('profile'), disabled: true },
      ]
    }
  ];

  const isActiveItem = (label: string) => {
    return (
      (label === 'Public Maps' && currentView === 'public-maps') ||
      (label === 'Nearby Places' && currentView === 'nearby-places') ||
      (label === 'Trending Maps' && currentView === 'trending-maps') ||
      (label === 'My Contributions' && currentView === 'my-contributions') ||
      (label === 'Saved Maps' && currentView === 'saved-maps') ||
      (label === 'Achievements' && currentView === 'profile') ||
      (label === 'XP Progress' && currentView === 'profile') ||
      (label === 'Levels' && currentView === 'profile') ||
      (label === 'Relief Points' && currentView === 'relief-points') ||
      (label === 'Backend Test' && currentView === 'backend-test') ||
      (label === 'Backend Integration' && currentView === 'backend-integration')
    );
  };

  return (
    <aside className={`${sidebarWidth} glassmorphism border-r border-white/20 dark:border-gray-700/20 transition-all duration-300 ease-in-out flex flex-col shadow-xl md:relative fixed md:translate-x-0 ${isCollapsed ? '-translate-x-full md:translate-x-0' : 'translate-x-0'} z-40 h-full`}>
      {/* Collapse Toggle */}
      <div className="flex items-center justify-between p-4 border-b border-white/20">
        {!isCollapsed && (
          <span className="font-semibold text-slate-800 dark:text-white bg-gradient-to-r from-blue-600 to-emerald-500 bg-clip-text text-transparent">
            Navigation
          </span>
        )}
        <Button
          variant="ghost"
          size="sm"
          onClick={onToggleCollapse}
          className="p-2 h-10 w-10 hover:bg-blue-50 dark:hover:bg-gray-700 rounded-xl transition-all duration-200 hover-lift"
        >
          {isCollapsed ? (
            <ChevronRight className="w-5 h-5 text-blue-600" />
          ) : (
            <ChevronLeft className="w-5 h-5 text-blue-600" />
          )}
        </Button>
      </div>

      {/* Navigation Sections */}
      <div className="flex-1 overflow-y-auto p-4 space-y-6">
        {sections.map((section, sectionIndex) => (
          <div key={sectionIndex} className="space-y-3">
            {!isCollapsed && (
              <h3 className="text-sm font-bold text-slate-600 dark:text-gray-300 uppercase tracking-wider px-3 bg-gradient-to-r from-blue-600 to-emerald-500 bg-clip-text text-transparent">
                {section.title}
              </h3>
            )}
            <div className="space-y-2">
              {section.items.map((item, itemIndex) => (
                <button
                  key={itemIndex}
                  onClick={item.action}
                  className={`w-full flex items-center space-x-4 px-4 py-3 rounded-xl text-left transition-all duration-200 hover:bg-gradient-to-r hover:from-blue-50 hover:to-emerald-50 dark:hover:from-gray-700 dark:hover:to-gray-600 hover:shadow-md hover-lift group ${
                    isCollapsed ? 'justify-center' : ''
                  } ${item.label === 'Create Map' && user ? 'bg-gradient-to-r from-blue-500 to-emerald-500 text-white hover:from-blue-600 hover:to-emerald-600' : ''} ${item.disabled ? 'opacity-60 cursor-not-allowed' : ''} ${
                    isActiveItem(item.label) ? 'bg-blue-100 dark:bg-gray-700 border-l-4 border-blue-500' : ''
                  }`}
                  title={isCollapsed ? item.label : undefined}
                >
                  <item.icon className={`w-5 h-5 transition-colors ${
                    item.label === 'Create Map' && user
                      ? 'text-white' 
                      : 'text-slate-600 dark:text-gray-300 group-hover:text-blue-600'
                  }`} />
                  {!isCollapsed && (
                    <span className={`font-medium transition-colors ${
                      item.label === 'Create Map' && user
                        ? 'text-white'
                        : 'text-slate-700 dark:text-gray-300 group-hover:text-slate-900 dark:group-hover:text-white'
                    }`}>
                      {item.label}
                    </span>
                  )}
                </button>
              ))}
            </div>
          </div>
        ))}
      </div>

      {/* User XP Progress (collapsed state) */}
      {!isCollapsed && user && profile && (
        <div className="p-4 border-t border-white/20 bg-gradient-to-r from-blue-50/80 to-emerald-50/80 backdrop-blur-md">
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <span className="font-bold text-slate-800 bg-gradient-to-r from-blue-600 to-emerald-500 bg-clip-text text-transparent">
                Level {profile.level} Explorer
              </span>
              <span className="text-sm font-semibold text-slate-600 bg-white/70 px-2 py-1 rounded-lg">
                {profile.xp.toLocaleString()} XP
              </span>
            </div>
            <div className="w-full bg-white/50 rounded-full h-3 backdrop-blur-sm">
              <div 
                className="bg-gradient-to-r from-blue-600 to-emerald-500 h-3 rounded-full transition-all duration-500 xp-progress shadow-sm"
                style={{ width: `${Math.min(100, (profile.xp % 1000) / 10)}%` }}
              ></div>
            </div>
            <p className="text-xs text-slate-600 text-center bg-white/50 py-1 px-2 rounded-lg">
              {1000 - (profile.xp % 1000)} XP to next level
            </p>
          </div>
        </div>
      )}
    </aside>
  );
}