import React, { useState, useEffect } from 'react';
import { ChevronLeft, ChevronRight, Apple, Lightbulb, Target, Zap, Award, Clock, Heart, Play, Pause } from 'lucide-react';
import { Button } from './ui/button';
import { Card } from './ui/card';
import { motion, AnimatePresence } from 'motion/react';

const slides = [
  {
    id: 1,
    type: 'intro',
    title: 'My Idol – Steve Jobs',
    subtitle: 'By Deepika',
    class: '216-B',
    icon: Apple,
    gradient: 'from-iron-black via-iron-deep-black to-iron-dark-red'
  },
  {
    id: 2,
    type: 'content',
    title: 'Who is Steve Jobs?',
    points: [
      'Co-founder of Apple Inc.',
      'Visionary entrepreneur',
      'Pioneer of personal computing'
    ],
    icon: Target,
    gradient: 'from-iron-deep-black via-iron-dark-red to-iron-black'
  },
  {
    id: 3,
    type: 'content',
    title: 'Early Life & Struggles',
    points: [
      'Born in 1955, San Francisco',
      'Adopted child',
      'Dropped out of college',
      'Faced many failures before success'
    ],
    icon: Heart,
    gradient: 'from-iron-black via-iron-red to-iron-deep-black'
  },
  {
    id: 4,
    type: 'content',
    title: 'Founding Apple (1976)',
    points: [
      'Founded Apple with Steve Wozniak',
      'Launched Apple I & Apple II',
      'Sparked the personal computer revolution'
    ],
    icon: Apple,
    gradient: 'from-iron-deep-black via-iron-dark-red to-iron-red'
  },
  {
    id: 5,
    type: 'content',
    title: 'Challenges & Comeback',
    points: [
      'Left Apple in 1985',
      'Founded NeXT & Pixar',
      'Returned to Apple in 1997',
      'Turned the company around'
    ],
    icon: Zap,
    gradient: 'from-iron-black via-iron-gold/20 to-iron-deep-black'
  },
  {
    id: 6,
    type: 'innovations',
    title: 'Major Innovations',
    innovations: [
      { product: 'iMac', year: '1998' },
      { product: 'iPod', year: '2001' },
      { product: 'iPhone', year: '2007' },
      { product: 'iPad', year: '2010' }
    ],
    icon: Lightbulb,
    gradient: 'from-iron-deep-black via-iron-bright-gold/10 to-iron-black'
  },
  {
    id: 7,
    type: 'content',
    title: 'Leadership Style',
    points: [
      'Known for perfectionism',
      'Focused on design + user experience',
      'Believed in simplicity'
    ],
    icon: Target,
    gradient: 'from-iron-black via-iron-dark-red to-iron-deep-black'
  },
  {
    id: 8,
    type: 'content',
    title: 'How He Inspires Me',
    points: [
      'Resilience through failures',
      'Thinking differently',
      'Creating impact through innovation'
    ],
    icon: Heart,
    gradient: 'from-iron-deep-black via-iron-red to-iron-black'
  },
  {
    id: 9,
    type: 'content',
    title: 'Achievements & Legacy',
    points: [
      'Revolutionized multiple industries: Computers, Music, Phones, Animation',
      'Built Apple into a trillion-dollar company',
      'Inspired generations of innovators'
    ],
    icon: Award,
    gradient: 'from-iron-black via-iron-bright-gold/15 to-iron-deep-black'
  },
  {
    id: 10,
    type: 'timeline',
    title: 'Timeline of Key Milestones',
    timeline: [
      { year: '1955', event: 'Born' },
      { year: '1976', event: 'Founded Apple' },
      { year: '1985', event: 'Left Apple' },
      { year: '1997', event: 'Returned to Apple' },
      { year: '2007', event: 'iPhone launch' },
      { year: '2011', event: 'Passed away, leaving a legacy' }
    ],
    icon: Clock,
    gradient: 'from-iron-deep-black via-iron-gold/10 to-iron-black'
  },
  {
    id: 11,
    type: 'conclusion',
    title: 'Conclusion',
    points: [
      'Steve Jobs showed us the power of vision and persistence',
      'He inspires me to dream big and never give up'
    ],
    quote: '"Stay Hungry, Stay Foolish"',
    icon: Apple,
    gradient: 'from-iron-black via-iron-bright-gold/20 to-iron-deep-black'
  }
];

// Animated background particles
const FloatingParticles = () => {
  return (
    <div className="absolute inset-0 overflow-hidden pointer-events-none">
      {[...Array(50)].map((_, i) => (
        <motion.div
          key={i}
          className="absolute w-1 h-1 bg-iron-gold/30 rounded-full"
          initial={{
            x: Math.random() * window.innerWidth,
            y: Math.random() * window.innerHeight,
          }}
          animate={{
            x: Math.random() * window.innerWidth,
            y: Math.random() * window.innerHeight,
          }}
          transition={{
            duration: Math.random() * 20 + 10,
            repeat: Infinity,
            repeatType: 'reverse',
          }}
        />
      ))}
    </div>
  );
};

export default function SteveJobsPresentation() {
  const [currentSlide, setCurrentSlide] = useState(0);
  const [isAutoPlay, setIsAutoPlay] = useState(false);
  const [direction, setDirection] = useState(1);

  // Auto-play functionality
  useEffect(() => {
    if (!isAutoPlay) return;
    
    const interval = setInterval(() => {
      setCurrentSlide((prev) => {
        if (prev >= slides.length - 1) {
          setIsAutoPlay(false);
          return prev;
        }
        setDirection(1);
        return prev + 1;
      });
    }, 4000);

    return () => clearInterval(interval);
  }, [isAutoPlay, currentSlide]);

  // Keyboard navigation
  useEffect(() => {
    const handleKeyPress = (event: KeyboardEvent) => {
      if (event.key === 'ArrowRight' && currentSlide < slides.length - 1) {
        setDirection(1);
        setCurrentSlide(currentSlide + 1);
      } else if (event.key === 'ArrowLeft' && currentSlide > 0) {
        setDirection(-1);
        setCurrentSlide(currentSlide - 1);
      } else if (event.key === ' ') {
        event.preventDefault();
        setIsAutoPlay(!isAutoPlay);
      }
    };

    window.addEventListener('keydown', handleKeyPress);
    return () => window.removeEventListener('keydown', handleKeyPress);
  }, [currentSlide, isAutoPlay]);

  const nextSlide = () => {
    if (currentSlide < slides.length - 1) {
      setDirection(1);
      setCurrentSlide(currentSlide + 1);
    }
  };

  const prevSlide = () => {
    if (currentSlide > 0) {
      setDirection(-1);
      setCurrentSlide(currentSlide - 1);
    }
  };

  const goToSlide = (index: number) => {
    setDirection(index > currentSlide ? 1 : -1);
    setCurrentSlide(index);
  };

  const slide = slides[currentSlide];
  const IconComponent = slide.icon;

  const slideVariants = {
    enter: (direction: number) => ({
      x: direction > 0 ? 1000 : -1000,
      opacity: 0,
      scale: 0.8,
      rotateY: direction > 0 ? 45 : -45,
    }),
    center: {
      zIndex: 1,
      x: 0,
      opacity: 1,
      scale: 1,
      rotateY: 0,
    },
    exit: (direction: number) => ({
      zIndex: 0,
      x: direction < 0 ? 1000 : -1000,
      opacity: 0,
      scale: 0.8,
      rotateY: direction < 0 ? 45 : -45,
    }),
  };

  return (
    <div className={`min-h-screen bg-gradient-to-br ${slide.gradient} relative overflow-hidden tech-grid`}>
      <FloatingParticles />
      
      {/* Modern glassmorphism overlay */}
      <div className="absolute inset-0 bg-black/20 backdrop-blur-sm" />
      
      <div className="relative z-10 min-h-screen flex items-center justify-center p-4">
        <div className="w-full max-w-7xl h-[85vh] relative perspective-1000">
          
          <AnimatePresence mode="wait" custom={direction}>
            <motion.div
              key={currentSlide}
              custom={direction}
              variants={slideVariants}
              initial="enter"
              animate="center"
              exit="exit"
              transition={{
                x: { type: "spring", stiffness: 300, damping: 30 },
                opacity: { duration: 0.3 },
                scale: { duration: 0.4 },
                rotateY: { duration: 0.4 }
              }}
              className="absolute inset-0"
            >
              {/* Main Slide Content */}
              <Card className="w-full h-full bg-iron-card border-iron-red/30 backdrop-blur-xl shadow-2xl rounded-3xl overflow-hidden">
                <div className="h-full flex flex-col justify-center items-center p-8 lg:p-12 text-center relative">
                  
                  {/* Animated background pattern */}
                  <div className="absolute inset-0 opacity-5">
                    <div className="w-full h-full bg-[radial-gradient(circle_at_center,_var(--color-iron-gold)_1px,_transparent_1px)] bg-[length:50px_50px] animate-pulse" />
                  </div>
                  
                  {/* Slide Content */}
                  <div className="flex-1 flex flex-col justify-center items-center space-y-8 max-w-5xl relative z-10">
                    
                    {/* Animated Icon */}
                    <motion.div
                      initial={{ scale: 0, rotate: -180 }}
                      animate={{ scale: 1, rotate: 0 }}
                      transition={{ delay: 0.2, type: "spring", stiffness: 200 }}
                      className="mb-6 relative"
                    >
                      <div className="absolute inset-0 bg-iron-gold/20 blur-xl rounded-full animate-pulse" />
                      <div className="relative bg-gradient-to-br from-iron-gold to-iron-bright-gold p-4 rounded-2xl">
                        <IconComponent className="w-16 h-16 text-iron-black" strokeWidth={1.5} />
                      </div>
                    </motion.div>

                    {/* Animated Title */}
                    <motion.h1
                      initial={{ y: 50, opacity: 0 }}
                      animate={{ y: 0, opacity: 1 }}
                      transition={{ delay: 0.4, duration: 0.8 }}
                      className="text-4xl lg:text-7xl font-black text-iron-white tracking-tight leading-tight"
                      style={{
                        background: 'linear-gradient(135deg, #FFFFFF 0%, #DAA520 50%, #FFFFFF 100%)',
                        WebkitBackgroundClip: 'text',
                        WebkitTextFillColor: 'transparent',
                        backgroundClip: 'text'
                      }}
                    >
                      {slide.title}
                    </motion.h1>

                    {/* Content based on slide type */}
                    {slide.type === 'intro' && (
                      <motion.div
                        initial={{ y: 30, opacity: 0 }}
                        animate={{ y: 0, opacity: 1 }}
                        transition={{ delay: 0.6, duration: 0.6 }}
                        className="space-y-8"
                      >
                        <p className="text-3xl text-iron-light-gray font-light">{slide.subtitle}</p>
                        <p className="text-xl text-iron-gray">Class {slide.class}</p>
                        <motion.div
                          initial={{ scale: 0 }}
                          animate={{ scale: 1 }}
                          transition={{ delay: 0.8, type: "spring", stiffness: 200 }}
                          className="mt-12 w-40 h-40 mx-auto bg-gradient-to-br from-iron-gold to-iron-bright-gold rounded-full flex items-center justify-center shadow-2xl"
                        >
                          <Apple className="w-20 h-20 text-iron-black" />
                        </motion.div>
                      </motion.div>
                    )}

                    {slide.type === 'content' && (
                      <motion.div
                        initial={{ y: 30, opacity: 0 }}
                        animate={{ y: 0, opacity: 1 }}
                        transition={{ delay: 0.6, duration: 0.6 }}
                        className="space-y-8 w-full max-w-4xl"
                      >
                        <div className="grid gap-6">
                          {slide.points?.map((point, index) => (
                            <motion.div
                              key={index}
                              initial={{ x: -50, opacity: 0 }}
                              animate={{ x: 0, opacity: 1 }}
                              transition={{ delay: 0.8 + index * 0.1, duration: 0.5 }}
                              className="flex items-start space-x-6 group"
                            >
                              <div className="relative">
                                <div className="w-3 h-3 bg-gradient-to-r from-iron-gold to-iron-bright-gold rounded-full mt-2 group-hover:scale-125 transition-transform duration-300" />
                                <div className="absolute inset-0 bg-iron-gold/30 blur-md rounded-full animate-pulse" />
                              </div>
                              <span className="text-xl lg:text-2xl text-iron-light-gray font-light leading-relaxed group-hover:text-iron-white transition-colors duration-300">
                                {point}
                              </span>
                            </motion.div>
                          ))}
                        </div>
                      </motion.div>
                    )}

                    {slide.type === 'conclusion' && (
                      <motion.div
                        initial={{ y: 30, opacity: 0 }}
                        animate={{ y: 0, opacity: 1 }}
                        transition={{ delay: 0.6, duration: 0.6 }}
                        className="space-y-10 w-full max-w-4xl"
                      >
                        <div className="grid gap-6">
                          {slide.points?.map((point, index) => (
                            <motion.div
                              key={index}
                              initial={{ x: -50, opacity: 0 }}
                              animate={{ x: 0, opacity: 1 }}
                              transition={{ delay: 0.8 + index * 0.1, duration: 0.5 }}
                              className="flex items-start space-x-6 group"
                            >
                              <div className="relative">
                                <div className="w-3 h-3 bg-gradient-to-r from-iron-gold to-iron-bright-gold rounded-full mt-2 group-hover:scale-125 transition-transform duration-300" />
                                <div className="absolute inset-0 bg-iron-gold/30 blur-md rounded-full animate-pulse" />
                              </div>
                              <span className="text-xl lg:text-2xl text-iron-light-gray font-light leading-relaxed group-hover:text-iron-white transition-colors duration-300">
                                {point}
                              </span>
                            </motion.div>
                          ))}
                        </div>
                        {slide.quote && (
                          <motion.div
                            initial={{ scale: 0.8, opacity: 0 }}
                            animate={{ scale: 1, opacity: 1 }}
                            transition={{ delay: 1.2, duration: 0.8 }}
                            className="relative"
                          >
                            <div className="absolute inset-0 bg-gradient-to-r from-iron-gold/20 via-iron-bright-gold/30 to-iron-gold/20 blur-xl rounded-3xl" />
                            <div className="relative bg-iron-card border border-iron-gold/30 rounded-3xl p-8 lg:p-12">
                              <p className="text-3xl lg:text-5xl font-light text-iron-white italic leading-tight">
                                {slide.quote}
                              </p>
                            </div>
                          </motion.div>
                        )}
                      </motion.div>
                    )}

                    {slide.type === 'innovations' && (
                      <motion.div
                        initial={{ y: 30, opacity: 0 }}
                        animate={{ y: 0, opacity: 1 }}
                        transition={{ delay: 0.6, duration: 0.6 }}
                        className="grid grid-cols-2 gap-8 max-w-4xl w-full"
                      >
                        {slide.innovations?.map((innovation, index) => (
                          <motion.div
                            key={index}
                            initial={{ scale: 0, rotate: -10 }}
                            animate={{ scale: 1, rotate: 0 }}
                            transition={{ delay: 0.8 + index * 0.1, type: "spring", stiffness: 200 }}
                            whileHover={{ scale: 1.05, y: -5 }}
                            className="relative group cursor-pointer"
                          >
                            <div className="absolute inset-0 bg-gradient-to-br from-iron-gold/20 to-iron-bright-gold/20 blur-xl rounded-2xl group-hover:blur-2xl transition-all duration-300" />
                            <div className="relative bg-iron-card border border-iron-gold/30 rounded-2xl p-8 text-center group-hover:border-iron-bright-gold/50 transition-all duration-300">
                              <h3 className="text-2xl lg:text-3xl font-bold text-iron-white mb-3">{innovation.product}</h3>
                              <p className="text-xl text-iron-gold font-medium">{innovation.year}</p>
                            </div>
                          </motion.div>
                        ))}
                      </motion.div>
                    )}

                    {slide.type === 'timeline' && (
                      <motion.div
                        initial={{ y: 30, opacity: 0 }}
                        animate={{ y: 0, opacity: 1 }}
                        transition={{ delay: 0.6, duration: 0.6 }}
                        className="space-y-8 max-w-3xl w-full relative"
                      >
                        <div className="absolute left-12 top-8 bottom-8 w-0.5 bg-gradient-to-b from-iron-gold via-iron-bright-gold to-iron-gold" />
                        {slide.timeline?.map((item, index) => (
                          <motion.div
                            key={index}
                            initial={{ x: -100, opacity: 0 }}
                            animate={{ x: 0, opacity: 1 }}
                            transition={{ delay: 0.8 + index * 0.2, duration: 0.5 }}
                            className="flex items-center space-x-8 relative group"
                          >
                            <div className="relative">
                              <div className="w-6 h-6 bg-gradient-to-r from-iron-gold to-iron-bright-gold rounded-full flex items-center justify-center shadow-lg group-hover:scale-125 transition-transform duration-300">
                                <div className="w-2 h-2 bg-iron-black rounded-full" />
                              </div>
                              <div className="absolute inset-0 bg-iron-gold/40 blur-md rounded-full animate-pulse" />
                            </div>
                            <div className="flex-1 grid grid-cols-3 gap-4 items-center">
                              <span className="text-2xl font-bold text-iron-gold">{item.year}</span>
                              <span className="col-span-2 text-xl text-iron-light-gray font-light group-hover:text-iron-white transition-colors duration-300">
                                {item.event}
                              </span>
                            </div>
                          </motion.div>
                        ))}
                      </motion.div>
                    )}
                  </div>

                  {/* Slide Counter with modern design */}
                  <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 1, duration: 0.5 }}
                    className="absolute bottom-8 right-8 bg-iron-card border border-iron-gold/30 rounded-2xl px-6 py-3"
                  >
                    <span className="text-iron-gold font-medium">
                      {String(currentSlide + 1).padStart(2, '0')} / {String(slides.length).padStart(2, '0')}
                    </span>
                  </motion.div>
                </div>
              </Card>
            </motion.div>
          </AnimatePresence>

          {/* Modern Navigation Controls */}
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 1.2, duration: 0.8 }}
            className="absolute bottom-8 left-1/2 transform -translate-x-1/2 flex items-center space-x-6"
          >
            <Button
              onClick={prevSlide}
              disabled={currentSlide === 0}
              variant="outline"
              size="icon"
              className="w-14 h-14 rounded-2xl bg-iron-card border-iron-gold/30 hover:bg-iron-gold/20 hover:border-iron-bright-gold/50 disabled:opacity-30 transition-all duration-300"
            >
              <ChevronLeft className="w-6 h-6 text-iron-gold" />
            </Button>

            {/* Auto-play button */}
            <Button
              onClick={() => setIsAutoPlay(!isAutoPlay)}
              variant="outline"
              size="icon"
              className="w-14 h-14 rounded-2xl bg-iron-card border-iron-gold/30 hover:bg-iron-gold/20 hover:border-iron-bright-gold/50 transition-all duration-300"
            >
              {isAutoPlay ? (
                <Pause className="w-6 h-6 text-iron-gold" />
              ) : (
                <Play className="w-6 h-6 text-iron-gold" />
              )}
            </Button>

            {/* Enhanced Slide Indicators */}
            <div className="flex space-x-3 bg-iron-card border border-iron-gold/30 rounded-2xl p-3">
              {slides.map((_, index) => (
                <button
                  key={index}
                  onClick={() => goToSlide(index)}
                  className={`relative transition-all duration-300 ${
                    index === currentSlide 
                      ? 'w-8 h-3 bg-gradient-to-r from-iron-gold to-iron-bright-gold' 
                      : 'w-3 h-3 bg-iron-gray hover:bg-iron-gold/50'
                  } rounded-full`}
                >
                  {index === currentSlide && (
                    <div className="absolute inset-0 bg-iron-gold/50 blur-sm rounded-full animate-pulse" />
                  )}
                </button>
              ))}
            </div>

            <Button
              onClick={nextSlide}
              disabled={currentSlide === slides.length - 1}
              variant="outline"
              size="icon"
              className="w-14 h-14 rounded-2xl bg-iron-card border-iron-gold/30 hover:bg-iron-gold/20 hover:border-iron-bright-gold/50 disabled:opacity-30 transition-all duration-300"
            >
              <ChevronRight className="w-6 h-6 text-iron-gold" />
            </Button>
          </motion.div>

          {/* Enhanced Keyboard Navigation Hint */}
          <motion.div
            initial={{ opacity: 0, x: 50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 1.4, duration: 0.6 }}
            className="absolute top-8 right-8 bg-iron-card border border-iron-gold/30 rounded-2xl px-4 py-2"
          >
            <span className="text-iron-gray text-sm font-medium">
              ← → Keys | Space for Auto-play
            </span>
          </motion.div>
        </div>
      </div>
    </div>
  );
}