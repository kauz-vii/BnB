import { UserPlus, Sparkles, Trophy, Map } from 'lucide-react';
import { Button } from './ui/button';

interface GuestBannerProps {
  onSignUp: () => void;
  onDismiss?: () => void;
}

export function GuestBanner({ onSignUp, onDismiss }: GuestBannerProps) {
  return (
    <div className="glassmorphism border-travel-blue/20 p-4 m-4 rounded-xl animate-slide-in">
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-3">
          <div className="p-2 bg-gradient-to-r from-blue-500 to-emerald-500 rounded-lg">
            <Sparkles className="w-5 h-5 text-white" />
          </div>
          <div>
            <h3 className="font-semibold text-travel-blue dark:text-white">
              Exploring as Guest
            </h3>
            <p className="text-sm text-travel-slate dark:text-gray-300">
              Sign up to save maps, earn XP, and unlock achievements!
            </p>
          </div>
        </div>
        
        <div className="flex items-center space-x-2">
          <div className="hidden sm:flex items-center space-x-4 mr-4">
            <div className="flex items-center space-x-1 text-xs text-travel-slate dark:text-gray-400">
              <Map className="w-4 h-4" />
              <span>Save Maps</span>
            </div>
            <div className="flex items-center space-x-1 text-xs text-travel-slate dark:text-gray-400">
              <Trophy className="w-4 h-4" />
              <span>Earn XP</span>
            </div>
          </div>
          
          <Button
            onClick={onSignUp}
            size="sm"
            className="bg-gradient-to-r from-blue-600 to-emerald-500 hover:from-blue-700 hover:to-emerald-600 text-white"
          >
            <UserPlus className="w-4 h-4 mr-2" />
            Sign Up
          </Button>
          
          {onDismiss && (
            <Button
              onClick={onDismiss}
              variant="ghost"
              size="sm"
              className="text-travel-slate hover:text-travel-blue dark:text-gray-400 dark:hover:text-white"
            >
              ×
            </Button>
          )}
        </div>
      </div>
    </div>
  );
}