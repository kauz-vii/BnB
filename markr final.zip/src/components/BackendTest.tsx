import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Loader2, CheckCircle, XCircle, AlertCircle } from 'lucide-react';
import { travelMapAPI } from '../api/backend-endpoints';
import { useAuth } from '../hooks/useAuth';

interface TestResult {
  name: string;
  status: 'pending' | 'success' | 'error';
  message: string;
  duration?: number;
}

export function BackendTest() {
  const { user } = useAuth();
  const [results, setResults] = useState<TestResult[]>([]);
  const [testing, setTesting] = useState(false);

  const tests = [
    {
      name: 'Health Check',
      test: async () => {
        const start = Date.now();
        const result = await travelMapAPI.health.check();
        return {
          success: result.status === 'healthy',
          message: result.service || 'Health check passed',
          duration: Date.now() - start
        };
      }
    },
    {
      name: 'User Location API',
      test: async () => {
        const start = Date.now();
        const result = await travelMapAPI.location.getUserLocation();
        return {
          success: !!result.lat && !!result.lng,
          message: `Location: ${result.address || 'Unknown'} (${result.lat?.toFixed(4)}, ${result.lng?.toFixed(4)})`,
          duration: Date.now() - start
        };
      }
    },
    {
      name: 'Leaderboard API',
      test: async () => {
        const start = Date.now();
        const result = await travelMapAPI.leaderboard.get({ limit: 5 });
        return {
          success: Array.isArray(result),
          message: `Retrieved ${result.length} leaderboard entries`,
          duration: Date.now() - start
        };
      }
    },
    {
      name: 'Maps API',
      test: async () => {
        const start = Date.now();
        const result = await travelMapAPI.maps.getAll({ limit: 5 });
        return {
          success: !!result.maps && Array.isArray(result.maps),
          message: `Retrieved ${result.maps?.length || 0} maps`,
          duration: Date.now() - start
        };
      }
    },
    {
      name: 'Search API',
      test: async () => {
        const start = Date.now();
        const result = await travelMapAPI.search.search({ q: 'test', limit: 5 });
        return {
          success: !!result && typeof result.total === 'number',
          message: `Search returned ${result.total} total results`,
          duration: Date.now() - start
        };
      }
    },
    {
      name: 'Directions API',
      test: async () => {
        const start = Date.now();
        const result = await travelMapAPI.directions.getRoute({
          origin_lat: 40.7128,
          origin_lng: -74.0060,
          destination_lat: 34.0522,
          destination_lng: -118.2437
        });
        return {
          success: !!result.distance && !!result.duration,
          message: `Route: ${(result.distance / 1000).toFixed(1)}km, ${Math.round(result.duration / 60)}min`,
          duration: Date.now() - start
        };
      }
    }
  ];

  // Add authenticated tests if user is logged in
  if (user) {
    tests.push(
      {
        name: 'Profile API',
        test: async () => {
          const start = Date.now();
          const result = await travelMapAPI.profile.get();
          return {
            success: !!result.id,
            message: `Profile: ${result.name} (Level ${result.level})`,
            duration: Date.now() - start
          };
        }
      },
      {
        name: 'Activity Feed API',
        test: async () => {
          const start = Date.now();
          const result = await travelMapAPI.activity.get({ limit: 5 });
          return {
            success: !!result.activities && Array.isArray(result.activities),
            message: `Retrieved ${result.activities?.length || 0} activities`,
            duration: Date.now() - start
          };
        }
      }
    );
  }

  const runTests = async () => {
    setTesting(true);
    setResults([]);

    for (const testCase of tests) {
      // Update status to pending
      setResults(prev => [...prev, {
        name: testCase.name,
        status: 'pending',
        message: 'Running...'
      }]);

      try {
        const result = await testCase.test();
        
        // Update with result
        setResults(prev => prev.map(r => 
          r.name === testCase.name 
            ? {
                ...r,
                status: result.success ? 'success' : 'error',
                message: result.message,
                duration: result.duration
              }
            : r
        ));
      } catch (error: any) {
        // Update with error
        setResults(prev => prev.map(r => 
          r.name === testCase.name 
            ? {
                ...r,
                status: 'error',
                message: error.message || 'Test failed'
              }
            : r
        ));
      }

      // Small delay between tests
      await new Promise(resolve => setTimeout(resolve, 500));
    }

    setTesting(false);
  };

  const getStatusIcon = (status: TestResult['status']) => {
    switch (status) {
      case 'pending':
        return <Loader2 className="w-4 h-4 animate-spin text-blue-500" />;
      case 'success':
        return <CheckCircle className="w-4 h-4 text-green-500" />;
      case 'error':
        return <XCircle className="w-4 h-4 text-red-500" />;
    }
  };

  const getStatusBadge = (status: TestResult['status']) => {
    const variants = {
      pending: 'secondary',
      success: 'default',
      error: 'destructive'
    } as const;

    return (
      <Badge variant={variants[status]} className="ml-auto">
        {status === 'pending' ? 'Running' : status === 'success' ? 'Pass' : 'Fail'}
      </Badge>
    );
  };

  const successCount = results.filter(r => r.status === 'success').length;
  const errorCount = results.filter(r => r.status === 'error').length;
  const totalTests = results.length;

  return (
    <div className="p-6 max-w-4xl mx-auto">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <AlertCircle className="w-5 h-5 text-blue-500" />
            Backend API Connectivity Test
          </CardTitle>
          <CardDescription>
            Test all backend endpoints to ensure proper connectivity and functionality.
            {user ? ' (Authenticated tests included)' : ' (Sign in for full test coverage)'}
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* Test Controls */}
          <div className="flex items-center justify-between">
            <Button 
              onClick={runTests} 
              disabled={testing}
              className="flex items-center gap-2"
            >
              {testing && <Loader2 className="w-4 h-4 animate-spin" />}
              {testing ? 'Running Tests...' : 'Run All Tests'}
            </Button>

            {totalTests > 0 && (
              <div className="text-sm text-muted-foreground">
                {successCount} passed, {errorCount} failed, {totalTests} total
              </div>
            )}
          </div>

          {/* Test Results */}
          {results.length > 0 && (
            <div className="space-y-2">
              {results.map((result, index) => (
                <div
                  key={index}
                  className="flex items-center gap-3 p-3 border rounded-lg bg-card"
                >
                  {getStatusIcon(result.status)}
                  
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <span className="font-medium">{result.name}</span>
                      {result.duration && (
                        <span className="text-xs text-muted-foreground">
                          ({result.duration}ms)
                        </span>
                      )}
                    </div>
                    <p className="text-sm text-muted-foreground truncate">
                      {result.message}
                    </p>
                  </div>

                  {getStatusBadge(result.status)}
                </div>
              ))}
            </div>
          )}

          {/* Summary */}
          {totalTests > 0 && !testing && (
            <div className="mt-6 p-4 border rounded-lg bg-muted/50">
              <h4 className="font-medium mb-2">Test Summary</h4>
              <div className="grid grid-cols-3 gap-4 text-sm">
                <div className="text-center">
                  <div className="text-2xl font-bold text-green-600">{successCount}</div>
                  <div className="text-muted-foreground">Passed</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-red-600">{errorCount}</div>
                  <div className="text-muted-foreground">Failed</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-blue-600">
                    {Math.round((successCount / totalTests) * 100)}%
                  </div>
                  <div className="text-muted-foreground">Success Rate</div>
                </div>
              </div>
            </div>
          )}

          {/* Instructions */}
          <div className="mt-6 p-4 border border-blue-200 rounded-lg bg-blue-50 dark:bg-blue-950 dark:border-blue-800">
            <h4 className="font-medium text-blue-900 dark:text-blue-100 mb-2">
              Backend Setup Instructions
            </h4>
            <ul className="text-sm text-blue-800 dark:text-blue-200 space-y-1">
              <li>• Ensure Supabase project is properly configured</li>
              <li>• Deploy the server function to Supabase Edge Functions</li>
              <li>• Set required environment variables (SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY)</li>
              <li>• All endpoints should return successful responses</li>
            </ul>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}