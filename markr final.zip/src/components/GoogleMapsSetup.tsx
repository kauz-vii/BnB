import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Alert, AlertDescription } from './ui/alert';
import { Badge } from './ui/badge';
import { 
  MapPin, 
  Key, 
  ExternalLink, 
  CheckCircle, 
  XCircle, 
  Settings,
  Copy,
  Eye,
  EyeOff
} from 'lucide-react';

interface GoogleMapsSetupProps {
  onApiKeySet?: (apiKey: string) => void;
}

export function GoogleMapsSetup({ onApiKeySet }: GoogleMapsSetupProps) {
  const [apiKey, setApiKey] = useState('');
  const [showApiKey, setShowApiKey] = useState(false);
  const [isValidating, setIsValidating] = useState(false);
  const [validationResult, setValidationResult] = useState<{
    isValid: boolean;
    message: string;
  } | null>(null);

  const validateApiKey = async (key: string): Promise<boolean> => {
    try {
      // Test the API key by making a simple request
      const response = await fetch(
        `https://maps.googleapis.com/maps/api/js?key=${key}&libraries=places`,
        { method: 'HEAD' }
      );
      return response.ok;
    } catch (error) {
      return false;
    }
  };

  const handleApiKeySubmit = async () => {
    if (!apiKey.trim()) {
      setValidationResult({
        isValid: false,
        message: 'Please enter an API key'
      });
      return;
    }

    setIsValidating(true);
    setValidationResult(null);

    try {
      const isValid = await validateApiKey(apiKey.trim());
      
      if (isValid) {
        setValidationResult({
          isValid: true,
          message: 'API key is valid! Maps will be enabled.'
        });
        
        // Store in localStorage for development
        localStorage.setItem('MARKR_GOOGLE_MAPS_API_KEY', apiKey.trim());
        
        if (onApiKeySet) {
          onApiKeySet(apiKey.trim());
        }
        
        // Reload the page to reinitialize with the new API key
        setTimeout(() => {
          window.location.reload();
        }, 1500);
      } else {
        setValidationResult({
          isValid: false,
          message: 'Invalid API key. Please check your key and try again.'
        });
      }
    } catch (error) {
      setValidationResult({
        isValid: false,
        message: 'Unable to validate API key. Please check your internet connection.'
      });
    } finally {
      setIsValidating(false);
    }
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
  };

  const steps = [
    {
      title: "Go to Google Cloud Console",
      description: "Visit the Google Cloud Console and create a new project or select an existing one",
      action: (
        <Button
          variant="outline"
          size="sm"
          onClick={() => window.open('https://console.cloud.google.com/', '_blank')}
          className="flex items-center gap-2"
        >
          <ExternalLink className="w-4 h-4" />
          Open Console
        </Button>
      )
    },
    {
      title: "Enable Maps JavaScript API",
      description: "Navigate to APIs & Services > Library and enable the Maps JavaScript API",
      action: (
        <Button
          variant="outline"
          size="sm"
          onClick={() => window.open('https://console.cloud.google.com/apis/library/maps-backend.googleapis.com', '_blank')}
          className="flex items-center gap-2"
        >
          <ExternalLink className="w-4 h-4" />
          Enable API
        </Button>
      )
    },
    {
      title: "Create API Key",
      description: "Go to APIs & Services > Credentials and create a new API key",
      action: (
        <Button
          variant="outline"
          size="sm"
          onClick={() => window.open('https://console.cloud.google.com/apis/credentials', '_blank')}
          className="flex items-center gap-2"
        >
          <ExternalLink className="w-4 h-4" />
          Create Key
        </Button>
      )
    },
    {
      title: "Restrict API Key",
      description: "For security, restrict your API key to specific domains and APIs",
      action: (
        <Badge variant="secondary" className="text-xs">
          Recommended
        </Badge>
      )
    }
  ];

  return (
    <div className="max-w-4xl mx-auto p-6 space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Settings className="w-5 h-5 text-blue-500" />
            Google Maps API Setup
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Current Status */}
          <Alert>
            <MapPin className="h-4 w-4" />
            <AlertDescription>
              Google Maps API key is required to enable interactive maps with full functionality.
              Currently using fallback map display.
            </AlertDescription>
          </Alert>

          {/* API Key Input */}
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium mb-2">
                Google Maps API Key
              </label>
              <div className="flex gap-2">
                <div className="relative flex-1">
                  <Input
                    type={showApiKey ? "text" : "password"}
                    placeholder="Enter your Google Maps API key"
                    value={apiKey}
                    onChange={(e) => setApiKey(e.target.value)}
                    className="pr-10"
                  />
                  <Button
                    type="button"
                    variant="ghost"
                    size="sm"
                    className="absolute right-2 top-1/2 transform -translate-y-1/2 h-6 w-6 p-0"
                    onClick={() => setShowApiKey(!showApiKey)}
                  >
                    {showApiKey ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </Button>
                </div>
                <Button
                  onClick={handleApiKeySubmit}
                  disabled={isValidating || !apiKey.trim()}
                  className="flex items-center gap-2"
                >
                  {isValidating ? (
                    <>
                      <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                      Validating
                    </>
                  ) : (
                    <>
                      <Key className="w-4 h-4" />
                      Set API Key
                    </>
                  )}
                </Button>
              </div>
            </div>

            {/* Validation Result */}
            {validationResult && (
              <Alert className={validationResult.isValid ? "border-green-200 bg-green-50" : "border-red-200 bg-red-50"}>
                {validationResult.isValid ? (
                  <CheckCircle className="h-4 w-4 text-green-600" />
                ) : (
                  <XCircle className="h-4 w-4 text-red-600" />
                )}
                <AlertDescription className={validationResult.isValid ? "text-green-800" : "text-red-800"}>
                  {validationResult.message}
                </AlertDescription>
              </Alert>
            )}
          </div>

          {/* Setup Instructions */}
          <div className="space-y-4">
            <h3 className="text-lg font-semibold">Setup Instructions</h3>
            <div className="grid gap-4">
              {steps.map((step, index) => (
                <Card key={index} className="p-4">
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-2">
                        <div className="w-6 h-6 bg-blue-100 dark:bg-blue-900 text-blue-600 dark:text-blue-400 rounded-full flex items-center justify-center text-sm font-semibold">
                          {index + 1}
                        </div>
                        <h4 className="font-medium">{step.title}</h4>
                      </div>
                      <p className="text-sm text-muted-foreground ml-8">
                        {step.description}
                      </p>
                    </div>
                    <div className="ml-4">
                      {step.action}
                    </div>
                  </div>
                </Card>
              ))}
            </div>
          </div>

          {/* Environment Variable Setup */}
          <Card className="bg-gray-50 dark:bg-gray-800/50">
            <CardHeader>
              <CardTitle className="text-base">For Production Deployment</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <p className="text-sm text-muted-foreground">
                Set the following environment variable in your deployment platform:
              </p>
              <div className="bg-gray-800 dark:bg-gray-900 p-3 rounded-lg">
                <div className="flex items-center justify-between">
                  <code className="text-green-400 text-sm">VITE_GOOGLE_MAPS_API_KEY=your_api_key_here</code>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => copyToClipboard('VITE_GOOGLE_MAPS_API_KEY=')}
                    className="h-6 w-6 p-0"
                  >
                    <Copy className="w-3 h-3" />
                  </Button>
                </div>
              </div>
              <Alert>
                <AlertDescription className="text-xs">
                  Never commit API keys to version control. Use environment variables for secure deployment.
                </AlertDescription>
              </Alert>
            </CardContent>
          </Card>

          {/* Quick Test */}
          <Card className="border-blue-200 bg-blue-50 dark:bg-blue-900/20">
            <CardContent className="p-4">
              <div className="flex items-start gap-3">
                <MapPin className="w-5 h-5 text-blue-600 flex-shrink-0 mt-0.5" />
                <div>
                  <h4 className="font-medium text-blue-900 dark:text-blue-100 mb-1">
                    Development Mode
                  </h4>
                  <p className="text-sm text-blue-800 dark:text-blue-200">
                    For development, you can temporarily set your API key here. 
                    It will be stored locally and cleared when you refresh or close the browser.
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </CardContent>
      </Card>
    </div>
  );
}