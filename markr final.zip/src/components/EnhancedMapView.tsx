import { useState, useEffect, useRef } from 'react';
import { GoogleMap } from './GoogleMap';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Card, CardContent } from './ui/card';
import { Alert, AlertDescription } from './ui/alert';
import { 
  Search, 
  Navigation, 
  Target,
  Route,
  MapPin,
  AlertCircle,
  Locate,
  Star,
  TrendingUp,
  Users,
  Clock
} from 'lucide-react';
import type { User } from '@supabase/supabase-js';

// Direct configuration to avoid import issues
const MARKR_CONFIG = {
  googleMaps: {
    apiKey: (() => {
      try {
        // Check localStorage first for development
        const localKey = typeof window !== 'undefined' ? localStorage.getItem('MARKR_GOOGLE_MAPS_API_KEY') : null;
        if (localKey && localKey !== 'DEMO_MODE') {
          return localKey;
        }
        
        // Check environment variables
        const envKey = (window as any)?.import?.meta?.env?.VITE_GOOGLE_MAPS_API_KEY || 
                      (import.meta as any)?.env?.VITE_GOOGLE_MAPS_API_KEY;
        if (envKey && envKey !== 'YOUR_GOOGLE_MAPS_API_KEY' && envKey !== 'DEMO_MODE') {
          return envKey;
        }
        
        return "DEMO_MODE";
      } catch (error) {
        return "DEMO_MODE";
      }
    })(),
  },
  app: {
    name: "Markr",
    defaultLocation: {
      lat: 20.5937,
      lng: 78.9629,
      zoom: 5
    }
  }
};

interface EnhancedMapViewProps {
  onAddMarker: () => void;
  user: User | null;
}

export function EnhancedMapView({ onAddMarker, user }: EnhancedMapViewProps) {
  const [currentCenter, setCurrentCenter] = useState<[number, number]>([
    MARKR_CONFIG.app.defaultLocation.lat, 
    MARKR_CONFIG.app.defaultLocation.lng
  ]);
  const [currentZoom, setCurrentZoom] = useState(MARKR_CONFIG.app.defaultLocation.zoom);
  const [userLocation, setUserLocation] = useState<[number, number] | null>(null);
  const [showDirections, setShowDirections] = useState(false);
  const [directionsFrom, setDirectionsFrom] = useState<[number, number] | null>(null);
  const [directionsTo, setDirectionsTo] = useState<[number, number] | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState<any[]>([]);
  const [isSearching, setIsSearching] = useState(false);
  const [showSearchResults, setShowSearchResults] = useState(false);
  const searchInputRef = useRef<HTMLInputElement>(null);
  
  // Sample markers for demonstration
  const [markers, setMarkers] = useState([
    {
      id: 'marker-1',
      position: [28.6129, 77.2295] as [number, number],
      title: 'India Gate Food Court',
      type: 'food' as const,
      info: {
        name: 'India Gate Food Court',
        type: 'food',
        description: 'Popular food stalls near India Gate',
        address: 'Rajpath, New Delhi'
      }
    },
    {
      id: 'marker-2',
      position: [18.9220, 72.8347] as [number, number],
      title: 'Gateway Cafe',
      type: 'food' as const,
      info: {
        name: 'Gateway Cafe',
        type: 'food',
        description: 'Cafe with sea view near Gateway of India',
        address: 'Apollo Bunder, Mumbai'
      }
    },
    {
      id: 'marker-3',
      position: [22.5858, 88.3469] as [number, number],
      title: 'Howrah Bridge Viewpoint',
      type: 'attraction' as const,
      info: {
        name: 'Howrah Bridge Viewpoint',
        type: 'attraction',
        description: 'Best viewpoint for bridge photography',
        address: 'Strand Road, Kolkata'
      }
    }
  ]);

  // Map stats
  const [mapStats] = useState({
    totalUsers: 4247,
    totalMarkers: 28432,
    activeExplorers: 387
  });

  // Simulate search functionality
  const handleSearch = async (query: string) => {
    if (!query.trim()) {
      setSearchResults([]);
      setShowSearchResults(false);
      return;
    }

    setIsSearching(true);
    setShowSearchResults(true);

    // Simulate API delay
    setTimeout(() => {
      // Mock search results - in real implementation, this would use Google Places API
      const mockResults = [
        {
          id: 'search-1',
          name: query.includes('delhi') || query.includes('gate') ? 'India Gate, New Delhi' : `${query} - Delhi`,
          address: 'Rajpath, India Gate, New Delhi',
          coordinates: [28.6129, 77.2295] as [number, number],
          type: 'landmark'
        },
        {
          id: 'search-2',
          name: query.includes('mumbai') || query.includes('gateway') ? 'Gateway of India, Mumbai' : `${query} - Mumbai`,
          address: 'Apollo Bunder, Colaba, Mumbai',
          coordinates: [18.9220, 72.8347] as [number, number],
          type: 'landmark'
        },
        {
          id: 'search-3',
          name: query.includes('kolkata') || query.includes('howrah') ? 'Howrah Bridge, Kolkata' : `${query} - Kolkata`,
          address: 'Strand Road, Kolkata',
          coordinates: [22.5858, 88.3469] as [number, number],
          type: 'landmark'
        }
      ].filter((_, index) => query.length > 2 ? index < 3 : index < 2);

      setSearchResults(mockResults);
      setIsSearching(false);
    }, 500);
  };

  // Handle search input changes
  useEffect(() => {
    const timeoutId = setTimeout(() => {
      if (searchQuery) {
        handleSearch(searchQuery);
      }
    }, 300);

    return () => clearTimeout(timeoutId);
  }, [searchQuery]);

  const handleMarkerAdd = (latlng: { lat: number; lng: number }) => {
    console.log('New marker requested at:', latlng);
    onAddMarker();
  };

  const handleMarkerClick = (marker: any) => {
    console.log('Marker clicked:', marker);
  };

  const jumpToLocation = (coordinates: [number, number], zoom: number = 15) => {
    setCurrentCenter(coordinates);
    setCurrentZoom(zoom);
    setShowSearchResults(false);
    setSearchQuery('');
  };

  const getUserLocation = () => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          const { latitude, longitude } = position.coords;
          setUserLocation([latitude, longitude]);
          setCurrentCenter([latitude, longitude]);
          setCurrentZoom(16);
        },
        (error) => {
          console.error('Error getting location:', error);
          alert('Unable to get your location. Please enable location services.');
          setCurrentCenter([MARKR_CONFIG.app.defaultLocation.lat, MARKR_CONFIG.app.defaultLocation.lng]);
          setCurrentZoom(MARKR_CONFIG.app.defaultLocation.zoom);
        }
      );
    } else {
      alert('Geolocation is not supported by this browser.');
    }
  };

  const clearDirections = () => {
    setShowDirections(false);
    setDirectionsFrom(null);
    setDirectionsTo(null);
  };

  return (
    <div className="h-full bg-gradient-to-br from-blue-50 via-indigo-50 to-emerald-50 dark:from-gray-900 dark:via-gray-800 dark:to-gray-900 relative">
      {/* API Key Alert */}
      {MARKR_CONFIG.googleMaps.apiKey === 'DEMO_MODE' && (
        <Alert className="absolute top-4 left-1/2 transform -translate-x-1/2 z-[1001] max-w-md border-orange-200 bg-orange-50 dark:bg-orange-900/20">
          <AlertCircle className="h-4 w-4 text-orange-600" />
          <AlertDescription className="text-orange-800 dark:text-orange-200">
            <span className="font-medium">Demo Mode:</span> Configure Google Maps API key for full functionality.
            <Button
              variant="link"
              size="sm"
              className="p-0 h-auto ml-2 text-orange-600 hover:text-orange-800"
              onClick={() => window.open(window.location.origin + '?setup=maps', '_blank')}
            >
              Set up now
            </Button>
          </AlertDescription>
        </Alert>
      )}

      {/* Search Bar */}
      <div className="absolute top-4 left-1/2 transform -translate-x-1/2 z-[1000] w-full max-w-md px-4">
        <div className="relative">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
            <Input
              ref={searchInputRef}
              type="text"
              placeholder="Search locations..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10 pr-4 py-3 w-full glassmorphism border-white/20 dark:border-gray-700/20 bg-white/90 dark:bg-gray-800/90 rounded-xl shadow-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              onFocus={() => {
                if (searchResults.length > 0) {
                  setShowSearchResults(true);
                }
              }}
            />
            {isSearching && (
              <div className="absolute right-3 top-1/2 transform -translate-y-1/2">
                <div className="w-4 h-4 border-2 border-blue-500 border-t-transparent rounded-full animate-spin"></div>
              </div>
            )}
          </div>
          
          {/* Search Results */}
          {showSearchResults && searchResults.length > 0 && (
            <Card className="absolute top-full mt-2 w-full glassmorphism border-white/20 dark:border-gray-700/20 shadow-xl z-[1001]">
              <CardContent className="p-0">
                <div className="max-h-60 overflow-y-auto">
                  {searchResults.map((result, index) => (
                    <button
                      key={result.id}
                      onClick={() => jumpToLocation(result.coordinates)}
                      className="w-full flex items-center gap-3 p-3 text-left hover:bg-blue-50 dark:hover:bg-gray-700 transition-colors duration-200 border-b border-gray-100 dark:border-gray-700 last:border-0"
                    >
                      <div className="w-8 h-8 bg-blue-500 rounded-full flex items-center justify-center flex-shrink-0">
                        <MapPin className="w-4 h-4 text-white" />
                      </div>
                      <div className="flex-1">
                        <h4 className="font-medium text-gray-900 dark:text-gray-100 text-sm">
                          {result.name}
                        </h4>
                        <p className="text-xs text-gray-500 dark:text-gray-400">
                          {result.address}
                        </p>
                      </div>
                      <Navigation className="w-4 h-4 text-gray-400" />
                    </button>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}
        </div>
      </div>

      {/* Main Google Map */}
      <GoogleMap
        center={currentCenter}
        zoom={currentZoom}
        markers={markers}
        onMarkerClick={handleMarkerClick}
        onMapClick={(coordinates) => {
          console.log('Map clicked at:', coordinates);
          setShowSearchResults(false);
          if (user) {
            handleMarkerAdd({ lat: coordinates[0], lng: coordinates[1] });
          }
        }}
        userLocation={userLocation}
        apiKey={MARKR_CONFIG.googleMaps.apiKey}
        showDirections={showDirections}
        directionsFrom={directionsFrom || undefined}
        directionsTo={directionsTo || undefined}
      />

      {/* Quick Location Button */}
      <div className="absolute top-20 right-4 z-[1000]">
        <Button
          onClick={getUserLocation}
          size="sm"
          className="w-12 h-12 p-0 rounded-full glassmorphism border-white/20 dark:border-gray-700/20 bg-white/90 dark:bg-gray-800/90 hover:bg-white dark:hover:bg-gray-700 shadow-lg"
          title="Go to my location"
        >
          <Target className="w-5 h-5 text-blue-600" />
        </Button>
      </div>

      {/* Mobile Stats Panel */}
      <div className="absolute bottom-4 right-4 z-[1000] md:hidden">
        <Card className="glassmorphism border-white/20 dark:border-gray-700/20 shadow-xl">
          <CardContent className="p-3">
            <div className="flex items-center gap-3 text-xs">
              <div className="flex items-center gap-1 text-emerald-600 dark:text-emerald-400">
                <div className="w-2 h-2 bg-emerald-500 rounded-full animate-pulse" />
                <span className="font-medium">{mapStats.activeExplorers}</span>
              </div>
              <div className="w-1 h-1 bg-gray-400 rounded-full" />
              <div className="flex items-center gap-1 text-blue-600 dark:text-blue-400">
                <MapPin className="w-3 h-3" />
                <span className="font-medium">{mapStats.totalMarkers.toLocaleString()}</span>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Directions Panel */}
      {showDirections && (
        <div className="absolute top-32 left-4 z-[1000] max-w-sm">
          <Card className="glassmorphism border-blue-500/20 bg-blue-50/50 dark:bg-blue-900/20 shadow-xl">
            <CardContent className="p-4">
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-2">
                  <Route className="w-4 h-4 text-blue-600" />
                  <span className="font-medium text-blue-800 dark:text-blue-200 text-sm">Navigation Active</span>
                </div>
                <Button
                  onClick={clearDirections}
                  variant="ghost"
                  size="sm"
                  className="h-6 w-6 p-0 text-blue-600 hover:text-blue-800"
                >
                  ×
                </Button>
              </div>
              <div className="space-y-2 text-xs text-blue-700 dark:text-blue-300">
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 bg-blue-500 rounded-full" />
                  <span>From: Your Location</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 bg-red-500 rounded-full" />
                  <span>To: Selected Destination</span>
                </div>
              </div>
              <p className="text-xs text-blue-600 dark:text-blue-400 mt-3">
                Follow the blue route on the map for turn-by-turn directions.
              </p>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Click outside to close search results */}
      {showSearchResults && (
        <div 
          className="fixed inset-0 z-[999]" 
          onClick={() => setShowSearchResults(false)}
        />
      )}
    </div>
  );
}