import { Search, Globe, Trophy, User, LogOut, Menu } from 'lucide-react';
import { Input } from './ui/input';
import { Button } from './ui/button';
import { useAuth } from '../hooks/useAuth';
import { ThemeToggle } from './ThemeToggle';
import type { User as SupabaseUser } from '@supabase/supabase-js';

interface UserProfile {
  id: string;
  name: string;
  email: string;
  level: number;
  xp: number;
  totalDistance: number;
  placesExplored: number;
  mapsContributed: number;
  achievements: string[];
  createdAt: string;
}

type ViewType = 'explore' | 'profile' | 'leaderboard' | 'public-maps' | 'nearby-places' | 'trending-maps' | 'my-contributions' | 'saved-maps' | 'relief-points';

interface NavbarProps {
  currentView: ViewType;
  onViewChange: (view: ViewType) => void;
  user: SupabaseUser | null;
  profile: UserProfile | null;
  onAuthClick: () => void;
  onMobileMenuToggle?: () => void;
}

export function Navbar({ currentView, onViewChange, user, profile, onAuthClick, onMobileMenuToggle }: NavbarProps) {
  const { signOut } = useAuth();

  const handleSignOut = async () => {
    await signOut();
  };

  return (
    <nav className="sticky top-0 z-50 h-16 backdrop-blur-xl bg-white/70 dark:bg-gray-900/70 border-b border-white/20 dark:border-gray-700/20 shadow-lg">
      <div className="flex items-center justify-between h-full px-4 md:px-6">
        {/* Mobile Menu Toggle & Logo */}
        <div className="flex items-center space-x-3">
          {/* Mobile Menu Toggle */}
          <Button
            variant="ghost"
            size="sm"
            onClick={onMobileMenuToggle}
            className="p-2 md:hidden"
          >
            <Menu className="w-5 h-5" />
          </Button>
          
          {/* Logo */}
          <div className="w-10 h-10 bg-gradient-to-br from-blue-600 to-emerald-500 rounded-xl flex items-center justify-center shadow-lg hover-lift">
            <Globe className="w-6 h-6 text-white" />
          </div>
          <span className="font-inter font-black text-2xl bg-gradient-to-r from-blue-600 to-emerald-500 bg-clip-text text-transparent hidden sm:block">
            Markr
          </span>
        </div>

        {/* Center Logo for mobile */}
        <div className="flex-1 flex justify-center sm:hidden">
          <span className="font-inter font-black text-xl bg-gradient-to-r from-blue-600 to-emerald-500 bg-clip-text text-transparent">
            Markr
          </span>
        </div>

        {/* Right Side */}
        <div className="flex items-center space-x-3">
          {/* Theme Toggle */}
          <ThemeToggle />
          {user ? (
            <>
              {/* Navigation Icons */}
              <div className="flex items-center space-x-1 glassmorphism rounded-xl p-1">
                <button
                  onClick={() => onViewChange('explore')}
                  className={`p-3 rounded-lg transition-all duration-200 hover-lift ${
                    currentView === 'explore'
                      ? 'bg-gradient-to-r from-blue-500 to-emerald-500 text-white shadow-lg'
                      : 'text-slate-600 dark:text-gray-300 hover:bg-white/70 dark:hover:bg-gray-700/70 hover:text-slate-800 dark:hover:text-white'
                  }`}
                  title="Explore"
                >
                  <Globe className="w-5 h-5" />
                </button>
                
                <button
                  onClick={() => onViewChange('leaderboard')}
                  className={`p-3 rounded-lg transition-all duration-200 hover-lift ${
                    currentView === 'leaderboard'
                      ? 'bg-gradient-to-r from-blue-500 to-emerald-500 text-white shadow-lg'
                      : 'text-slate-600 dark:text-gray-300 hover:bg-white/70 dark:hover:bg-gray-700/70 hover:text-slate-800 dark:hover:text-white'
                  }`}
                  title="Leaderboard"
                >
                  <Trophy className="w-5 h-5" />
                </button>
                
                <button
                  onClick={() => onViewChange('profile')}
                  className={`p-3 rounded-lg transition-all duration-200 hover-lift ${
                    currentView === 'profile'
                      ? 'bg-gradient-to-r from-blue-500 to-emerald-500 text-white shadow-lg'
                      : 'text-slate-600 dark:text-gray-300 hover:bg-white/70 dark:hover:bg-gray-700/70 hover:text-slate-800 dark:hover:text-white'
                  }`}
                  title="Profile"
                >
                  <User className="w-5 h-5" />
                </button>
              </div>

              {/* User Info */}
              <div className="flex items-center space-x-3 ml-4 pl-4 border-l border-white/30 dark:border-gray-700/30">
                <div className="text-right">
                  <p className="font-semibold text-slate-800 dark:text-white">{profile?.name}</p>
                  <p className="text-xs text-slate-500 bg-gradient-to-r from-blue-500 to-emerald-500 bg-clip-text text-transparent">
                    Level {profile?.level} Explorer
                  </p>
                </div>
                <div className="w-10 h-10 bg-gradient-to-br from-blue-600 to-emerald-500 rounded-full flex items-center justify-center shadow-lg hover-lift">
                  <span className="font-bold text-white">
                    {profile?.name?.charAt(0).toUpperCase()}
                  </span>
                </div>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={handleSignOut}
                  className="p-2 hover:bg-red-50 hover:text-red-600 rounded-lg transition-all duration-200"
                  title="Sign Out"
                >
                  <LogOut className="w-4 h-4" />
                </Button>
              </div>
            </>
          ) : (
            <div className="flex items-center space-x-2">
              <Button 
                onClick={onAuthClick}
                variant="ghost"
                className="text-slate-600 dark:text-gray-300 hover:text-slate-800 dark:hover:text-white"
              >
                Sign In
              </Button>
              <Button 
                onClick={onAuthClick}
                className="bg-gradient-to-r from-blue-600 to-emerald-500 hover:from-blue-700 hover:to-emerald-600 px-6 py-2 rounded-xl shadow-lg hover-lift"
              >
                Get Started
              </Button>
            </div>
          )}
        </div>
      </div>
    </nav>
  );
}