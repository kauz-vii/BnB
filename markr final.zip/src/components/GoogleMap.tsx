import { useEffect, useRef, useState } from 'react';
import { Button } from './ui/button';
import { Card, CardContent } from './ui/card';
import { Badge } from './ui/badge';
import { 
  Navigation, 
  Phone, 
  MapPin, 
  Home, 
  UtensilsCrossed, 
  Heart, 
  Shield, 
  ShoppingBag, 
  AlertTriangle,
  Star,
  Locate
} from 'lucide-react';

interface GoogleMapProps {
  center: [number, number];
  zoom: number;
  markers?: MapMarker[];
  onMarkerClick?: (marker: MapMarker) => void;
  onMapClick?: (coordinates: [number, number]) => void;
  userLocation?: [number, number] | null;
  apiKey: string;
  showDirections?: boolean;
  directionsFrom?: [number, number];
  directionsTo?: [number, number];
}

interface MapMarker {
  id: string;
  position: [number, number];
  title: string;
  type: 'food' | 'toilet' | 'attraction' | 'note' | 'shelter' | 'medical' | 'safe-point' | 'shop' | 'emergency';
  info?: {
    name: string;
    type: string;
    address?: string;
    phone?: string;
    services?: string[];
    isActive?: boolean;
    description?: string;
  };
}

const typeIcons = {
  food: UtensilsCrossed,
  toilet: Home,
  attraction: Star,
  note: MapPin,
  shelter: Home,
  medical: Heart,
  'safe-point': Shield,
  shop: ShoppingBag,
  emergency: AlertTriangle
};

const typeColors = {
  food: '#f97316',
  toilet: '#3b82f6',
  attraction: '#eab308',
  note: '#6b7280',
  shelter: '#3b82f6',
  medical: '#ef4444',
  'safe-point': '#22c55e',
  shop: '#8b5cf6',
  emergency: '#eab308'
};

export function GoogleMap({ 
  center, 
  zoom, 
  markers = [], 
  onMarkerClick, 
  onMapClick, 
  userLocation,
  apiKey,
  showDirections = false,
  directionsFrom,
  directionsTo
}: GoogleMapProps) {
  const mapRef = useRef<HTMLDivElement>(null);
  const mapInstanceRef = useRef<google.maps.Map | null>(null);
  const markersRef = useRef<google.maps.Marker[]>([]);
  const infoWindowRef = useRef<google.maps.InfoWindow | null>(null);
  const directionsServiceRef = useRef<google.maps.DirectionsService | null>(null);
  const directionsRendererRef = useRef<google.maps.DirectionsRenderer | null>(null);
  const userLocationMarkerRef = useRef<google.maps.Marker | null>(null);
  const [isLoaded, setIsLoaded] = useState(false);
  const [selectedMarker, setSelectedMarker] = useState<MapMarker | null>(null);

  // Load Google Maps API
  useEffect(() => {
    // Check if API key is valid (not placeholder)
    if (apiKey === 'YOUR_GOOGLE_MAPS_API_KEY' || !apiKey || apiKey === 'DEMO_MODE') {
      console.warn('Google Maps API key not configured. Using fallback map.');
      return;
    }

    if (window.google && window.google.maps) {
      setIsLoaded(true);
      return;
    }

    // Check if script is already loading
    const existingScript = document.querySelector(`script[src*="maps.googleapis.com"]`);
    if (existingScript) {
      existingScript.addEventListener('load', () => setIsLoaded(true));
      return;
    }

    const script = document.createElement('script');
    script.src = `https://maps.googleapis.com/maps/api/js?key=${apiKey}&libraries=places,geometry&loading=async`;
    script.async = true;
    script.defer = true;
    script.onload = () => setIsLoaded(true);
    script.onerror = () => {
      console.error('Failed to load Google Maps API');
      setIsLoaded(false);
    };
    document.head.appendChild(script);

    return () => {
      // Don't remove script on cleanup as it might be used by other components
    };
  }, [apiKey]);

  // Initialize map
  useEffect(() => {
    if (!isLoaded || !mapRef.current) return;

    const map = new google.maps.Map(mapRef.current, {
      center: { lat: center[0], lng: center[1] },
      zoom: zoom,
      styles: [
        {
          featureType: 'poi',
          elementType: 'labels.text',
          stylers: [{ visibility: 'off' }]
        }
      ],
      mapTypeControl: true,
      streetViewControl: true,
      fullscreenControl: true,
      zoomControl: true
    });

    mapInstanceRef.current = map;

    // Initialize services
    directionsServiceRef.current = new google.maps.DirectionsService();
    directionsRendererRef.current = new google.maps.DirectionsRenderer({
      draggable: true,
      panel: null
    });
    directionsRendererRef.current.setMap(map);

    // Initialize info window
    infoWindowRef.current = new google.maps.InfoWindow();

    // Add click listener for map
    map.addListener('click', (event: google.maps.MapMouseEvent) => {
      if (event.latLng && onMapClick) {
        const lat = event.latLng.lat();
        const lng = event.latLng.lng();
        onMapClick([lat, lng]);
      }
    });

    return () => {
      if (mapInstanceRef.current) {
        google.maps.event.clearInstanceListeners(mapInstanceRef.current);
      }
    };
  }, [isLoaded, center, zoom, onMapClick]);

  // Update map center and zoom
  useEffect(() => {
    if (mapInstanceRef.current) {
      mapInstanceRef.current.setCenter({ lat: center[0], lng: center[1] });
      mapInstanceRef.current.setZoom(zoom);
    }
  }, [center, zoom]);

  // Update markers
  useEffect(() => {
    if (!mapInstanceRef.current || !window.google?.maps) return;

    // Clear existing markers
    markersRef.current.forEach(marker => marker.setMap(null));
    markersRef.current = [];

    // Add new markers
    markers.forEach(markerData => {
      // Create custom marker icon
      const markerElement = document.createElement('div');
      markerElement.className = 'custom-marker';
      markerElement.innerHTML = `
        <div style="
          background-color: ${typeColors[markerData.type] || '#6b7280'};
          width: 32px;
          height: 32px;
          border-radius: 50%;
          display: flex;
          align-items: center;
          justify-content: center;
          color: white;
          box-shadow: 0 2px 4px rgba(0,0,0,0.3);
          border: 2px solid white;
        ">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor">
            ${getIconSVG(markerData.type)}
          </svg>
        </div>
      `;

      // Check if AdvancedMarkerElement is available
      let marker;
      if (google.maps.marker?.AdvancedMarkerElement) {
        marker = new google.maps.marker.AdvancedMarkerElement({
          map: mapInstanceRef.current,
          position: { lat: markerData.position[0], lng: markerData.position[1] },
          content: markerElement,
          title: markerData.title
        });
      } else {
        // Fallback to regular marker
        marker = new google.maps.Marker({
          map: mapInstanceRef.current,
          position: { lat: markerData.position[0], lng: markerData.position[1] },
          title: markerData.title,
          icon: {
            url: `data:image/svg+xml;charset=UTF-8,${encodeURIComponent(`
              <svg width="32" height="32" viewBox="0 0 32 32" xmlns="http://www.w3.org/2000/svg">
                <circle cx="16" cy="16" r="14" fill="${typeColors[markerData.type] || '#6b7280'}" stroke="white" stroke-width="2"/>
                <svg x="8" y="8" width="16" height="16" viewBox="0 0 24 24" fill="white">
                  <path d="${getIconSVG(markerData.type)}"/>
                </svg>
              </svg>
            `)}`,
            scaledSize: new google.maps.Size(32, 32),
            anchor: new google.maps.Point(16, 16)
          }
        });
      }

      // Add click listener
      marker.addListener('click', () => {
        setSelectedMarker(markerData);
        if (onMarkerClick) {
          onMarkerClick(markerData);
        }

        // Show info window
        if (infoWindowRef.current && markerData.info) {
          const content = createInfoWindowContent(markerData);
          infoWindowRef.current.setContent(content);
          infoWindowRef.current.open(mapInstanceRef.current, marker);
        }
      });

      markersRef.current.push(marker as any);
    });
  }, [markers, onMarkerClick]);

  // Update user location marker
  useEffect(() => {
    if (!mapInstanceRef.current || !window.google?.maps) return;

    // Remove existing user location marker
    if (userLocationMarkerRef.current) {
      userLocationMarkerRef.current.setMap(null);
    }

    // Add new user location marker
    if (userLocation) {
      const userMarkerElement = document.createElement('div');
      userMarkerElement.innerHTML = `
        <div style="
          background-color: #3b82f6;
          width: 20px;
          height: 20px;
          border-radius: 50%;
          border: 3px solid white;
          box-shadow: 0 2px 8px rgba(59, 130, 246, 0.5);
        "></div>
      `;

      // Check if AdvancedMarkerElement is available
      if (google.maps.marker?.AdvancedMarkerElement) {
        userLocationMarkerRef.current = new google.maps.marker.AdvancedMarkerElement({
          map: mapInstanceRef.current,
          position: { lat: userLocation[0], lng: userLocation[1] },
          content: userMarkerElement,
          title: 'Your Location'
        }) as any;
      } else {
        // Fallback to regular marker
        userLocationMarkerRef.current = new google.maps.Marker({
          map: mapInstanceRef.current,
          position: { lat: userLocation[0], lng: userLocation[1] },
          title: 'Your Location',
          icon: {
            url: `data:image/svg+xml;charset=UTF-8,${encodeURIComponent(`
              <svg width="20" height="20" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                <circle cx="10" cy="10" r="8" fill="#3b82f6" stroke="white" stroke-width="3"/>
              </svg>
            `)}`,
            scaledSize: new google.maps.Size(20, 20),
            anchor: new google.maps.Point(10, 10)
          }
        }) as any;
      }
    }
  }, [userLocation]);

  // Handle directions
  useEffect(() => {
    if (!mapInstanceRef.current || !directionsServiceRef.current || !directionsRendererRef.current) return;
    if (!showDirections || !directionsFrom || !directionsTo) {
      directionsRendererRef.current.setDirections({ routes: [] } as any);
      return;
    }

    const request: google.maps.DirectionsRequest = {
      origin: { lat: directionsFrom[0], lng: directionsFrom[1] },
      destination: { lat: directionsTo[0], lng: directionsTo[1] },
      travelMode: google.maps.TravelMode.DRIVING
    };

    directionsServiceRef.current.route(request, (result, status) => {
      if (status === 'OK' && result && directionsRendererRef.current) {
        directionsRendererRef.current.setDirections(result);
      }
    });
  }, [showDirections, directionsFrom, directionsTo]);

  const getIconSVG = (type: string): string => {
    const iconPaths = {
      food: 'M11 9H9V2H7v7H5V2H3v7c0 2.12 1.66 3.84 3.75 3.97V22h2.5v-9.03C11.34 12.84 13 11.12 13 9V2h-2v7zm5-3v8h2.5v8H21V2c-2.76 0-5 2.24-5 4z',
      medical: 'M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z',
      shelter: 'M10 20v-6h4v6h5v-8h3L12 3 2 12h3v8z',
      'safe-point': 'M12,1L3,5V11C3,16.55 6.84,21.74 12,23C17.16,21.74 21,16.55 21,11V5L12,1M12,7C13.4,7 14.8,8.6 14.8,10V11H16V17H8V11H9.2V10C9.2,8.6 10.6,7 12,7M12,8.2C11.2,8.2 10.4,8.7 10.4,10V11H13.6V10C13.6,8.7 12.8,8.2 12,8.2Z',
      shop: 'M7 18c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2zM1 2v2h2l3.6 7.59-1.35 2.45c-.16.28-.25.61-.25.96 0 1.1.9 2 2 2h12v-2H7.42c-.14 0-.25-.11-.25-.25l.03-.12L8.1 13h7.45c.75 0 1.41-.41 1.75-1.03L21.7 4H5.21l-.94-2H1zm16 16c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2z',
      emergency: 'M1 21h22L12 2 1 21zm12-3h-2v-2h2v2zm0-4h-2v-4h2v4z',
      default: 'M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7zm0 9.5c-1.38 0-2.5-1.12-2.5-2.5s1.12-2.5 2.5-2.5 2.5 1.12 2.5 2.5-1.12 2.5-2.5 2.5z'
    };
    return iconPaths[type as keyof typeof iconPaths] || iconPaths.default;
  };

  const createInfoWindowContent = (marker: MapMarker): string => {
    if (!marker.info) return `<div>${marker.title}</div>`;

    return `
      <div style="padding: 12px; min-width: 200px;">
        <h3 style="margin: 0 0 8px 0; font-weight: 600; color: #1f2937;">${marker.info.name}</h3>
        <div style="margin-bottom: 8px;">
          <span style="background: ${typeColors[marker.type]}; color: white; padding: 2px 8px; border-radius: 12px; font-size: 12px; text-transform: capitalize;">
            ${marker.info.type.replace('-', ' ')}
          </span>
          ${marker.info.isActive ? 
            '<span style="background: #22c55e; color: white; padding: 2px 8px; border-radius: 12px; font-size: 12px; margin-left: 4px;">Active</span>' : 
            '<span style="background: #6b7280; color: white; padding: 2px 8px; border-radius: 12px; font-size: 12px; margin-left: 4px;">Inactive</span>'
          }
        </div>
        ${marker.info.address ? `<p style="margin: 4px 0; color: #6b7280; font-size: 14px;">${marker.info.address}</p>` : ''}
        ${marker.info.phone ? `<p style="margin: 4px 0; color: #6b7280; font-size: 14px;">📞 ${marker.info.phone}</p>` : ''}
        ${marker.info.description ? `<p style="margin: 8px 0; color: #374151; font-size: 14px;">${marker.info.description}</p>` : ''}
        ${marker.info.services ? `
          <div style="margin: 8px 0;">
            <strong style="color: #374151; font-size: 12px;">Services:</strong>
            <div style="margin-top: 4px;">
              ${marker.info.services.map(service => 
                `<span style="background: #f3f4f6; color: #374151; padding: 2px 6px; border-radius: 8px; font-size: 11px; margin-right: 4px; margin-bottom: 2px; display: inline-block;">${service}</span>`
              ).join('')}
            </div>
          </div>
        ` : ''}
      </div>
    `;
  };

  const getCurrentLocation = () => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          const { latitude, longitude } = position.coords;
          if (mapInstanceRef.current) {
            mapInstanceRef.current.setCenter({ lat: latitude, lng: longitude });
            mapInstanceRef.current.setZoom(16);
          }
        },
        (error) => {
          console.error('Error getting location:', error);
          alert('Unable to get your location. Please enable location services.');
        }
      );
    } else {
      alert('Geolocation is not supported by this browser.');
    }
  };

  // Show fallback if API key is invalid or not configured
  if (apiKey === 'YOUR_GOOGLE_MAPS_API_KEY' || !apiKey || apiKey === 'DEMO_MODE') {
    return (
      <div className="w-full h-full relative bg-gradient-to-br from-blue-100 to-emerald-100 dark:from-gray-700 dark:to-gray-800">
        <div className="absolute inset-0 flex items-center justify-center">
          <Card className="max-w-md mx-4 glassmorphism border-white/20 dark:border-gray-700/20 shadow-xl">
            <CardContent className="p-6 text-center">
              <MapPin className="w-12 h-12 mx-auto mb-4 text-blue-600" />
              <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-2">
                Google Maps Setup Required
              </h3>
              <p className="text-gray-600 dark:text-gray-300 mb-4">
                To enable interactive maps with full functionality, please configure your Google Maps API key.
              </p>
              <div className="space-y-3">
                <Button
                  onClick={() => {
                    // Open setup modal or navigate to setup page
                    const setupUrl = window.location.origin + '?setup=maps';
                    window.open(setupUrl, '_blank');
                  }}
                  className="w-full bg-gradient-to-r from-blue-600 to-emerald-500 hover:from-blue-700 hover:to-emerald-600 text-white"
                >
                  Set Up Google Maps
                </Button>
                <div className="bg-blue-50 dark:bg-blue-900/20 p-3 rounded-lg">
                  <p className="text-sm text-blue-700 dark:text-blue-300">
                    Free API key available from Google Cloud Console
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
        
        {/* Mock map overlay with markers */}
        <div className="absolute inset-0 opacity-20">
          <div className="w-full h-full bg-gradient-to-br from-blue-200 to-emerald-200 dark:from-gray-600 dark:to-gray-700">
            {markers.map((marker, index) => (
              <div
                key={marker.id}
                className="absolute w-6 h-6 bg-red-500 rounded-full border-2 border-white shadow-lg transform -translate-x-1/2 -translate-y-1/2"
                style={{
                  left: `${30 + (index * 15)}%`,
                  top: `${40 + (index * 10)}%`,
                }}
                title={marker.title}
              />
            ))}
          </div>
        </div>
      </div>
    );
  }

  if (!isLoaded) {
    return (
      <div className="w-full h-full flex items-center justify-center bg-gray-100 dark:bg-gray-800">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto mb-2"></div>
          <p className="text-gray-600 dark:text-gray-300">Loading map...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="relative w-full h-full">
      <div ref={mapRef} className="w-full h-full" />
      
      {/* Controls */}
      <div className="absolute top-4 right-4 space-y-2">
        <Button
          onClick={getCurrentLocation}
          size="sm"
          className="bg-white dark:bg-gray-800 text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-700 shadow-lg"
        >
          <Locate className="w-4 h-4" />
        </Button>
      </div>

      {/* Selected marker info panel */}
      {selectedMarker && selectedMarker.info && (
        <Card className="absolute bottom-4 left-4 max-w-sm glassmorphism border-white/20 dark:border-gray-700/20 shadow-xl">
          <CardContent className="p-4">
            <div className="flex items-start justify-between mb-2">
              <h3 className="font-semibold text-gray-900 dark:text-white">
                {selectedMarker.info.name}
              </h3>
              <Button
                size="sm"
                variant="ghost"
                onClick={() => setSelectedMarker(null)}
                className="h-6 w-6 p-0"
              >
                ×
              </Button>
            </div>
            <div className="space-y-2">
              <Badge
                className={`text-xs ${selectedMarker.info.isActive ? 'bg-green-500' : 'bg-gray-500'}`}
              >
                {selectedMarker.info.isActive ? 'Active' : 'Inactive'}
              </Badge>
              {selectedMarker.info.address && (
                <p className="text-sm text-gray-600 dark:text-gray-300">
                  {selectedMarker.info.address}
                </p>
              )}
              {selectedMarker.info.phone && (
                <div className="flex items-center gap-2">
                  <Phone className="w-3 h-3 text-gray-400" />
                  <span className="text-sm text-gray-600 dark:text-gray-300">
                    {selectedMarker.info.phone}
                  </span>
                </div>
              )}
              <div className="flex gap-2">
                <Button
                  size="sm"
                  onClick={() => {
                    const googleMapsUrl = `https://www.google.com/maps/dir/?api=1&destination=${selectedMarker.position[0]},${selectedMarker.position[1]}`;
                    window.open(googleMapsUrl, '_blank');
                  }}
                  className="flex-1"
                >
                  <Navigation className="w-3 h-3 mr-1" />
                  Directions
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Add CSS for pulse animation */}
      <style>{`
        @keyframes pulse {
          0% {
            transform: scale(1);
            opacity: 1;
          }
          50% {
            transform: scale(1.2);
            opacity: 0.7;
          }
          100% {
            transform: scale(1);
            opacity: 1;
          }
        }
        .pulse-animation {
          animation: pulse 2s infinite;
        }
      `}</style>
    </div>
  );
}