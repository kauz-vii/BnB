import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { ArrowUp, ArrowDown, MessageSquare, Star, CheckCircle, Clock, User, Eye, Share, Bookmark, Flag } from 'lucide-react';
import { useAuth, useQuestions, useAnswers, useVotes } from '../contexts/DataProvider';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Card } from './ui/card';
import { Textarea } from './ui/textarea';

interface QuestionDetailProps {
  questionId: string;
  onNavigateToProfile: (userId: string) => void;
}

export default function QuestionDetail({ questionId, onNavigateToProfile }: QuestionDetailProps) {
  const { user } = useAuth();
  const { getQuestionById } = useQuestions();
  const { getAnswersByQuestion, createAnswer, acceptAnswer, rateAnswer, getAnswerRating } = useAnswers();
  const { castVote, getVoteScore, getUserVote } = useVotes();
  
  const [newAnswer, setNewAnswer] = useState('');
  const [loading, setLoading] = useState(false);

  const question = getQuestionById(questionId);
  const answers = getAnswersByQuestion(questionId);

  const handleVote = async (type: 'UP' | 'DOWN', targetType: 'question' | 'answer', targetId: string) => {
    if (!user) return;
    
    try {
      if (targetType === 'question') {
        await castVote(user.id, type, questionId);
      } else {
        await castVote(user.id, type, undefined, targetId);
      }
    } catch (error) {
      console.error('Vote failed:', error);
    }
  };

  const handleAcceptAnswer = (answerId: string) => {
    if (!user || !question || question.authorId !== user.id) return;
    acceptAnswer(answerId);
  };

  const handleRateAnswer = (answerId: string, stars: number) => {
    if (!user || !question || question.authorId !== user.id) return;
    rateAnswer(answerId, user.id, stars);
  };

  const handleSubmitAnswer = async () => {
    if (!newAnswer.trim() || !user) return;
    
    setLoading(true);
    try {
      await createAnswer(questionId, newAnswer, user.id);
      setNewAnswer('');
    } catch (error) {
      console.error('Failed to submit answer:', error);
    } finally {
      setLoading(false);
    }
  };

  const formatTimeAgo = (date: Date) => {
    const now = new Date();
    const diff = now.getTime() - date.getTime();
    const hours = Math.floor(diff / (1000 * 60 * 60));
    
    if (hours < 1) return 'just now';
    if (hours === 1) return '1 hour ago';
    if (hours < 24) return `${hours} hours ago`;
    
    const days = Math.floor(hours / 24);
    if (days === 1) return '1 day ago';
    return `${days} days ago`;
  };

  const getUserLevel = (reputation: number) => {
    if (reputation >= 1600) return { name: 'Moderator', color: 'bg-gradient-to-r from-iron-red to-iron-gold' };
    if (reputation >= 900) return { name: 'Guru', color: 'bg-gradient-to-r from-iron-gold to-iron-bright-gold' };
    if (reputation >= 400) return { name: 'Expert', color: 'bg-iron-bright-gold' };
    if (reputation >= 150) return { name: 'Helpful', color: 'bg-iron-gold' };
    if (reputation >= 50) return { name: 'Contributor', color: 'bg-iron-red' };
    return { name: 'Newbie', color: 'bg-iron-gray' };
  };

  if (!question) {
    return (
      <div className="p-6">
        <div className="max-w-4xl mx-auto">
          <div className="text-center py-12">
            <div className="text-iron-gray mb-4">
              <MessageSquare className="w-16 h-16 mx-auto mb-4 opacity-50" />
              <h3 className="text-xl font-semibold mb-2">Question not found</h3>
              <p>The question you're looking for doesn't exist or has been removed.</p>
            </div>
          </div>
        </div>
      </div>
    );
  }

  const isQuestionAuthor = user?.id === question.author.id;
  const userLevel = getUserLevel(question.author.reputation);
  const questionScore = getVoteScore(questionId);
  const questionUserVote = user ? getUserVote(user.id, questionId) : null;

  return (
    <div className="p-6">
      <div className="max-w-4xl mx-auto space-y-6">
        {/* Question Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
        >
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center space-x-3 text-sm text-iron-gray">
              <span>Question</span>
              <span>•</span>
              <div className="flex items-center space-x-1">
                <Eye className="w-4 h-4" />
                <span>{question.views} views</span>
              </div>
              <span>•</span>
              <div className="flex items-center space-x-1">
                <Clock className="w-4 h-4" />
                <span>Asked {formatTimeAgo(question.createdAt)}</span>
              </div>
            </div>
            
            <div className="flex items-center space-x-2">
              <Button variant="ghost" size="sm" className="text-iron-gray hover:text-iron-white">
                <Share className="w-4 h-4 mr-1" />
                Share
              </Button>
              <Button variant="ghost" size="sm" className="text-iron-gray hover:text-iron-white">
                <Bookmark className="w-4 h-4 mr-1" />
                Save
              </Button>
              <Button variant="ghost" size="sm" className="text-iron-gray hover:text-iron-red">
                <Flag className="w-4 h-4 mr-1" />
                Report
              </Button>
            </div>
          </div>

          <h1 className="text-3xl font-poppins font-black text-iron-white mb-6 heading-shadow">
            {question.title}
          </h1>
        </motion.div>

        {/* Question Content */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
        >
          <Card className="p-6 bg-iron-card border-iron-dark-gray">
            <div className="flex space-x-4">
              {/* Vote Section */}
              <div className="flex flex-col items-center space-y-2">
                <Button
                  variant="ghost"
                  size="sm"
                  className={`p-2 transition-colors ${
                    questionUserVote?.type === 'UP' 
                      ? 'text-iron-gold' 
                      : 'text-iron-gray hover:text-iron-gold'
                  }`}
                  onClick={() => handleVote('UP', 'question', question.id)}
                  disabled={!user || question.authorId === user.id}
                >
                  <ArrowUp className="w-6 h-6" />
                </Button>
                <span className="text-2xl font-bold text-iron-white">
                  {questionScore}
                </span>
                <Button
                  variant="ghost"
                  size="sm"
                  className={`p-2 transition-colors ${
                    questionUserVote?.type === 'DOWN' 
                      ? 'text-iron-red' 
                      : 'text-iron-gray hover:text-iron-red'
                  }`}
                  onClick={() => handleVote('DOWN', 'question', question.id)}
                  disabled={!user || question.authorId === user.id}
                >
                  <ArrowDown className="w-6 h-6" />
                </Button>
              </div>

              {/* Question Body */}
              <div className="flex-1">
                <div className="prose prose-invert max-w-none mb-6">
                  <div 
                    className="text-iron-light-gray leading-relaxed whitespace-pre-wrap"
                    dangerouslySetInnerHTML={{ 
                      __html: question.body
                        .replace(/\*\*(.*?)\*\*/g, '<strong class="text-iron-white">$1</strong>')
                        .replace(/`([^`]+)`/g, '<code class="bg-iron-black px-1 py-0.5 rounded text-iron-gold">$1</code>')
                        .replace(/```([^```]+)```/g, '<pre class="bg-iron-black p-4 rounded-lg overflow-x-auto"><code class="text-iron-gold">$1</code></pre>')
                    }}
                  />
                </div>

                {/* Tags */}
                <div className="flex flex-wrap gap-2 mb-4">
                  {question.tags.map((tag) => (
                    <Badge
                      key={tag}
                      variant="secondary"
                      className="bg-iron-black/50 text-iron-gold border-iron-dark-gray hover:bg-iron-gold hover:text-iron-black cursor-pointer transition-colors"
                    >
                      {tag}
                    </Badge>
                  ))}
                </div>

                {/* Author Info */}
                <div className="flex justify-end">
                  <div 
                    className="flex items-center space-x-3 p-3 bg-iron-black/30 rounded-lg cursor-pointer hover:bg-iron-black/50 transition-colors"
                    onClick={() => onNavigateToProfile(question.author.id)}
                  >
                    <div className="w-10 h-10 bg-iron-gold rounded-full flex items-center justify-center">
                      <User className="w-5 h-5 text-iron-black" />
                    </div>
                    <div>
                      <div className="font-semibold text-iron-white">
                        {question.author.username}
                      </div>
                      <div className="flex items-center space-x-2 text-sm">
                        <div className={`w-3 h-3 rounded-full ${userLevel.color}`}></div>
                        <span className="text-iron-gold">{question.author.reputation}</span>
                        <span className="text-iron-gray">•</span>
                        <span className="text-iron-gray">{userLevel.name}</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </Card>
        </motion.div>

        {/* Answers Section */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
        >
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-2xl font-poppins font-bold text-iron-white heading-shadow">
              {answers.length} Answer{answers.length !== 1 ? 's' : ''}
            </h2>
            <select className="bg-iron-black border border-iron-dark-gray text-iron-white rounded px-3 py-1 text-sm">
              <option>Highest score (default)</option>
              <option>Date modified (newest first)</option>
              <option>Date created (oldest first)</option>
            </select>
          </div>

          <div className="space-y-6">
            {answers.map((answer, index) => {
              const answerUserLevel = getUserLevel(answer.author.reputation);
              const canRate = isQuestionAuthor && answer.author.id !== user?.id;
              const answerScore = getVoteScore(undefined, answer.id);
              const answerUserVote = user ? getUserVote(user.id, undefined, answer.id) : null;
              const existingRating = canRate ? getAnswerRating(answer.id, user.id) : null;
              
              return (
                <motion.div
                  key={answer.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.3 + index * 0.1 }}
                >
                  <Card className={`p-6 border-iron-dark-gray ${answer.isAccepted ? 'bg-iron-card border-iron-gold' : 'bg-iron-card'}`}>
                    {answer.isAccepted && (
                      <div className="flex items-center space-x-2 mb-4 text-iron-gold">
                        <CheckCircle className="w-5 h-5" />
                        <span className="font-semibold">Accepted Answer</span>
                      </div>
                    )}
                    
                    <div className="flex space-x-4">
                      {/* Vote Section */}
                      <div className="flex flex-col items-center space-y-2">
                        <Button
                          variant="ghost"
                          size="sm"
                          className={`p-2 transition-colors ${
                            answerUserVote?.type === 'UP' 
                              ? 'text-iron-gold' 
                              : 'text-iron-gray hover:text-iron-gold'
                          }`}
                          onClick={() => handleVote('UP', 'answer', answer.id)}
                          disabled={!user || answer.authorId === user.id}
                        >
                          <ArrowUp className="w-5 h-5" />
                        </Button>
                        <span className="text-xl font-bold text-iron-white">
                          {answerScore}
                        </span>
                        <Button
                          variant="ghost"
                          size="sm"
                          className={`p-2 transition-colors ${
                            answerUserVote?.type === 'DOWN' 
                              ? 'text-iron-red' 
                              : 'text-iron-gray hover:text-iron-red'
                          }`}
                          onClick={() => handleVote('DOWN', 'answer', answer.id)}
                          disabled={!user || answer.authorId === user.id}
                        >
                          <ArrowDown className="w-5 h-5" />
                        </Button>
                        
                        {isQuestionAuthor && !answer.isAccepted && (
                          <Button
                            variant="ghost"
                            size="sm"
                            className="p-2 text-iron-gray hover:text-iron-gold mt-2"
                            onClick={() => handleAcceptAnswer(answer.id)}
                          >
                            <CheckCircle className="w-5 h-5" />
                          </Button>
                        )}
                      </div>

                      {/* Answer Content */}
                      <div className="flex-1">
                        <div 
                          className="prose prose-invert max-w-none mb-6 text-iron-light-gray leading-relaxed whitespace-pre-wrap"
                          dangerouslySetInnerHTML={{ 
                            __html: answer.body
                              .replace(/\*\*(.*?)\*\*/g, '<strong class="text-iron-white">$1</strong>')
                              .replace(/`([^`]+)`/g, '<code class="bg-iron-black px-1 py-0.5 rounded text-iron-gold">$1</code>')
                              .replace(/## (.*?)$/gm, '<h3 class="text-iron-gold font-bold text-lg mt-4 mb-2">$1</h3>')
                              .replace(/```([^```]+)```/g, '<pre class="bg-iron-black p-4 rounded-lg overflow-x-auto my-4"><code class="text-iron-gold">$1</code></pre>')
                          }}
                        />

                        {/* Rating Section (only for question author) */}
                        {canRate && (
                          <div className="mb-4 p-3 bg-iron-black/30 rounded-lg">
                            <div className="flex items-center space-x-2 mb-2">
                              <span className="text-sm text-iron-white">Rate this answer:</span>
                              <div className="flex space-x-1">
                                {[1, 2, 3, 4, 5].map((stars) => (
                                  <button
                                    key={stars}
                                    className={`transition-colors ${
                                      existingRating && existingRating.stars >= stars
                                        ? 'text-iron-gold'
                                        : 'text-iron-gray hover:text-iron-gold'
                                    }`}
                                    onClick={() => handleRateAnswer(answer.id, stars)}
                                  >
                                    <Star className="w-4 h-4" fill={existingRating && existingRating.stars >= stars ? 'currentColor' : 'none'} />
                                  </button>
                                ))}
                              </div>
                              {existingRating && (
                                <span className="text-iron-gold text-sm ml-2">
                                  ({existingRating.stars} stars)
                                </span>
                              )}
                            </div>
                            <p className="text-xs text-iron-gray">
                              Only you can rate answers to your question
                            </p>
                          </div>
                        )}

                        {/* Author and Timestamp */}
                        <div className="flex justify-between items-center">
                          <div className="text-sm text-iron-gray">
                            Answered {formatTimeAgo(answer.createdAt)}
                          </div>
                          <div 
                            className="flex items-center space-x-3 p-2 bg-iron-black/30 rounded-lg cursor-pointer hover:bg-iron-black/50 transition-colors"
                            onClick={() => onNavigateToProfile(answer.author.id)}
                          >
                            <div className="w-8 h-8 bg-iron-gold rounded-full flex items-center justify-center">
                              <User className="w-4 h-4 text-iron-black" />
                            </div>
                            <div>
                              <div className="font-semibold text-iron-white text-sm">
                                {answer.author.username}
                              </div>
                              <div className="flex items-center space-x-1 text-xs">
                                <div className={`w-2 h-2 rounded-full ${answerUserLevel.color}`}></div>
                                <span className="text-iron-gold">{answer.author.reputation}</span>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </Card>
                </motion.div>
              );
            })}
          </div>
        </motion.div>

        {/* Answer Form */}
        {user && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4 }}
          >
            <Card className="p-6 bg-iron-card border-iron-dark-gray">
              <h3 className="text-xl font-poppins font-bold text-iron-white mb-4 heading-shadow">
                Your Answer
              </h3>
              <Textarea
                placeholder="Write your answer here..."
                value={newAnswer}
                onChange={(e) => setNewAnswer(e.target.value)}
                className="min-h-[200px] bg-iron-black/50 border-iron-dark-gray text-iron-white placeholder-iron-gray focus:border-iron-gold resize-none"
              />
              <div className="flex justify-between items-center mt-4">
                <p className="text-sm text-iron-gray">
                  Use markdown for formatting. Be helpful and constructive.
                </p>
                <Button
                  onClick={handleSubmitAnswer}
                  disabled={!newAnswer.trim() || loading}
                  className="bg-iron-gold hover:bg-iron-bright-gold text-iron-black font-semibold"
                >
                  {loading ? 'Posting...' : 'Post Your Answer'}
                </Button>
              </div>
            </Card>
          </motion.div>
        )}
      </div>
    </div>
  );
}