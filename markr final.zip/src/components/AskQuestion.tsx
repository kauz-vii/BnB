import { useState } from 'react';
import { motion } from 'framer-motion';
import { X, Plus, HelpCircle, Tags, FileText } from 'lucide-react';
import { useAuth, useQuestions, useTags } from '../contexts/DataProvider';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Textarea } from './ui/textarea';
import { Card } from './ui/card';
import { Badge } from './ui/badge';
import { Label } from './ui/label';

interface AskQuestionProps {
  onQuestionCreated: () => void;
}

export default function AskQuestion({ onQuestionCreated }: AskQuestionProps) {
  const { user } = useAuth();
  const { createQuestion } = useQuestions();
  const { getPopularTags, createTag, updateTagCount } = useTags();
  
  const [formData, setFormData] = useState({
    title: '',
    body: '',
    tags: [] as string[]
  });
  const [tagInput, setTagInput] = useState('');
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [isSubmitting, setIsSubmitting] = useState(false);

  const popularTags = getPopularTags(15).map(tag => tag.name);

  const handleTitleChange = (value: string) => {
    setFormData(prev => ({ ...prev, title: value }));
    if (errors.title) setErrors(prev => ({ ...prev, title: '' }));
  };

  const handleBodyChange = (value: string) => {
    setFormData(prev => ({ ...prev, body: value }));
    if (errors.body) setErrors(prev => ({ ...prev, body: '' }));
  };

  const handleAddTag = (tag: string) => {
    const normalizedTag = tag.toLowerCase().trim();
    if (normalizedTag && !formData.tags.includes(normalizedTag) && formData.tags.length < 5) {
      setFormData(prev => ({
        ...prev,
        tags: [...prev.tags, normalizedTag]
      }));
      setTagInput('');
      
      // Create tag if it doesn't exist
      createTag(normalizedTag);
    }
  };

  const handleRemoveTag = (tagToRemove: string) => {
    setFormData(prev => ({
      ...prev,
      tags: prev.tags.filter(tag => tag !== tagToRemove)
    }));
  };

  const handleTagInputKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' || e.key === ',') {
      e.preventDefault();
      handleAddTag(tagInput);
    }
  };

  const validateForm = () => {
    const newErrors: Record<string, string> = {};

    if (!formData.title.trim()) {
      newErrors.title = 'Title is required';
    } else if (formData.title.length < 10) {
      newErrors.title = 'Title must be at least 10 characters';
    }

    if (!formData.body.trim()) {
      newErrors.body = 'Question body is required';
    } else if (formData.body.length < 50) {
      newErrors.body = 'Question body must be at least 50 characters';
    }

    if (formData.tags.length === 0) {
      newErrors.tags = 'At least one tag is required';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validateForm() || !user) return;

    setIsSubmitting(true);

    try {
      await createQuestion(formData.title, formData.body, formData.tags, user.id);
      
      // Update tag counts
      formData.tags.forEach(tag => {
        updateTagCount(tag);
      });
      
      onQuestionCreated();
    } catch (error) {
      setErrors({ submit: 'Failed to submit question. Please try again.' });
    } finally {
      setIsSubmitting(false);
    }
  };

  const getUserLevel = () => {
    if (!user) return null;
    const levels = [
      { min: 0, name: 'Newbie', color: 'bg-iron-gray' },
      { min: 50, name: 'Contributor', color: 'bg-iron-red' },
      { min: 150, name: 'Helpful', color: 'bg-iron-gold' },
      { min: 400, name: 'Expert', color: 'bg-iron-bright-gold' },
      { min: 900, name: 'Guru', color: 'bg-gradient-to-r from-iron-gold to-iron-bright-gold' },
      { min: 1600, name: 'Moderator', color: 'bg-gradient-to-r from-iron-red to-iron-gold' },
    ];
    
    const userLevel = levels.reverse().find(level => user.reputation >= level.min) || levels[0];
    return userLevel;
  };

  const userLevel = getUserLevel();

  return (
    <div className="p-6">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8"
        >
          <h1 className="text-3xl font-poppins font-black text-iron-white mb-4 heading-shadow">
            Ask a Question
          </h1>
          <p className="text-iron-gray">
            Get help from our community of developers. Be specific and provide context.
          </p>
        </motion.div>

        {/* Guidelines */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="mb-6"
        >
          <Card className="p-6 bg-iron-card border-iron-dark-gray border-l-4 border-l-iron-gold">
            <div className="flex items-start space-x-3">
              <HelpCircle className="w-6 h-6 text-iron-gold mt-1 flex-shrink-0" />
              <div>
                <h3 className="font-poppins font-bold text-iron-white mb-2">
                  Writing a good question
                </h3>
                <ul className="text-sm text-iron-light-gray space-y-1">
                  <li>• Be specific about what you're trying to achieve</li>
                  <li>• Include relevant code, error messages, or examples</li>
                  <li>• Describe what you've already tried</li>
                  <li>• Use clear, descriptive titles</li>
                  <li>• Tag your question appropriately</li>
                </ul>
              </div>
            </div>
          </Card>
        </motion.div>

        {/* Question Form */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
        >
          <Card className="p-8 bg-iron-card border-iron-dark-gray">
            <form onSubmit={handleSubmit} className="space-y-6">
              {/* Title */}
              <div>
                <Label htmlFor="title" className="text-iron-white font-semibold mb-2 flex items-center">
                  <FileText className="w-4 h-4 mr-2" />
                  Question Title *
                </Label>
                <Input
                  id="title"
                  type="text"
                  placeholder="e.g., How to implement JWT authentication in React?"
                  value={formData.title}
                  onChange={(e) => handleTitleChange(e.target.value)}
                  className={`bg-iron-black/50 border-iron-dark-gray text-iron-white placeholder-iron-gray focus:border-iron-gold ${
                    errors.title ? 'border-iron-red' : ''
                  }`}
                />
                {errors.title && (
                  <p className="text-iron-red text-sm mt-1">{errors.title}</p>
                )}
                <p className="text-xs text-iron-gray mt-1">
                  Be specific and imagine you're asking a friend for help
                </p>
              </div>

              {/* Body */}
              <div>
                <Label htmlFor="body" className="text-iron-white font-semibold mb-2 flex items-center">
                  <FileText className="w-4 h-4 mr-2" />
                  Question Details *
                </Label>
                <Textarea
                  id="body"
                  placeholder="Describe your problem in detail. Include:
• What you're trying to accomplish
• Code examples or error messages
• What you've already tried
• Your expected vs actual results"
                  value={formData.body}
                  onChange={(e) => handleBodyChange(e.target.value)}
                  className={`min-h-[300px] bg-iron-black/50 border-iron-dark-gray text-iron-white placeholder-iron-gray focus:border-iron-gold resize-none ${
                    errors.body ? 'border-iron-red' : ''
                  }`}
                />
                {errors.body && (
                  <p className="text-iron-red text-sm mt-1">{errors.body}</p>
                )}
                <div className="flex justify-between items-center mt-1">
                  <p className="text-xs text-iron-gray">
                    Use markdown for code blocks and formatting
                  </p>
                  <span className={`text-xs ${formData.body.length >= 50 ? 'text-iron-gold' : 'text-iron-red'}`}>
                    {formData.body.length}/50 min
                  </span>
                </div>
              </div>

              {/* Tags */}
              <div>
                <Label htmlFor="tags" className="text-iron-white font-semibold mb-2 flex items-center">
                  <Tags className="w-4 h-4 mr-2" />
                  Tags * (up to 5)
                </Label>
                
                {/* Current Tags */}
                {formData.tags.length > 0 && (
                  <div className="flex flex-wrap gap-2 mb-3">
                    {formData.tags.map((tag) => (
                      <Badge
                        key={tag}
                        variant="secondary"
                        className="bg-iron-gold text-iron-black pr-1 flex items-center"
                      >
                        {tag}
                        <button
                          type="button"
                          onClick={() => handleRemoveTag(tag)}
                          className="ml-1 hover:bg-iron-black/20 rounded-full p-0.5"
                        >
                          <X className="w-3 h-3" />
                        </button>
                      </Badge>
                    ))}
                  </div>
                )}

                {/* Tag Input */}
                {formData.tags.length < 5 && (
                  <div className="flex space-x-2 mb-3">
                    <Input
                      type="text"
                      placeholder="Add a tag..."
                      value={tagInput}
                      onChange={(e) => setTagInput(e.target.value)}
                      onKeyPress={handleTagInputKeyPress}
                      className="bg-iron-black/50 border-iron-dark-gray text-iron-white placeholder-iron-gray focus:border-iron-gold"
                    />
                    <Button
                      type="button"
                      variant="outline"
                      onClick={() => handleAddTag(tagInput)}
                      disabled={!tagInput.trim()}
                      className="border-iron-dark-gray text-iron-white hover:bg-iron-black/30"
                    >
                      <Plus className="w-4 h-4" />
                    </Button>
                  </div>
                )}

                {/* Popular Tags */}
                <div>
                  <p className="text-sm text-iron-gray mb-2">Popular tags:</p>
                  <div className="flex flex-wrap gap-2">
                    {popularTags.slice(0, 10).map((tag) => (
                      <button
                        key={tag}
                        type="button"
                        onClick={() => handleAddTag(tag)}
                        disabled={formData.tags.includes(tag) || formData.tags.length >= 5}
                        className="text-xs px-2 py-1 bg-iron-black/30 text-iron-light-gray border border-iron-dark-gray rounded hover:bg-iron-black/50 hover:text-iron-white disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
                      >
                        {tag}
                      </button>
                    ))}
                  </div>
                </div>

                {errors.tags && (
                  <p className="text-iron-red text-sm mt-2">{errors.tags}</p>
                )}
              </div>

              {/* Submit Error */}
              {errors.submit && (
                <div className="p-3 bg-iron-red/20 border border-iron-red rounded-lg">
                  <p className="text-iron-red text-sm">{errors.submit}</p>
                </div>
              )}

              {/* Submit Button */}
              <div className="flex items-center justify-between pt-4">
                <div className="flex items-center space-x-3">
                  {user && userLevel && (
                    <div className="flex items-center space-x-2 text-sm text-iron-gray">
                      <div className={`w-3 h-3 rounded-full ${userLevel.color}`}></div>
                      <span>Posting as {user.username} ({userLevel.name})</span>
                    </div>
                  )}
                </div>

                <div className="flex space-x-3">
                  <Button
                    type="button"
                    variant="outline"
                    onClick={onQuestionCreated}
                    className="border-iron-dark-gray text-iron-white hover:bg-iron-black/30"
                  >
                    Cancel
                  </Button>
                  <Button
                    type="submit"
                    disabled={isSubmitting}
                    className="bg-iron-gold hover:bg-iron-bright-gold text-iron-black font-semibold px-8"
                  >
                    {isSubmitting ? (
                      <motion.div
                        animate={{ rotate: 360 }}
                        transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
                        className="w-4 h-4 border-2 border-iron-black border-t-transparent rounded-full mr-2"
                      />
                    ) : null}
                    {isSubmitting ? 'Posting...' : 'Post Question'}
                  </Button>
                </div>
              </div>
            </form>
          </Card>
        </motion.div>

        {/* Preview Section */}
        {(formData.title || formData.body) && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
            className="mt-8"
          >
            <Card className="p-6 bg-iron-card border-iron-dark-gray">
              <h3 className="text-lg font-poppins font-bold text-iron-white mb-4 heading-shadow">
                Preview
              </h3>
              
              {formData.title && (
                <h4 className="text-xl font-poppins font-bold text-iron-white mb-3">
                  {formData.title}
                </h4>
              )}
              
              {formData.body && (
                <div className="text-iron-light-gray mb-4 whitespace-pre-wrap">
                  {formData.body.slice(0, 200)}
                  {formData.body.length > 200 && '...'}
                </div>
              )}
              
              {formData.tags.length > 0 && (
                <div className="flex flex-wrap gap-2">
                  {formData.tags.map((tag) => (
                    <Badge
                      key={tag}
                      variant="secondary"
                      className="bg-iron-black/50 text-iron-gold border-iron-dark-gray"
                    >
                      {tag}
                    </Badge>
                  ))}
                </div>
              )}
            </Card>
          </motion.div>
        )}
      </div>
    </div>
  );
}