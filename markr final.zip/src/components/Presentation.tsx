import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Calendar, Star, Award, Zap, Heart, Shield, Target, TrendingUp, Lightbulb } from "lucide-react";

interface SlideData {
  id: number;
  title: string;
  subtitle?: string;
  content: string[];
  type: 'title' | 'content' | 'quote' | 'timeline';
  quote?: string;
  author?: string;
  year?: string;
  timeline?: Array<{
    year: string;
    event: string;
    description: string;
  }>;
  inspiration?: string[];
}

const slides: SlideData[] = [
  {
    id: 1,
    title: "Robert Downey Jr.",
    subtitle: "The Iron Man Legacy",
    content: ["From Rock Bottom to Global Icon", "A Story of Redemption, Resilience & Inspiration"],
    type: 'title'
  },
  {
    id: 2,
    title: "The Foundation",
    year: "1965-1985",
    content: [
      "Born into Hollywood royalty - son of filmmaker Robert Downey Sr.",
      "Early exposure to the entertainment industry and substance abuse",
      "Started acting at age 5 in his father's film 'Pound' (1970)",
      "Developed acting skills while battling personal demons from a young age"
    ],
    type: 'content',
    inspiration: ["Sometimes our greatest challenges begin where we least expect them"]
  },
  {
    id: 3,
    title: "Rising Star",
    year: "1985-2000",
    content: [
      "Breakthrough with Saturday Night Live cast member (1985-1986)",
      "Starred in critically acclaimed films like 'Less Than Zero' (1987)",
      "Academy Award nomination for 'Chaplin' (1992) - career peak",
      "Golden Globe win established him as a serious dramatic actor"
    ],
    type: 'content',
    inspiration: ["Talent alone isn't enough - it requires dedication and authenticity"]
  },
  {
    id: 4,
    title: "The Dark Years",
    year: "1996-2003",
    content: [
      "Multiple arrests for drug possession and substance abuse",
      "Career virtually destroyed - became uninsurable for major films",
      "Spent time in state prison and rehabilitation facilities",
      "Lost major roles and Hollywood status - hit absolute rock bottom"
    ],
    type: 'content',
    inspiration: ["The darkest moments often precede the greatest comebacks"]
  },
  {
    id: 5,
    title: "The Iron Man Transformation",
    year: "2008",
    content: [
      "Cast as Tony Stark despite studio concerns about his past",
      "Jon Favreau believed in his redemption story and natural fit",
      "Improvised much of the dialogue - brought authentic charisma",
      "Film grossed $585M worldwide - launched the Marvel Cinematic Universe"
    ],
    type: 'content',
    inspiration: ["Sometimes the perfect role finds you when you're ready to be found"]
  },
  {
    id: 6,
    title: "Building an Empire",
    year: "2008-2019",
    timeline: [
      { year: "2008-2013", event: "Iron Man Trilogy", description: "Established Tony Stark as iconic character" },
      { year: "2009-2011", event: "Sherlock Holmes Films", description: "Proved versatility beyond superhero genre" },
      { year: "2012-2019", event: "Avengers Saga", description: "Became the heart of Marvel Cinematic Universe" },
      { year: "2019", event: "Avengers: Endgame", description: "Delivered the ultimate sacrifice as Tony Stark" }
    ],
    type: 'timeline'
  },
  {
    id: 7,
    title: "The Complete Transformation",
    content: [
      "From Hollywood pariah to highest-paid actor in the world",
      "Earned over $75 million per film at his peak",
      "Became a symbol of redemption and second chances",
      "Used his platform to inspire others struggling with addiction"
    ],
    type: 'content',
    inspiration: ["True transformation is measured not by what you achieve, but who you become"]
  },
  {
    id: 8,
    title: "Why He Inspires Me",
    content: [
      "Proved that past mistakes don't define your future potential",
      "Showed incredible resilience in the face of public humiliation",
      "Transformed personal pain into authentic, relatable performances",
      "Became a mentor and positive influence for countless people"
    ],
    type: 'content',
    inspiration: ["Inspiration comes from those who rise after falling the hardest"]
  },
  {
    id: 9,
    title: "The Tony Stark Parallel",
    content: [
      "Both RDJ and Tony Stark were brilliant but flawed individuals",
      "Both hit rock bottom due to their own destructive behaviors",
      "Both found redemption through taking responsibility for their actions",
      "Both became heroes - one on screen, one in real life"
    ],
    type: 'content',
    inspiration: ["Sometimes fiction and reality merge to create the perfect story"]
  },
  {
    id: 10,
    title: "Legacy of Inspiration",
    content: ["Robert Downey Jr. didn't just play a superhero - he became one in real life"],
    quote: "Remember that just because you hit bottom doesn't mean you have to stay there.",
    author: "Robert Downey Jr.",
    type: 'quote',
    inspiration: [
      "That redemption is always possible",
      "That our lowest moments can become our greatest strengths",
      "That authenticity and vulnerability are true superpowers"
    ]
  }
];

export default function Presentation() {
  const [currentSlide, setCurrentSlide] = useState(0);

  const nextSlide = () => {
    if (currentSlide < slides.length - 1) {
      setCurrentSlide((prev) => prev + 1);
    }
  };

  const prevSlide = () => {
    if (currentSlide > 0) {
      setCurrentSlide((prev) => prev - 1);
    }
  };

  // Keyboard navigation
  useEffect(() => {
    const handleKeyDown = (event: KeyboardEvent) => {
      if (event.key === 'ArrowRight' || event.key === ' ') {
        event.preventDefault();
        nextSlide();
      } else if (event.key === 'ArrowLeft') {
        event.preventDefault();
        prevSlide();
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [currentSlide]);

  const slideVariants = {
    enter: (direction: number) => ({
      x: direction > 0 ? 1000 : -1000,
      opacity: 0
    }),
    center: {
      zIndex: 1,
      x: 0,
      opacity: 1
    },
    exit: (direction: number) => ({
      zIndex: 0,
      x: direction < 0 ? 1000 : -1000,
      opacity: 0
    })
  };

  const swipeConfidenceThreshold = 10000;
  const swipePower = (offset: number, velocity: number) => {
    return Math.abs(offset) * velocity;
  };

  return (
    <div className="min-h-screen bg-iron-gradient relative overflow-hidden">
      {/* Subtle Grid Background */}
      <div className="absolute inset-0 tech-grid opacity-30"></div>

      {/* Professional Header */}
      <div className="absolute top-6 left-6 z-50">
        <div className="flex items-center space-x-3 text-iron-gold font-inter font-semibold uppercase tracking-wider">
          <div className="w-2 h-2 bg-iron-gold rounded-full"></div>
          <span className="text-sm">PRESENTATION SYSTEM</span>
        </div>
      </div>

      <div className="absolute top-6 right-6 z-50">
        <div className="text-iron-gold font-poppins font-bold">
          <span className="text-lg">{String(currentSlide + 1).padStart(2, '0')}</span>
          <span className="text-iron-gray mx-1">/</span>
          <span className="text-sm">10</span>
        </div>
      </div>

      {/* Clean Corner Elements */}
      <div className="absolute top-0 left-0 w-16 h-16 border-l-2 border-t-2 border-iron-gold opacity-60"></div>
      <div className="absolute top-0 right-0 w-16 h-16 border-r-2 border-t-2 border-iron-gold opacity-60"></div>
      <div className="absolute bottom-0 left-0 w-16 h-16 border-l-2 border-b-2 border-iron-gold opacity-60"></div>
      <div className="absolute bottom-0 right-0 w-16 h-16 border-r-2 border-b-2 border-iron-gold opacity-60"></div>

      {/* Keyboard Navigation Hint */}
      <div className="absolute bottom-6 left-6 z-50">
        <div className="text-iron-gray font-inter text-xs uppercase tracking-wider opacity-60">
          Use Arrow Keys to Navigate
        </div>
      </div>

      {/* Main Content */}
      <div className="relative z-10 h-screen flex items-center justify-center">
        <div className="w-full max-w-7xl px-8">
          <AnimatePresence mode="wait" custom={currentSlide}>
            <motion.div
              key={currentSlide}
              custom={currentSlide}
              variants={slideVariants}
              initial="enter"
              animate="center"
              exit="exit"
              transition={{
                x: { type: "spring", stiffness: 300, damping: 30 },
                opacity: { duration: 0.3 }
              }}
              drag="x"
              dragConstraints={{ left: 0, right: 0 }}
              dragElastic={1}
              onDragEnd={(e, { offset, velocity }) => {
                const swipe = swipePower(offset.x, velocity.x);

                if (swipe < -swipeConfidenceThreshold) {
                  nextSlide();
                } else if (swipe > swipeConfidenceThreshold) {
                  prevSlide();
                }
              }}
              className="w-full"
            >
              <SlideRenderer slide={slides[currentSlide]} />
            </motion.div>
          </AnimatePresence>
        </div>
      </div>
    </div>
  );
}

function SlideRenderer({ slide }: { slide: SlideData }) {
  if (slide.type === 'title') {
    return (
      <div className="text-center space-y-12 max-w-6xl mx-auto">
        {/* Professional Logo */}
        <motion.div
          initial={{ scale: 0.8, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ duration: 0.8 }}
          className="mx-auto w-24 h-24 relative"
        >
          <div className="w-full h-full rounded-full bg-gradient-to-br from-iron-red to-iron-gold border-3 border-iron-white relative">
            <div className="absolute inset-3 rounded-full bg-iron-black border border-iron-red">
              <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-3 h-3 bg-iron-gold rounded-full"></div>
            </div>
          </div>
        </motion.div>

        <motion.h1
          initial={{ y: 30, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.3, duration: 0.8 }}
          className="text-7xl font-poppins font-black text-iron-white mb-4 heading-shadow"
        >
          {slide.title}
        </motion.h1>

        {slide.subtitle && (
          <motion.h2
            initial={{ y: 20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: 0.5, duration: 0.8 }}
            className="text-3xl font-inter font-bold text-iron-gold mb-8 heading-shadow"
          >
            {slide.subtitle}
          </motion.h2>
        )}

        <div className="space-y-4">
          {slide.content.map((item, index) => (
            <motion.p
              key={index}
              initial={{ y: 15, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              transition={{ delay: 0.7 + index * 0.1, duration: 0.6 }}
              className="text-xl font-roboto text-iron-light-gray max-w-4xl mx-auto leading-relaxed"
            >
              {item}
            </motion.p>
          ))}
        </div>
      </div>
    );
  }

  if (slide.type === 'quote') {
    return (
      <div className="text-center space-y-12 max-w-6xl mx-auto">
        <motion.h1
          initial={{ y: 30, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ duration: 0.8 }}
          className="text-6xl font-poppins font-black text-iron-red mb-16 heading-shadow"
        >
          {slide.title}
        </motion.h1>

        <motion.p
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.2, duration: 0.8 }}
          className="text-2xl font-roboto text-iron-white max-w-5xl mx-auto mb-12 leading-relaxed"
        >
          {slide.content[0]}
        </motion.p>

        {/* Professional Quote Container */}
        <motion.div
          initial={{ scale: 0.95, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ delay: 0.4, duration: 0.8 }}
          className="relative max-w-5xl mx-auto"
        >
          <div className="professional-card p-12 border-l-4 border-iron-gold">
            <div className="absolute top-0 left-0 w-6 h-6 border-l-2 border-t-2 border-iron-gold"></div>
            <div className="absolute top-0 right-0 w-6 h-6 border-r-2 border-t-2 border-iron-gold"></div>
            <div className="absolute bottom-0 left-0 w-6 h-6 border-l-2 border-b-2 border-iron-gold"></div>
            <div className="absolute bottom-0 right-0 w-6 h-6 border-r-2 border-b-2 border-iron-gold"></div>

            <blockquote className="text-3xl font-poppins font-bold italic text-iron-white text-center mb-6 leading-relaxed">
              "{slide.quote}"
            </blockquote>
            <cite className="text-iron-gold font-inter text-xl font-bold block text-center">
              — {slide.author}
            </cite>
          </div>
        </motion.div>

        {/* Inspiration Section */}
        {slide.inspiration && (
          <motion.div
            initial={{ y: 20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: 0.6, duration: 0.8 }}
            className="mt-16"
          >
            <h3 className="text-2xl font-poppins font-bold text-iron-gold mb-6 heading-shadow">His Legacy Teaches Us:</h3>
            <div className="space-y-4">
              {slide.inspiration.map((item, index) => (
                <motion.div
                  key={index}
                  initial={{ x: -15, opacity: 0 }}
                  animate={{ x: 0, opacity: 1 }}
                  transition={{ delay: 0.8 + index * 0.1, duration: 0.6 }}
                  className="flex items-center space-x-4"
                >
                  <Star className="w-5 h-5 text-iron-gold flex-shrink-0" fill="currentColor" />
                  <p className="text-lg font-roboto text-iron-light-gray">{item}</p>
                </motion.div>
              ))}
            </div>
          </motion.div>
        )}
      </div>
    );
  }

  if (slide.type === 'timeline') {
    return (
      <div className="max-w-6xl mx-auto">
        <motion.h1
          initial={{ y: 30, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ duration: 0.8 }}
          className="text-5xl font-poppins font-black text-iron-red mb-16 text-center heading-shadow"
        >
          {slide.title}
        </motion.h1>

        <div className="space-y-8 relative">
          <div className="absolute left-6 top-0 bottom-0 w-0.5 bg-gradient-to-b from-iron-gold via-iron-red to-iron-gold"></div>
          
          {slide.timeline?.map((item, index) => (
            <motion.div
              key={index}
              initial={{ x: -30, opacity: 0 }}
              animate={{ x: 0, opacity: 1 }}
              transition={{ delay: index * 0.15, duration: 0.6 }}
              className="relative pl-16"
            >
              <div className="absolute left-0 top-2 w-12 h-12 bg-iron-gold rounded-full flex items-center justify-center border-2 border-iron-red">
                <Calendar className="w-6 h-6 text-iron-black" />
              </div>
              
              <div className="professional-card p-6">
                <div className="flex items-center space-x-4 mb-4">
                  <span className="text-2xl font-poppins font-black text-iron-gold heading-shadow">{item.year}</span>
                  <span className="text-xl font-inter font-bold text-iron-white heading-shadow">{item.event}</span>
                </div>
                <p className="text-lg font-roboto text-iron-light-gray leading-relaxed">{item.description}</p>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    );
  }

  const getSlideIcon = (id: number) => {
    const iconProps = { className: "w-12 h-12 text-iron-gold", strokeWidth: 1.5 };
    switch (id) {
      case 2: return <Shield {...iconProps} />;
      case 3: return <TrendingUp {...iconProps} />;
      case 4: return <Heart {...iconProps} className="w-12 h-12 text-iron-red" />;
      case 5: return <Zap {...iconProps} className="w-12 h-12 text-iron-gold" />;
      case 7: return <Award {...iconProps} />;
      case 8: return <Lightbulb {...iconProps} className="w-12 h-12 text-iron-gold" />;
      case 9: return <Target {...iconProps} className="w-12 h-12 text-iron-red" />;
      default: return <Star {...iconProps} />;
    }
  };

  return (
    <div className="max-w-7xl mx-auto">
      {/* Year Badge */}
      {slide.year && (
        <motion.div
          initial={{ scale: 0.9, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ duration: 0.5 }}
          className="text-center mb-8"
        >
          <span className="inline-block bg-iron-gold text-iron-black px-6 py-2 rounded-full font-poppins font-black text-xl">
            {slide.year}
          </span>
        </motion.div>
      )}

      {/* Main Content Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-16 items-start">
        {/* Left Content (2/3) */}
        <motion.div
          initial={{ x: -30, opacity: 0 }}
          animate={{ x: 0, opacity: 1 }}
          transition={{ duration: 0.8 }}
          className="space-y-8 col-span-2"
        >
          <motion.h1
            initial={{ x: -20, opacity: 0 }}
            animate={{ x: 0, opacity: 1 }}
            transition={{ delay: 0.1, duration: 0.6 }}
            className="text-5xl font-poppins font-black text-iron-red mb-8 leading-tight heading-shadow"
          >
            {slide.title}
          </motion.h1>

          <div className="space-y-6 relative timeline-line">
            {slide.content.map((item, index) => (
              <motion.div
                key={index}
                initial={{ x: -15, opacity: 0 }}
                animate={{ x: 0, opacity: 1 }}
                transition={{ delay: 0.3 + index * 0.1, duration: 0.6 }}
                className="flex items-start space-x-4 timeline-dot relative"
              >
                <p className="text-xl font-roboto text-iron-white leading-relaxed pl-8">
                  {item}
                </p>
              </motion.div>
            ))}
          </div>

          {/* Inspiration Section */}
          {slide.inspiration && (
            <motion.div
              initial={{ y: 20, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              transition={{ delay: 0.6, duration: 0.8 }}
              className="mt-12 professional-card p-6 border-l-4 border-iron-gold"
            >
              <h3 className="text-xl font-poppins font-bold text-iron-gold mb-4 flex items-center heading-shadow">
                <Lightbulb className="w-6 h-6 mr-2" />
                Inspiration
              </h3>
              {slide.inspiration.map((item, index) => (
                <p key={index} className="text-lg font-roboto text-iron-light-gray italic">
                  {item}
                </p>
              ))}
            </motion.div>
          )}
        </motion.div>

        {/* Right Visual (1/3) */}
        <motion.div
          initial={{ x: 30, opacity: 0 }}
          animate={{ x: 0, opacity: 1 }}
          transition={{ delay: 0.4, duration: 0.8 }}
          className="flex items-center justify-center"
        >
          <div className="relative">
            {/* Professional Container */}
            <div className="w-64 h-64 professional-card border border-iron-dark-gray relative overflow-hidden">
              {/* Subtle Grid */}
              <div className="absolute inset-0 tech-grid opacity-15"></div>
              
              {/* Central Icon */}
              <div className="absolute inset-0 flex items-center justify-center z-10">
                {getSlideIcon(slide.id)}
              </div>
              
              {/* Clean Corners */}
              <div className="absolute top-2 left-2 w-6 h-6 border-l-2 border-t-2 border-iron-gold opacity-60"></div>
              <div className="absolute top-2 right-2 w-6 h-6 border-r-2 border-t-2 border-iron-gold opacity-60"></div>
              <div className="absolute bottom-2 left-2 w-6 h-6 border-l-2 border-b-2 border-iron-gold opacity-60"></div>
              <div className="absolute bottom-2 right-2 w-6 h-6 border-r-2 border-b-2 border-iron-gold opacity-60"></div>
            </div>

            {/* Simple Accent */}
            <div className="absolute -bottom-2 -right-2 w-4 h-4 bg-iron-red rounded-full"></div>
          </div>
        </motion.div>
      </div>
    </div>
  );
}