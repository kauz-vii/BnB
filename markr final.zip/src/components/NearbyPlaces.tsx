import { useState, useEffect } from 'react';
import { Navigation, MapPin, Clock, Star, Phone, Globe, Utensils, Coffee, ShoppingBag, Camera, Car, Fuel, Hospital, Search, Filter, List, Grid } from 'lucide-react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Badge } from './ui/badge';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import type { User } from '@supabase/supabase-js';

interface NearbyPlace {
  id: string;
  name: string;
  category: string;
  subcategory: string;
  address: string;
  distance: number;
  rating?: number;
  reviewCount?: number;
  priceLevel?: number;
  openingHours?: {
    isOpen: boolean;
    currentStatus: string;
    hours: string[];
  };
  contact?: {
    phone?: string;
    website?: string;
  };
  lat: number;
  lng: number;
  photos?: string[];
  description?: string;
  amenities?: string[];
  lastUpdated: string;
}

interface NearbyPlacesProps {
  user: User | null;
}

export function NearbyPlaces({ user }: NearbyPlacesProps) {
  const [nearbyPlaces, setNearbyPlaces] = useState<NearbyPlace[]>([]);
  const [filteredPlaces, setFilteredPlaces] = useState<NearbyPlace[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('all');
  const [radiusFilter, setRadiusFilter] = useState('5');
  const [sortBy, setSortBy] = useState('distance');
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('list');
  const [loading, setLoading] = useState(true);
  const [userLocation, setUserLocation] = useState<{ lat: number; lng: number } | null>(null);

  // Mock data - will be replaced with Google Places API or similar
  const mockNearbyPlaces: NearbyPlace[] = [
    {
      id: '1',
      name: "Joe's Coffee",
      category: 'Food & Drink',
      subcategory: 'Coffee Shop',
      address: '123 Main St, New York, NY 10001',
      distance: 0.2,
      rating: 4.5,
      reviewCount: 324,
      priceLevel: 2,
      openingHours: {
        isOpen: true,
        currentStatus: 'Open until 9:00 PM',
        hours: ['6:00 AM - 9:00 PM', '6:00 AM - 9:00 PM', '6:00 AM - 9:00 PM', '6:00 AM - 9:00 PM', '6:00 AM - 9:00 PM', '7:00 AM - 8:00 PM', '7:00 AM - 8:00 PM']
      },
      contact: {
        phone: '+1 (555) 123-4567',
        website: 'https://joescoffee.com'
      },
      lat: 40.7128,
      lng: -74.0060,
      amenities: ['WiFi', 'Outdoor Seating', 'Takeout'],
      description: 'Cozy neighborhood coffee shop with excellent espresso and pastries',
      lastUpdated: '2024-01-20T10:00:00Z'
    },
    {
      id: '2',
      name: 'Central Park',
      category: 'Attractions',
      subcategory: 'Park',
      address: 'Central Park, New York, NY',
      distance: 0.8,
      rating: 4.8,
      reviewCount: 12540,
      openingHours: {
        isOpen: true,
        currentStatus: 'Open 24 hours',
        hours: ['Open 24 hours']
      },
      lat: 40.7829,
      lng: -73.9654,
      amenities: ['Walking Trails', 'Playgrounds', 'Boating', 'Zoo'],
      description: 'Iconic urban park with lakes, trails, and recreational activities',
      lastUpdated: '2024-01-19T15:30:00Z'
    },
    {
      id: '3',
      name: 'Tech Repair Plus',
      category: 'Services',
      subcategory: 'Electronics Repair',
      address: '456 Broadway, New York, NY 10013',
      distance: 1.2,
      rating: 4.3,
      reviewCount: 89,
      priceLevel: 2,
      openingHours: {
        isOpen: false,
        currentStatus: 'Closed • Opens 9:00 AM Mon',
        hours: ['Closed', '9:00 AM - 6:00 PM', '9:00 AM - 6:00 PM', '9:00 AM - 6:00 PM', '9:00 AM - 6:00 PM', '9:00 AM - 6:00 PM', '10:00 AM - 4:00 PM']
      },
      contact: {
        phone: '+1 (555) 987-6543',
        website: 'https://techrepairplus.com'
      },
      lat: 40.7180,
      lng: -74.0020,
      amenities: ['Same Day Repair', 'Warranty', 'Pickup/Delivery'],
      description: 'Professional electronics and phone repair service',
      lastUpdated: '2024-01-18T12:15:00Z'
    },
    {
      id: '4',
      name: 'Fresh Market Deli',
      category: 'Food & Drink',
      subcategory: 'Grocery Store',
      address: '789 1st Ave, New York, NY 10009',
      distance: 0.5,
      rating: 4.1,
      reviewCount: 156,
      priceLevel: 2,
      openingHours: {
        isOpen: true,
        currentStatus: 'Open until 11:00 PM',
        hours: ['7:00 AM - 11:00 PM', '7:00 AM - 11:00 PM', '7:00 AM - 11:00 PM', '7:00 AM - 11:00 PM', '7:00 AM - 11:00 PM', '7:00 AM - 11:00 PM', '8:00 AM - 10:00 PM']
      },
      contact: {
        phone: '+1 (555) 456-7890'
      },
      lat: 40.7260,
      lng: -73.9780,
      amenities: ['Fresh Produce', 'Deli Counter', 'ATM', '24/7 Access'],
      description: 'Full-service grocery store with fresh produce and prepared foods',
      lastUpdated: '2024-01-20T08:45:00Z'
    },
    {
      id: '5',
      name: 'City Fitness Gym',
      category: 'Health & Fitness',
      subcategory: 'Gym',
      address: '321 Park Ave, New York, NY 10010',
      distance: 1.8,
      rating: 4.4,
      reviewCount: 267,
      priceLevel: 3,
      openingHours: {
        isOpen: true,
        currentStatus: 'Open until 10:00 PM',
        hours: ['5:00 AM - 10:00 PM', '5:00 AM - 10:00 PM', '5:00 AM - 10:00 PM', '5:00 AM - 10:00 PM', '5:00 AM - 10:00 PM', '6:00 AM - 8:00 PM', '6:00 AM - 8:00 PM']
      },
      contact: {
        phone: '+1 (555) 234-5678',
        website: 'https://cityfitnessnyc.com'
      },
      lat: 40.7390,
      lng: -73.9890,
      amenities: ['Free Weights', 'Cardio Equipment', 'Group Classes', 'Locker Rooms', 'Parking'],
      description: 'Modern fitness center with state-of-the-art equipment and group classes',
      lastUpdated: '2024-01-17T14:20:00Z'
    },
    {
      id: '6',
      name: 'Brooklyn Bridge',
      category: 'Attractions',
      subcategory: 'Historic Landmark',
      address: 'Brooklyn Bridge, New York, NY',
      distance: 2.1,
      rating: 4.7,
      reviewCount: 8934,
      openingHours: {
        isOpen: true,
        currentStatus: 'Open 24 hours',
        hours: ['Open 24 hours']
      },
      lat: 40.7061,
      lng: -73.9969,
      amenities: ['Walking Path', 'Bike Lane', 'Photography Spots', 'City Views'],
      description: 'Iconic suspension bridge offering stunning views of Manhattan skyline',
      lastUpdated: '2024-01-20T11:30:00Z'
    },
    {
      id: '7',
      name: 'Metro Pharmacy',
      category: 'Services',
      subcategory: 'Pharmacy',
      address: '567 2nd Ave, New York, NY 10016',
      distance: 0.6,
      rating: 4.2,
      reviewCount: 78,
      priceLevel: 2,
      openingHours: {
        isOpen: true,
        currentStatus: 'Open until 8:00 PM',
        hours: ['8:00 AM - 8:00 PM', '8:00 AM - 8:00 PM', '8:00 AM - 8:00 PM', '8:00 AM - 8:00 PM', '8:00 AM - 8:00 PM', '9:00 AM - 6:00 PM', '10:00 AM - 4:00 PM']
      },
      contact: {
        phone: '+1 (555) 345-6789'
      },
      lat: 40.7320,
      lng: -73.9850,
      amenities: ['Prescription Pickup', 'Health Consultations', 'Flu Shots', 'OTC Medications'],
      description: 'Full-service pharmacy with prescription services and health consultations',
      lastUpdated: '2024-01-20T09:15:00Z'
    },
    {
      id: '8',
      name: 'Urban Bookstore',
      category: 'Shopping',
      subcategory: 'Bookstore',
      address: '890 3rd St, New York, NY 10003',
      distance: 1.1,
      rating: 4.6,
      reviewCount: 234,
      priceLevel: 2,
      openingHours: {
        isOpen: true,
        currentStatus: 'Open until 10:00 PM',
        hours: ['9:00 AM - 10:00 PM', '9:00 AM - 10:00 PM', '9:00 AM - 10:00 PM', '9:00 AM - 10:00 PM', '9:00 AM - 11:00 PM', '9:00 AM - 11:00 PM', '10:00 AM - 9:00 PM']
      },
      contact: {
        phone: '+1 (555) 567-8901',
        website: 'https://urbanbookstore.com'
      },
      lat: 40.7310,
      lng: -73.9890,
      amenities: ['Reading Nook', 'Coffee Corner', 'Book Events', 'Local Authors'],
      description: 'Independent bookstore featuring local authors and cozy reading spaces',
      lastUpdated: '2024-01-19T16:00:00Z'
    },
    {
      id: '9',
      name: 'Gasoline Station Plus',
      category: 'Transportation',
      subcategory: 'Gas Station',
      address: '234 Highway 1, New York, NY 10001',
      distance: 2.3,
      rating: 3.9,
      reviewCount: 145,
      priceLevel: 2,
      openingHours: {
        isOpen: true,
        currentStatus: 'Open 24 hours',
        hours: ['Open 24 hours']
      },
      contact: {
        phone: '+1 (555) 678-9012'
      },
      lat: 40.7150,
      lng: -74.0100,
      amenities: ['24/7 Service', 'Convenience Store', 'Car Wash', 'ATM'],
      description: '24-hour gas station with convenience store and car wash services',
      lastUpdated: '2024-01-18T22:00:00Z'
    },
    {
      id: '10',
      name: 'Pizza Corner',
      category: 'Food & Drink',
      subcategory: 'Pizza Restaurant',
      address: '678 Main St, New York, NY 10002',
      distance: 0.9,
      rating: 4.3,
      reviewCount: 512,
      priceLevel: 1,
      openingHours: {
        isOpen: true,
        currentStatus: 'Open until 1:00 AM',
        hours: ['11:00 AM - 1:00 AM', '11:00 AM - 1:00 AM', '11:00 AM - 1:00 AM', '11:00 AM - 2:00 AM', '11:00 AM - 2:00 AM', '11:00 AM - 2:00 AM', '12:00 PM - 12:00 AM']
      },
      contact: {
        phone: '+1 (555) 789-0123',
        website: 'https://pizzacornernyc.com'
      },
      lat: 40.7200,
      lng: -73.9850,
      amenities: ['Delivery', 'Takeout', 'Late Night', 'By The Slice'],
      description: 'Classic New York pizza joint serving authentic thin crust slices',
      lastUpdated: '2024-01-20T13:45:00Z'
    }
  ];

  useEffect(() => {
    // Get user location
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          setUserLocation({
            lat: position.coords.latitude,
            lng: position.coords.longitude
          });
        },
        (error) => {
          console.log('Location access denied');
          // Default to NYC
          setUserLocation({ lat: 40.7128, lng: -74.0060 });
        }
      );
    } else {
      setUserLocation({ lat: 40.7128, lng: -74.0060 });
    }

    // Simulate API call
    setTimeout(() => {
      setNearbyPlaces(mockNearbyPlaces);
      setFilteredPlaces(mockNearbyPlaces);
      setLoading(false);
    }, 1000);
  }, []);

  useEffect(() => {
    let filtered = nearbyPlaces;

    // Search filter
    if (searchQuery) {
      filtered = filtered.filter(place => 
        place.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        place.category.toLowerCase().includes(searchQuery.toLowerCase()) ||
        place.subcategory.toLowerCase().includes(searchQuery.toLowerCase()) ||
        place.address.toLowerCase().includes(searchQuery.toLowerCase())
      );
    }

    // Category filter
    if (categoryFilter !== 'all') {
      filtered = filtered.filter(place => place.category === categoryFilter);
    }

    // Radius filter
    const maxDistance = parseFloat(radiusFilter);
    filtered = filtered.filter(place => place.distance <= maxDistance);

    // Sort
    switch (sortBy) {
      case 'distance':
        filtered.sort((a, b) => a.distance - b.distance);
        break;
      case 'rating':
        filtered.sort((a, b) => (b.rating || 0) - (a.rating || 0));
        break;
      case 'name':
        filtered.sort((a, b) => a.name.localeCompare(b.name));
        break;
    }

    setFilteredPlaces(filtered);
  }, [nearbyPlaces, searchQuery, categoryFilter, radiusFilter, sortBy]);

  const categories = ['all', 'Food & Drink', 'Attractions', 'Services', 'Health & Fitness', 'Shopping', 'Transportation'];

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case 'Food & Drink': return <Utensils className="w-5 h-5" />;
      case 'Attractions': return <Camera className="w-5 h-5" />;
      case 'Services': return <Car className="w-5 h-5" />;
      case 'Health & Fitness': return <Hospital className="w-5 h-5" />;
      case 'Shopping': return <ShoppingBag className="w-5 h-5" />;
      case 'Transportation': return <Navigation className="w-5 h-5" />;
      default: return <MapPin className="w-5 h-5" />;
    }
  };

  const getPriceLevel = (level?: number) => {
    if (!level) return '';
    return '$'.repeat(level);
  };

  const getDistanceText = (distance: number) => {
    if (distance < 1) {
      return `${Math.round(distance * 1000)}m`;
    }
    return `${distance.toFixed(1)}km`;
  };

  return (
    <div className="h-full bg-gradient-to-br from-blue-50 via-indigo-50 to-emerald-50 dark:from-gray-900 dark:via-gray-800 dark:to-gray-900 p-6 overflow-y-auto">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Header */}
        <div className="glassmorphism rounded-2xl shadow-xl p-6 border border-white/20 dark:border-gray-700/20">
          <div className="flex items-center justify-between mb-6">
            <div>
              <h1 className="text-3xl font-bold bg-gradient-to-r from-blue-600 to-emerald-500 bg-clip-text text-transparent">
                Nearby Places
              </h1>
              <p className="text-slate-600 dark:text-gray-300 mt-2">Discover what's around you right now</p>
            </div>
            <div className="flex items-center space-x-2">
              <Badge className="bg-gradient-to-r from-blue-500 to-emerald-500 text-white text-lg px-4 py-2 flex items-center space-x-2">
                <Navigation className="w-4 h-4" />
                <span>{filteredPlaces.length} Places Found</span>
              </Badge>
            </div>
          </div>

          {/* Search and Filters */}
          <div className="flex flex-col md:flex-row gap-4 items-center">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400 w-5 h-5" />
              <Input
                placeholder="Search nearby places..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10 bg-white/70 border-white/30 focus:bg-white"
              />
            </div>
            
            <Select value={categoryFilter} onValueChange={setCategoryFilter}>
              <SelectTrigger className="w-full md:w-48 bg-white/70 border-white/30">
                <SelectValue placeholder="Category" />
              </SelectTrigger>
              <SelectContent>
                {categories.map(category => (
                  <SelectItem key={category} value={category}>
                    {category === 'all' ? 'All Categories' : category}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>

            <Select value={radiusFilter} onValueChange={setRadiusFilter}>
              <SelectTrigger className="w-full md:w-32 bg-white/70 border-white/30">
                <SelectValue placeholder="Radius" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="1">1 km</SelectItem>
                <SelectItem value="2">2 km</SelectItem>
                <SelectItem value="5">5 km</SelectItem>
                <SelectItem value="10">10 km</SelectItem>
                <SelectItem value="25">25 km</SelectItem>
              </SelectContent>
            </Select>

            <Select value={sortBy} onValueChange={setSortBy}>
              <SelectTrigger className="w-full md:w-40 bg-white/70 border-white/30">
                <SelectValue placeholder="Sort by" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="distance">Distance</SelectItem>
                <SelectItem value="rating">Rating</SelectItem>
                <SelectItem value="name">Name</SelectItem>
              </SelectContent>
            </Select>

            <div className="flex bg-white/70 rounded-lg border border-white/30">
              <Button
                variant={viewMode === 'grid' ? 'default' : 'ghost'}
                size="sm"
                onClick={() => setViewMode('grid')}
                className="rounded-r-none"
              >
                <Grid className="w-4 h-4" />
              </Button>
              <Button
                variant={viewMode === 'list' ? 'default' : 'ghost'}
                size="sm"
                onClick={() => setViewMode('list')}
                className="rounded-l-none"
              >
                <List className="w-4 h-4" />
              </Button>
            </div>
          </div>
        </div>

        {/* Places List */}
        <div className="glassmorphism rounded-2xl shadow-xl border border-white/20 dark:border-gray-700/20 p-6">
          {loading ? (
            <div className="space-y-4">
              {[1, 2, 3, 4, 5].map((i) => (
                <div key={i} className="animate-pulse">
                  <div className="h-24 bg-slate-200 rounded-xl"></div>
                </div>
              ))}
            </div>
          ) : (
            <>
              {filteredPlaces.length > 0 ? (
                <div className={`grid ${viewMode === 'grid' ? 'grid-cols-1 md:grid-cols-2 lg:grid-cols-3' : 'grid-cols-1'} gap-6`}>
                  {filteredPlaces.map((place) => (
                    <Card key={place.id} className="hover-lift transition-all duration-200 hover:shadow-xl bg-white/60 backdrop-blur-sm border border-white/30">
                      <CardContent className="p-6">
                        <div className="flex items-start justify-between mb-4">
                          <div className="flex items-start space-x-3">
                            <div className="p-2 bg-blue-100 rounded-lg">
                              {getCategoryIcon(place.category)}
                            </div>
                            <div className="flex-1">
                              <h3 className="font-bold text-lg text-slate-800 line-clamp-1">
                                {place.name}
                              </h3>
                              <p className="text-sm text-slate-600">{place.subcategory}</p>
                            </div>
                          </div>
                          <div className="text-right">
                            <div className="text-sm font-semibold text-blue-600">
                              {getDistanceText(place.distance)}
                            </div>
                            {place.priceLevel && (
                              <div className="text-emerald-600 font-medium">
                                {getPriceLevel(place.priceLevel)}
                              </div>
                            )}
                          </div>
                        </div>

                        <div className="space-y-3">
                          {place.rating && (
                            <div className="flex items-center space-x-2">
                              <div className="flex items-center space-x-1">
                                <Star className="w-4 h-4 text-yellow-500 fill-current" />
                                <span className="font-medium text-slate-700">{place.rating}</span>
                              </div>
                              <span className="text-sm text-slate-500">({place.reviewCount} reviews)</span>
                            </div>
                          )}

                          <div className="text-sm text-slate-600 line-clamp-2">
                            {place.address}
                          </div>

                          {place.description && (
                            <p className="text-sm text-slate-600 line-clamp-2">
                              {place.description}
                            </p>
                          )}

                          {place.openingHours && (
                            <div className="flex items-center space-x-2">
                              <Clock className="w-4 h-4 text-slate-500" />
                              <span className={`text-sm font-medium ${
                                place.openingHours.isOpen ? 'text-emerald-600' : 'text-red-600'
                              }`}>
                                {place.openingHours.currentStatus}
                              </span>
                            </div>
                          )}

                          {place.amenities && place.amenities.length > 0 && (
                            <div className="flex flex-wrap gap-1">
                              {place.amenities.slice(0, 3).map(amenity => (
                                <Badge key={amenity} variant="secondary" className="text-xs bg-slate-100 text-slate-600">
                                  {amenity}
                                </Badge>
                              ))}
                              {place.amenities.length > 3 && (
                                <Badge variant="secondary" className="text-xs bg-slate-100 text-slate-600">
                                  +{place.amenities.length - 3}
                                </Badge>
                              )}
                            </div>
                          )}

                          <div className="flex items-center justify-between pt-3 border-t border-slate-200">
                            <div className="flex space-x-2">
                              {place.contact?.phone && (
                                <Button variant="outline" size="sm" className="text-xs">
                                  <Phone className="w-3 h-3 mr-1" />
                                  Call
                                </Button>
                              )}
                              {place.contact?.website && (
                                <Button variant="outline" size="sm" className="text-xs">
                                  <Globe className="w-3 h-3 mr-1" />
                                  Website
                                </Button>
                              )}
                            </div>
                            <Button size="sm" className="bg-gradient-to-r from-blue-600 to-emerald-500 hover:from-blue-700 hover:to-emerald-600 text-xs">
                              <Navigation className="w-3 h-3 mr-1" />
                              Directions
                            </Button>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              ) : (
                <div className="text-center py-12">
                  <div className="w-16 h-16 bg-slate-200 rounded-full flex items-center justify-center mx-auto mb-4">
                    <Navigation className="w-8 h-8 text-slate-400" />
                  </div>
                  <h3 className="font-semibold text-slate-600 mb-2">No places found</h3>
                  <p className="text-slate-500 mb-4">
                    {searchQuery || categoryFilter !== 'all' 
                      ? 'Try adjusting your search or filters'
                      : 'Unable to find nearby places at the moment'
                    }
                  </p>
                  <Button className="bg-gradient-to-r from-blue-600 to-emerald-500 hover:from-blue-700 hover:to-emerald-600">
                    Refresh Location
                  </Button>
                </div>
              )}
            </>
          )}
        </div>
      </div>
    </div>
  );
}