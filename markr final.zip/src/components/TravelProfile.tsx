import { MapPin, Compass, Layers, Award, Calendar, Camera, Users, Star } from 'lucide-react';
import { Card } from './ui/card';
import { Badge } from './ui/badge';
import { Progress } from './ui/progress';
import type { User } from '@supabase/supabase-js';

interface UserProfile {
  id: string;
  name: string;
  email: string;
  level: number;
  xp: number;
  totalDistance: number;
  placesExplored: number;
  mapsContributed: number;
  achievements: string[];
  createdAt: string;
}

interface ProfileProps {
  user: User | null;
  profile: UserProfile | null;
}

export function Profile({ user, profile }: ProfileProps) {
  if (!user || !profile) {
    return (
      <div className="p-6 max-w-6xl mx-auto">
        <Card className="p-8 text-center">
          <h2 className="text-2xl font-bold text-slate-800 mb-4">Please Sign In</h2>
          <p className="text-slate-600">Sign in to view your profile and track your exploration progress.</p>
        </Card>
      </div>
    );
  }
  const userStats = [
    { title: 'Total Distance', value: `${profile.totalDistance.toLocaleString()} km`, icon: MapPin, color: 'text-blue-600' },
    { title: 'Places Explored', value: profile.placesExplored.toString(), icon: Compass, color: 'text-emerald-600' },
    { title: 'Maps Contributed', value: profile.mapsContributed.toString(), icon: Layers, color: 'text-purple-600' },
  ];

  const achievements = [
    { name: 'Explorer', description: 'Visited 100+ places', icon: '🗺️', unlocked: profile.placesExplored >= 100 },
    { name: 'Contributor', description: 'Created 10+ maps', icon: '✏️', unlocked: profile.mapsContributed >= 10 },
    { name: 'Traveler', description: 'Traveled 1000+ km', icon: '✈️', unlocked: profile.totalDistance >= 1000 },
    { name: 'Photographer', description: 'Uploaded 50+ photos', icon: '📸', unlocked: false },
    { name: 'Social Explorer', description: 'Connected with 25+ users', icon: '👥', unlocked: false },
    { name: 'Master Explorer', description: 'Reached level 25', icon: '🏆', unlocked: profile.level >= 25 },
  ];

  const recentActivities = [
    { action: 'Checked in', location: 'Goa Beach Resort', time: '2 hours ago', icon: MapPin },
    { action: 'Added Snack Shop Marker', location: 'Mumbai Street Food', time: '5 hours ago', icon: Layers },
    { action: 'Unlocked Explorer Badge', location: 'Achievement', time: '1 day ago', icon: Award },
    { action: 'Uploaded Photo', location: 'Sunset Point, Kerala', time: '2 days ago', icon: Camera },
    { action: 'Created New Map', location: 'Weekend Getaway Route', time: '3 days ago', icon: Layers },
  ];

  return (
    <div className="p-8 max-w-7xl mx-auto space-y-8 animate-fade-in">
      {/* Profile Header */}
      <Card className="p-10 bg-gradient-to-r from-blue-50/80 to-emerald-50/80 backdrop-blur-xl border-0 shadow-2xl border border-white/20">
        <div className="flex items-center space-x-8">
          <div className="w-32 h-32 bg-gradient-to-br from-blue-600 to-emerald-500 rounded-2xl flex items-center justify-center shadow-2xl hover-lift float">
            <span className="text-4xl font-bold text-white">{profile.name.charAt(0).toUpperCase()}</span>
          </div>
          <div className="flex-1">
            <h1 className="text-4xl font-black text-slate-800 mb-3 bg-gradient-to-r from-blue-600 to-emerald-500 bg-clip-text text-transparent">
              {profile.name}
            </h1>
            <div className="flex items-center space-x-6 mb-6">
              <Badge variant="secondary" className="bg-gradient-to-r from-blue-600 to-emerald-500 text-white px-4 py-2 text-lg font-bold rounded-xl shadow-lg">
                Level {profile.level} Explorer
              </Badge>
              <span className="text-slate-600 font-medium bg-white/60 px-3 py-1 rounded-lg backdrop-blur-sm">
                Member since {new Date(profile.createdAt).toLocaleDateString('en-US', { month: 'short', year: 'numeric' })}
              </span>
            </div>
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="font-bold text-slate-700">XP Progress</span>
                <span className="font-semibold text-slate-600 bg-white/60 px-3 py-1 rounded-lg">
                  {profile.xp.toLocaleString()} / {((Math.floor(profile.level / 10) + 1) * 1000).toLocaleString()} XP
                </span>
              </div>
              <Progress value={Math.min(100, (profile.xp % 1000) / 10)} className="h-4 bg-white/60" />
              <p className="font-medium text-slate-600 text-center bg-white/50 py-2 px-4 rounded-lg">
                {1000 - (profile.xp % 1000)} XP to reach Level {profile.level + 1}
              </p>
            </div>
          </div>
        </div>
      </Card>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        {userStats.map((stat, index) => (
          <Card key={index} className="p-8 hover:shadow-2xl transition-all duration-300 hover:scale-105 border-0 shadow-xl bg-white/80 backdrop-blur-xl hover-lift">
            <div className="flex items-center space-x-6">
              <div className={`p-4 rounded-2xl bg-gradient-to-br from-white to-slate-50 shadow-lg ${stat.color}`}>
                <stat.icon className="w-8 h-8" />
              </div>
              <div>
                <p className="text-3xl font-black text-slate-800">{stat.value}</p>
                <p className="font-semibold text-slate-600">{stat.title}</p>
              </div>
            </div>
          </Card>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Achievements */}
        <Card className="p-6 border-0 shadow-xl">
          <div className="flex items-center space-x-2 mb-6">
            <Award className="w-5 h-5 text-yellow-600" />
            <h2 className="text-xl font-bold text-slate-800">Achievements</h2>
          </div>
          <div className="grid grid-cols-2 gap-4">
            {achievements.map((achievement, index) => (
              <div
                key={index}
                className={`p-4 rounded-xl border-2 transition-all duration-200 hover:scale-105 ${
                  achievement.unlocked
                    ? 'border-emerald-200 bg-emerald-50 hover:border-emerald-300'
                    : 'border-slate-200 bg-slate-50 opacity-60'
                }`}
              >
                <div className="text-center space-y-2">
                  <div className="text-2xl">{achievement.icon}</div>
                  <h3 className={`font-medium ${achievement.unlocked ? 'text-slate-800' : 'text-slate-500'}`}>
                    {achievement.name}
                  </h3>
                  <p className={`text-xs ${achievement.unlocked ? 'text-slate-600' : 'text-slate-400'}`}>
                    {achievement.description}
                  </p>
                  {achievement.unlocked && (
                    <div className="flex items-center justify-center space-x-1 pt-1">
                      <Star className="w-3 h-3 text-yellow-500 fill-current" />
                      <span className="text-xs text-yellow-600 font-medium">Unlocked</span>
                    </div>
                  )}
                </div>
              </div>
            ))}
          </div>
        </Card>

        {/* Activity Timeline */}
        <Card className="p-6 border-0 shadow-xl">
          <div className="flex items-center space-x-2 mb-6">
            <Calendar className="w-5 h-5 text-blue-600" />
            <h2 className="text-xl font-bold text-slate-800">Recent Activity</h2>
          </div>
          <div className="space-y-4">
            {recentActivities.map((activity, index) => (
              <div key={index} className="flex items-start space-x-4 p-3 rounded-lg hover:bg-slate-50 transition-colors">
                <div className="p-2 rounded-lg bg-blue-100 text-blue-600 flex-shrink-0">
                  <activity.icon className="w-4 h-4" />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium text-slate-800">
                    {activity.action}
                  </p>
                  <p className="text-sm text-slate-600 truncate">{activity.location}</p>
                  <p className="text-xs text-slate-400 mt-1">{activity.time}</p>
                </div>
              </div>
            ))}
          </div>
        </Card>
      </div>
    </div>
  );
}