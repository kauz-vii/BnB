import { useState } from 'react';
import { MapPin, Utensils, Car, Camera, StickyNote, Upload, X } from 'lucide-react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from './ui/dialog';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Textarea } from './ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Label } from './ui/label';

interface AddMarkerModalProps {
  isOpen: boolean;
  onOpenChange: (open: boolean) => void;
}

export function AddMarkerModal({ isOpen, onOpenChange }: AddMarkerModalProps) {
  const [formData, setFormData] = useState({
    category: '',
    title: '',
    notes: '',
    photo: null as File | null
  });

  const categories = [
    { value: 'food', label: 'Food & Drinks', icon: Utensils, color: 'text-orange-600', bgColor: 'bg-orange-100' },
    { value: 'facilities', label: 'Facilities', icon: Car, color: 'text-blue-600', bgColor: 'bg-blue-100' },
    { value: 'attraction', label: 'Photo Spots', icon: Camera, color: 'text-purple-600', bgColor: 'bg-purple-100' },
    { value: 'other', label: 'Notes & Tips', icon: StickyNote, color: 'text-emerald-600', bgColor: 'bg-emerald-100' },
  ];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Handle marker creation logic here
    console.log('Creating marker:', formData);
    onOpenChange(false);
    // Reset form
    setFormData({ category: '', title: '', notes: '', photo: null });
  };

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0] || null;
    setFormData(prev => ({ ...prev, photo: file }));
  };

  const selectedCategory = categories.find(cat => cat.value === formData.category);

  return (
    <Dialog open={isOpen} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center space-x-2">
            <MapPin className="w-5 h-5 text-blue-600" />
            <span>Add New Marker</span>
          </DialogTitle>
          <DialogDescription className="text-slate-600">
            Add a new marker to this map. Choose a category and provide details to help other travelers discover this location.
          </DialogDescription>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="space-y-2">
            <Label htmlFor="category">Category</Label>
            <Select 
              value={formData.category} 
              onValueChange={(value) => handleInputChange('category', value)}
              required
            >
              <SelectTrigger className="focus:border-blue-500 focus:ring-1 focus:ring-blue-500">
                <SelectValue placeholder="Choose a category..." />
              </SelectTrigger>
              <SelectContent>
                {categories.map((category) => (
                  <SelectItem key={category.value} value={category.value}>
                    <div className="flex items-center space-x-2">
                      <div className={`p-1 rounded ${category.bgColor}`}>
                        <category.icon className={`w-4 h-4 ${category.color}`} />
                      </div>
                      <span>{category.label}</span>
                    </div>
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label htmlFor="title">Title</Label>
            <Input
              id="title"
              placeholder="Give your marker a descriptive title..."
              value={formData.title}
              onChange={(e) => handleInputChange('title', e.target.value)}
              required
              className="focus:border-blue-500 focus:ring-1 focus:ring-blue-500"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="notes">Notes</Label>
            <Textarea
              id="notes"
              placeholder="Add helpful details, tips, or descriptions..."
              value={formData.notes}
              onChange={(e) => handleInputChange('notes', e.target.value)}
              rows={3}
              className="focus:border-blue-500 focus:ring-1 focus:ring-blue-500 resize-none"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="photo">Upload Photo (Optional)</Label>
            <div className="border-2 border-dashed border-slate-200 rounded-lg p-4 hover:border-blue-300 transition-colors">
              <input
                id="photo"
                type="file"
                accept="image/*"
                onChange={handleFileChange}
                className="hidden"
              />
              <label 
                htmlFor="photo" 
                className="flex flex-col items-center justify-center space-y-2 cursor-pointer"
              >
                <Upload className="w-8 h-8 text-slate-400" />
                <span className="text-sm text-slate-600">
                  {formData.photo ? formData.photo.name : 'Click to upload a photo'}
                </span>
                <span className="text-xs text-slate-400">PNG, JPG up to 10MB</span>
              </label>
            </div>
          </div>

          {selectedCategory && (
            <div className={`${selectedCategory.bgColor} p-4 rounded-lg border border-opacity-30`}>
              <div className="flex items-start space-x-3">
                <div className={`p-1 rounded ${selectedCategory.bgColor}`}>
                  <selectedCategory.icon className={`w-5 h-5 ${selectedCategory.color}`} />
                </div>
                <div>
                  <h4 className={`font-medium ${selectedCategory.color} mb-1`}>
                    {selectedCategory.label} Marker
                  </h4>
                  <p className={`text-sm ${selectedCategory.color} opacity-80`}>
                    This marker will help other travelers find great {selectedCategory.label.toLowerCase()} in the area.
                  </p>
                </div>
              </div>
            </div>
          )}

          <div className="flex space-x-3 pt-4">
            <Button
              type="button"
              variant="outline"
              onClick={() => onOpenChange(false)}
              className="flex-1"
            >
              Cancel
            </Button>
            <Button
              type="submit"
              className="flex-1 bg-gradient-to-r from-blue-600 to-emerald-500 hover:from-blue-700 hover:to-emerald-600"
              disabled={!formData.category || !formData.title.trim()}
            >
              Add Marker
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}