import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { ArrowUp, ArrowDown, MessageSquare, Eye, Clock, User, Tag, Star, CheckCircle } from 'lucide-react';
import { useQuestions, useAnswers, useVotes, useAuth } from '../contexts/DataProvider';
import { FeedFilters } from '../types';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Card } from './ui/card';

interface FeedProps {
  onNavigateToQuestion: (questionId: string) => void;
}

export default function Feed({ onNavigateToQuestion }: FeedProps) {
  const { user } = useAuth();
  const { getFilteredQuestions, incrementViews, isLoading } = useQuestions();
  const { getAnswersByQuestion } = useAnswers();
  const { castVote, getVoteScore, getUserVote } = useVotes();
  
  const [filters, setFilters] = useState<FeedFilters>({
    sort: 'hot',
    tags: [],
    timeRange: 'all'
  });

  const questions = getFilteredQuestions(filters);

  const handleVote = async (questionId: string, voteType: 'UP' | 'DOWN') => {
    if (!user) return;
    
    try {
      await castVote(user.id, voteType, questionId);
    } catch (error) {
      console.error('Vote failed:', error);
    }
  };

  const handleQuestionClick = (questionId: string) => {
    incrementViews(questionId);
    onNavigateToQuestion(questionId);
  };

  const formatTimeAgo = (date: Date) => {
    const now = new Date();
    const diff = now.getTime() - date.getTime();
    const hours = Math.floor(diff / (1000 * 60 * 60));
    
    if (hours < 1) return 'just now';
    if (hours === 1) return '1 hour ago';
    if (hours < 24) return `${hours} hours ago`;
    
    const days = Math.floor(hours / 24);
    if (days === 1) return '1 day ago';
    return `${days} days ago`;
  };

  const getUserLevel = (reputation: number) => {
    if (reputation >= 1600) return { name: 'Moderator', color: 'bg-gradient-to-r from-iron-red to-iron-gold' };
    if (reputation >= 900) return { name: 'Guru', color: 'bg-gradient-to-r from-iron-gold to-iron-bright-gold' };
    if (reputation >= 400) return { name: 'Expert', color: 'bg-iron-bright-gold' };
    if (reputation >= 150) return { name: 'Helpful', color: 'bg-iron-gold' };
    if (reputation >= 50) return { name: 'Contributor', color: 'bg-iron-red' };
    return { name: 'Newbie', color: 'bg-iron-gray' };
  };

  if (isLoading) {
    return (
      <div className="p-6">
        <div className="max-w-4xl mx-auto space-y-4">
          {[...Array(5)].map((_, i) => (
            <Card key={i} className="p-6 bg-iron-card border-iron-dark-gray">
              <div className="animate-pulse">
                <div className="h-4 bg-iron-dark-gray rounded w-3/4 mb-3"></div>
                <div className="h-3 bg-iron-dark-gray rounded w-full mb-2"></div>
                <div className="h-3 bg-iron-dark-gray rounded w-2/3 mb-4"></div>
                <div className="flex space-x-2">
                  <div className="h-6 bg-iron-dark-gray rounded w-16"></div>
                  <div className="h-6 bg-iron-dark-gray rounded w-20"></div>
                  <div className="h-6 bg-iron-dark-gray rounded w-14"></div>
                </div>
              </div>
            </Card>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="p-6">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <div>
            <h1 className="text-3xl font-poppins font-black text-iron-white mb-2 heading-shadow">
              Questions
            </h1>
            <p className="text-iron-gray">
              {questions.length} questions • Sorted by {filters.sort}
            </p>
          </div>

          {/* Sort Options */}
          <div className="flex space-x-2">
            {['hot', 'new', 'unanswered', 'trending'].map((sort) => (
              <Button
                key={sort}
                variant={filters.sort === sort ? 'default' : 'outline'}
                size="sm"
                className={filters.sort === sort 
                  ? 'bg-iron-gold text-iron-black hover:bg-iron-bright-gold' 
                  : 'border-iron-dark-gray text-iron-white hover:bg-iron-black/30'
                }
                onClick={() => setFilters(prev => ({ ...prev, sort: sort as any }))}
              >
                {sort.charAt(0).toUpperCase() + sort.slice(1)}
              </Button>
            ))}
          </div>
        </div>

        {/* Questions List */}
        <div className="space-y-4">
          {questions.map((question, index) => {
            const userLevel = getUserLevel(question.author.reputation);
            const answers = getAnswersByQuestion(question.id);
            const score = getVoteScore(question.id);
            const userVote = user ? getUserVote(user.id, question.id) : null;
            
            return (
              <motion.div
                key={question.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
              >
                <Card className="p-6 bg-iron-card border-iron-dark-gray hover:border-iron-gold/50 transition-all duration-300 cursor-pointer"
                      onClick={() => handleQuestionClick(question.id)}>
                  <div className="flex space-x-4">
                    {/* Vote Section */}
                    <div className="flex flex-col items-center space-y-2 min-w-0">
                      <Button
                        variant="ghost"
                        size="sm"
                        className={`p-1 transition-colors ${
                          userVote?.type === 'UP' 
                            ? 'text-iron-gold' 
                            : 'text-iron-gray hover:text-iron-gold'
                        }`}
                        onClick={(e) => {
                          e.stopPropagation();
                          handleVote(question.id, 'UP');
                        }}
                        disabled={!user || question.authorId === user.id}
                      >
                        <ArrowUp className="w-5 h-5" />
                      </Button>
                      <span className="text-lg font-bold text-iron-white">
                        {score}
                      </span>
                      <Button
                        variant="ghost"
                        size="sm"
                        className={`p-1 transition-colors ${
                          userVote?.type === 'DOWN' 
                            ? 'text-iron-red' 
                            : 'text-iron-gray hover:text-iron-red'
                        }`}
                        onClick={(e) => {
                          e.stopPropagation();
                          handleVote(question.id, 'DOWN');
                        }}
                        disabled={!user || question.authorId === user.id}
                      >
                        <ArrowDown className="w-5 h-5" />
                      </Button>
                    </div>

                    {/* Question Content */}
                    <div className="flex-1">
                      {/* Title */}
                      <h2 className="text-xl font-poppins font-bold text-iron-white mb-2 hover:text-iron-gold transition-colors">
                        {question.title}
                        {question.acceptedAnswerId && (
                          <CheckCircle className="inline w-5 h-5 text-iron-gold ml-2" />
                        )}
                      </h2>

                      {/* Body Preview */}
                      <p className="text-iron-light-gray mb-4 line-clamp-2">
                        {question.body}
                      </p>

                      {/* Tags */}
                      <div className="flex flex-wrap gap-2 mb-4">
                        {question.tags.map((tag) => (
                          <Badge
                            key={tag}
                            variant="secondary"
                            className="bg-iron-black/50 text-iron-gold border-iron-dark-gray hover:bg-iron-gold hover:text-iron-black cursor-pointer transition-colors"
                          >
                            {tag}
                          </Badge>
                        ))}
                      </div>

                      {/* Meta Information */}
                      <div className="flex items-center justify-between text-sm text-iron-gray">
                        <div className="flex items-center space-x-4">
                          <div className="flex items-center space-x-1">
                            <MessageSquare className="w-4 h-4" />
                            <span>{answers.length} answers</span>
                          </div>
                          <div className="flex items-center space-x-1">
                            <Eye className="w-4 h-4" />
                            <span>{question.views} views</span>
                          </div>
                        </div>

                        <div className="flex items-center space-x-3">
                          <div className="flex items-center space-x-2">
                            <Clock className="w-4 h-4" />
                            <span>{formatTimeAgo(question.createdAt)}</span>
                          </div>
                          <div className="flex items-center space-x-2">
                            <div className="w-6 h-6 bg-iron-gold rounded-full flex items-center justify-center">
                              <User className="w-3 h-3 text-iron-black" />
                            </div>
                            <div>
                              <div className="font-semibold text-iron-white">
                                {question.author.username}
                              </div>
                              <div className="flex items-center space-x-1">
                                <div className={`w-2 h-2 rounded-full ${userLevel.color}`}></div>
                                <span>{question.author.reputation}</span>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </Card>
              </motion.div>
            );
          })}
        </div>

        {/* Load More */}
        {questions.length === 0 && (
          <div className="text-center py-12">
            <div className="text-iron-gray mb-4">
              <MessageSquare className="w-16 h-16 mx-auto mb-4 opacity-50" />
              <h3 className="text-xl font-semibold mb-2">No questions found</h3>
              <p>Try adjusting your filters or be the first to ask a question!</p>
            </div>
          </div>
        )}

        {questions.length > 0 && (
          <div className="mt-8 text-center">
            <Button
              variant="outline"
              className="border-iron-dark-gray text-iron-white hover:bg-iron-black/30"
            >
              Load More Questions
            </Button>
          </div>
        )}
      </div>
    </div>
  );
}