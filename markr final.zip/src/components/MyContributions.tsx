import { useState, useEffect } from 'react';
import { MapPin, Calendar, Star, Eye, Heart, MoreHorizontal, Edit, Trash2, Share } from 'lucide-react';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from './ui/dropdown-menu';
import type { User } from '@supabase/supabase-js';

interface Contribution {
  id: string;
  type: 'marker' | 'map';
  title: string;
  description?: string;
  category: string;
  location?: string;
  rating?: number;
  views: number;
  likes: number;
  createdAt: string;
  status: 'published' | 'draft' | 'pending';
  image?: string;
}

interface MyContributionsProps {
  user: User | null;
}

export function MyContributions({ user }: MyContributionsProps) {
  const [contributions, setContributions] = useState<Contribution[]>([]);
  const [activeTab, setActiveTab] = useState('all');
  const [loading, setLoading] = useState(true);

  // Mock data - will be replaced with Supabase queries
  const mockContributions: Contribution[] = [
    {
      id: '1',
      type: 'marker',
      title: 'Amazing Pizza Place',
      description: 'Best pizza in the city with authentic Italian flavors',
      category: 'Food & Dining',
      location: 'Downtown Manhattan',
      rating: 4.8,
      views: 234,
      likes: 45,
      createdAt: '2024-01-15T10:00:00Z',
      status: 'published'
    },
    {
      id: '2',
      type: 'map',
      title: 'Hidden Gems of Brooklyn',
      description: 'A curated collection of lesser-known spots in Brooklyn',
      category: 'Exploration',
      views: 1250,
      likes: 189,
      createdAt: '2024-01-10T14:30:00Z',
      status: 'published'
    },
    {
      id: '3',
      type: 'marker',
      title: 'Perfect Sunset Viewpoint',
      description: 'Incredible views during golden hour',
      category: 'Photography',
      location: 'Central Park',
      rating: 4.9,
      views: 89,
      likes: 23,
      createdAt: '2024-01-08T18:45:00Z',
      status: 'published'
    },
    {
      id: '4',
      type: 'map',
      title: 'Coffee Shop Tour',
      description: 'Best coffee spots for remote work',
      category: 'Food & Dining',
      views: 567,
      likes: 78,
      createdAt: '2024-01-05T09:15:00Z',
      status: 'draft'
    }
  ];

  useEffect(() => {
    // Simulate API call
    setTimeout(() => {
      setContributions(mockContributions);
      setLoading(false);
    }, 1000);
  }, []);

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'published':
        return <Badge className="bg-green-100 text-green-700 border-green-200">Published</Badge>;
      case 'draft':
        return <Badge className="bg-yellow-100 text-yellow-700 border-yellow-200">Draft</Badge>;
      case 'pending':
        return <Badge className="bg-blue-100 text-blue-700 border-blue-200">Pending</Badge>;
      default:
        return <Badge variant="secondary">Unknown</Badge>;
    }
  };

  const getTypeIcon = (type: string) => {
    return type === 'map' ? '🗺️' : '📍';
  };

  const filteredContributions = activeTab === 'all' 
    ? contributions 
    : contributions.filter(c => c.type === activeTab);

  const stats = {
    total: contributions.length,
    markers: contributions.filter(c => c.type === 'marker').length,
    maps: contributions.filter(c => c.type === 'map').length,
    totalViews: contributions.reduce((sum, c) => sum + c.views, 0),
    totalLikes: contributions.reduce((sum, c) => sum + c.likes, 0)
  };

  if (!user) {
    return (
      <div className="h-full flex items-center justify-center bg-gradient-to-br from-blue-50 via-indigo-50 to-emerald-50">
        <div className="text-center space-y-4">
          <div className="w-24 h-24 bg-gradient-to-r from-blue-500 to-emerald-500 rounded-full flex items-center justify-center mx-auto">
            <MapPin className="w-12 h-12 text-white" />
          </div>
          <h2 className="text-2xl font-bold text-slate-800">Sign in to view your contributions</h2>
          <p className="text-slate-600">Track your markers, maps, and impact on the community</p>
        </div>
      </div>
    );
  }

  return (
    <div className="h-full bg-gradient-to-br from-blue-50 via-indigo-50 to-emerald-50 p-6 overflow-y-auto">
      <div className="max-w-6xl mx-auto space-y-6">
        {/* Header Section */}
        <div className="bg-white/80 backdrop-blur-xl rounded-2xl shadow-xl p-6 border border-white/20">
          <div className="flex items-center justify-between mb-6">
            <div>
              <h1 className="text-3xl font-bold bg-gradient-to-r from-blue-600 to-emerald-500 bg-clip-text text-transparent">
                My Contributions
              </h1>
              <p className="text-slate-600 mt-2">Track your impact on the TravelMapX community</p>
            </div>
            <Button className="bg-gradient-to-r from-blue-600 to-emerald-500 hover:from-blue-700 hover:to-emerald-600">
              Share Profile
            </Button>
          </div>

          {/* Stats Grid */}
          <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
            <Card className="bg-gradient-to-br from-blue-50 to-blue-100 border-blue-200">
              <CardContent className="p-4 text-center">
                <div className="text-2xl font-bold text-blue-700">{stats.total}</div>
                <div className="text-sm text-blue-600">Total</div>
              </CardContent>
            </Card>
            <Card className="bg-gradient-to-br from-emerald-50 to-emerald-100 border-emerald-200">
              <CardContent className="p-4 text-center">
                <div className="text-2xl font-bold text-emerald-700">{stats.markers}</div>
                <div className="text-sm text-emerald-600">Markers</div>
              </CardContent>
            </Card>
            <Card className="bg-gradient-to-br from-purple-50 to-purple-100 border-purple-200">
              <CardContent className="p-4 text-center">
                <div className="text-2xl font-bold text-purple-700">{stats.maps}</div>
                <div className="text-sm text-purple-600">Maps</div>
              </CardContent>
            </Card>
            <Card className="bg-gradient-to-br from-orange-50 to-orange-100 border-orange-200">
              <CardContent className="p-4 text-center">
                <div className="text-2xl font-bold text-orange-700">{stats.totalViews.toLocaleString()}</div>
                <div className="text-sm text-orange-600">Views</div>
              </CardContent>
            </Card>
            <Card className="bg-gradient-to-br from-red-50 to-red-100 border-red-200">
              <CardContent className="p-4 text-center">
                <div className="text-2xl font-bold text-red-700">{stats.totalLikes}</div>
                <div className="text-sm text-red-600">Likes</div>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Contributions List */}
        <div className="bg-white/80 backdrop-blur-xl rounded-2xl shadow-xl border border-white/20">
          <div className="p-6 border-b border-white/20">
            <Tabs value={activeTab} onValueChange={setActiveTab}>
              <TabsList className="grid w-full grid-cols-3 bg-slate-100">
                <TabsTrigger value="all">All ({stats.total})</TabsTrigger>
                <TabsTrigger value="marker">Markers ({stats.markers})</TabsTrigger>
                <TabsTrigger value="map">Maps ({stats.maps})</TabsTrigger>
              </TabsList>
            </Tabs>
          </div>

          <div className="p-6">
            {loading ? (
              <div className="space-y-4">
                {[1, 2, 3].map((i) => (
                  <div key={i} className="animate-pulse">
                    <div className="h-24 bg-slate-200 rounded-xl"></div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="space-y-4">
                {filteredContributions.map((contribution) => (
                  <Card key={contribution.id} className="hover-lift transition-all duration-200 hover:shadow-lg bg-white/60 backdrop-blur-sm border border-white/30">
                    <CardContent className="p-6">
                      <div className="flex items-start justify-between">
                        <div className="flex items-start space-x-4 flex-1">
                          <div className="text-3xl">
                            {getTypeIcon(contribution.type)}
                          </div>
                          
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center space-x-3 mb-2">
                              <h3 className="font-bold text-lg text-slate-800 truncate">
                                {contribution.title}
                              </h3>
                              {getStatusBadge(contribution.status)}
                            </div>
                            
                            {contribution.description && (
                              <p className="text-slate-600 mb-3 line-clamp-2">
                                {contribution.description}
                              </p>
                            )}
                            
                            <div className="flex items-center space-x-4 text-sm text-slate-500">
                              <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-200">
                                {contribution.category}
                              </Badge>
                              
                              {contribution.location && (
                                <div className="flex items-center space-x-1">
                                  <MapPin className="w-4 h-4" />
                                  <span>{contribution.location}</span>
                                </div>
                              )}
                              
                              <div className="flex items-center space-x-1">
                                <Calendar className="w-4 h-4" />
                                <span>{new Date(contribution.createdAt).toLocaleDateString()}</span>
                              </div>
                              
                              {contribution.rating && (
                                <div className="flex items-center space-x-1">
                                  <Star className="w-4 h-4 text-yellow-500" />
                                  <span>{contribution.rating}</span>
                                </div>
                              )}
                            </div>
                          </div>
                        </div>
                        
                        <div className="flex items-center space-x-4 ml-4">
                          <div className="flex items-center space-x-4 text-sm text-slate-500">
                            <div className="flex items-center space-x-1">
                              <Eye className="w-4 h-4" />
                              <span>{contribution.views}</span>
                            </div>
                            <div className="flex items-center space-x-1">
                              <Heart className="w-4 h-4 text-red-500" />
                              <span>{contribution.likes}</span>
                            </div>
                          </div>
                          
                          <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                              <Button variant="ghost" size="sm" className="p-2">
                                <MoreHorizontal className="w-4 h-4" />
                              </Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent align="end">
                              <DropdownMenuItem>
                                <Edit className="w-4 h-4 mr-2" />
                                Edit
                              </DropdownMenuItem>
                              <DropdownMenuItem>
                                <Share className="w-4 h-4 mr-2" />
                                Share
                              </DropdownMenuItem>
                              <DropdownMenuItem className="text-red-600">
                                <Trash2 className="w-4 h-4 mr-2" />
                                Delete
                              </DropdownMenuItem>
                            </DropdownMenuContent>
                          </DropdownMenu>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
                
                {filteredContributions.length === 0 && (
                  <div className="text-center py-12">
                    <div className="w-16 h-16 bg-slate-200 rounded-full flex items-center justify-center mx-auto mb-4">
                      <MapPin className="w-8 h-8 text-slate-400" />
                    </div>
                    <h3 className="font-semibold text-slate-600 mb-2">No contributions yet</h3>
                    <p className="text-slate-500 mb-4">Start contributing by adding markers or creating maps</p>
                    <Button className="bg-gradient-to-r from-blue-600 to-emerald-500 hover:from-blue-700 hover:to-emerald-600">
                      Create Your First Contribution
                    </Button>
                  </div>
                )}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}