import React, { useState, useEffect } from 'react';
import { ChevronLeft, ChevronRight, User, BookOpen, GraduationCap, Building, Zap, Code, Award, Network, Users, Heart, Play, Pause, Monitor, Brain, Trophy, Star, Sparkles, Maximize, Minimize } from 'lucide-react';
import { Button } from './ui/button';
import { Card } from './ui/card';
import { motion, AnimatePresence } from 'motion/react';

const slides = [
  {
    id: 1,
    type: 'intro',
    title: 'My Idol: Barbara Liskov',
    subtitle: 'Presented by Ishita Atwal',
    class: '216-B',
    icon: User,
    description: 'A pioneer in computer science and one of the most influential women in technology'
  },
  {
    id: 2,
    type: 'content',
    title: 'Early Life & Background',
    points: [
      'Born in 1939, Los Angeles, California',
      'Grew up interested in problem solving, mathematics, and logic',
      'At that time, very few women pursued science and technology careers'
    ],
    icon: BookOpen,
    visual: 'education'
  },
  {
    id: 3,
    type: 'content',
    title: 'Education',
    points: [
      '1961: Graduated with a BA in Mathematics from UC Berkeley',
      'Initially worked in industry but realized her passion was in computing',
      '1968: Earned a PhD in Computer Science from Stanford University, becoming one of the first women in the US to do so'
    ],
    icon: GraduationCap,
    visual: 'graduation'
  },
  {
    id: 4,
    type: 'content',
    title: 'Career Beginnings',
    points: [
      'Early career at MIT, where she became one of the first women to join the faculty in Computer Science',
      'Worked on AI (artificial intelligence) at Stanford before moving to programming languages',
      'Began developing ideas that shaped the future of software design'
    ],
    icon: Building,
    visual: 'career'
  },
  {
    id: 5,
    type: 'content',
    title: 'Hardships & Challenges',
    points: [
      'Faced strong gender bias in academia and technology',
      'Very few women role models or mentors in her time',
      'Often underestimated but proved herself through groundbreaking research'
    ],
    icon: Zap,
    visual: 'challenges'
  },
  {
    id: 6,
    type: 'content',
    title: 'Key Contributions',
    points: [
      'Designed CLU programming language in the 1970s, an early object-oriented language',
      'Researched distributed systems, making computing more reliable',
      'Formulated the Liskov Substitution Principle, a foundation of modern object-oriented programming'
    ],
    icon: Code,
    visual: 'code'
  },
  {
    id: 7,
    type: 'principle',
    title: 'Liskov Substitution Principle (LSP)',
    definition: 'Objects of a superclass should be replaceable with objects of a subclass without breaking the program.',
    example: "If 'Bird' is a class, and 'Sparrow' is a subclass, you should be able to substitute Sparrow wherever Bird is expected.",
    impact: 'This principle makes software easier to build, scale, and maintain.',
    icon: Code,
    visual: 'diagram'
  },
  {
    id: 8,
    type: 'achievements',
    title: 'Achievements & Awards',
    awards: [
      { name: '2008: Turing Award', description: 'The "Nobel Prize of Computing"', icon: Trophy },
      { name: 'IEEE John von Neumann Medal', description: 'For outstanding contributions to computer science', icon: Award },
      { name: 'National Academy of Engineering', description: 'Member recognition', icon: Star },
      { name: 'First woman in the US', description: 'To earn a PhD in Computer Science', icon: Sparkles }
    ],
    icon: Award,
    visual: 'awards'
  },
  {
    id: 9,
    type: 'content',
    title: 'Impact on Technology',
    points: [
      'Her work in programming languages influences Java, C#, Python, and modern OOP',
      'Distributed systems research led to more secure, reliable networks',
      'Paved the way for women in computing, inspiring diversity in STEM'
    ],
    icon: Network,
    visual: 'technology'
  },
  {
    id: 10,
    type: 'content',
    title: 'Inspiration & Legacy',
    points: [
      'Role model for generations of women and men in computer science',
      'Proved that excellence and persistence can break social barriers',
      'Legacy lives in every piece of modern software architecture'
    ],
    icon: Users,
    visual: 'mentorship'
  },
  {
    id: 11,
    type: 'conclusion',
    title: 'Conclusion',
    points: [
      "Barbara Liskov's journey = resilience + innovation + leadership",
      'Her research defines how we build reliable software today'
    ],
    quote: 'She is not just a computer scientist, she is an inspiration.',
    icon: Heart,
    visual: 'conclusion'
  }
];

// Matrix-style Code Rain
const MatrixCodeRain = () => {
  const chars = '01{}()<>[];=+-*/ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz';
  
  return (
    <div className="absolute inset-0 overflow-hidden pointer-events-none opacity-20">
      {[...Array(25)].map((_, i) => (
        <motion.div
          key={i}
          className="absolute text-green-400 font-mono text-sm"
          style={{ left: `${i * 4}%` }}
          animate={{
            y: [-100, window.innerHeight + 100],
          }}
          transition={{
            duration: 2 + Math.random() * 3,
            repeat: Infinity,
            delay: Math.random() * 2,
            ease: "linear"
          }}
        >
          {[...Array(30)].map((_, j) => (
            <div key={j} className="mb-1">
              {chars[Math.floor(Math.random() * chars.length)]}
            </div>
          ))}
        </motion.div>
      ))}
    </div>
  );
};

// Simple Circuit Network
const CircuitNetwork = () => {
  return (
    <div className="absolute inset-0 overflow-hidden pointer-events-none opacity-10">
      <svg className="w-full h-full" viewBox="0 0 1200 800">
        <motion.path
          d="M0,100 L300,100 L300,300 L600,300 L600,500 L900,500 M0,200 L200,200 L200,400 L500,400 L500,600 L800,600"
          stroke="#00ff00"
          strokeWidth="1"
          fill="none"
          initial={{ pathLength: 0 }}
          animate={{ pathLength: 1 }}
          transition={{ duration: 5, repeat: Infinity, repeatType: "loop" }}
        />
        
        {[...Array(8)].map((_, i) => (
          <motion.circle
            key={i}
            cx={150 + i * 150}
            cy={100 + (i % 3) * 200}
            r="3"
            fill="#00ff00"
            initial={{ scale: 0 }}
            animate={{ 
              scale: [0, 1.2, 1],
              opacity: [0.5, 1, 0.5]
            }}
            transition={{
              duration: 2,
              repeat: Infinity,
              delay: i * 0.3
            }}
          />
        ))}
      </svg>
    </div>
  );
};

export default function BarbaraLiskovPresentation() {
  const [currentSlide, setCurrentSlide] = useState(0);
  const [isAutoPlay, setIsAutoPlay] = useState(false);
  const [direction, setDirection] = useState(1);
  const [isFullscreen, setIsFullscreen] = useState(false);

  // Fullscreen functionality
  const toggleFullscreen = async () => {
    try {
      if (!document.fullscreenElement) {
        await document.documentElement.requestFullscreen();
        setIsFullscreen(true);
      } else {
        await document.exitFullscreen();
        setIsFullscreen(false);
      }
    } catch (error) {
      console.error('Error toggling fullscreen:', error);
    }
  };

  // Listen for fullscreen changes
  useEffect(() => {
    const handleFullscreenChange = () => {
      setIsFullscreen(!!document.fullscreenElement);
    };

    document.addEventListener('fullscreenchange', handleFullscreenChange);
    return () => document.removeEventListener('fullscreenchange', handleFullscreenChange);
  }, []);

  // Auto-play functionality
  useEffect(() => {
    if (!isAutoPlay) return;

    const interval = setInterval(() => {
      setCurrentSlide((prev) => {
        if (prev >= slides.length - 1) {
          setIsAutoPlay(false);
          return prev;
        }
        setDirection(1);
        return prev + 1;
      });
    }, 6000);

    return () => clearInterval(interval);
  }, [isAutoPlay, currentSlide]);

  // Keyboard navigation
  useEffect(() => {
    const handleKeyPress = (event: KeyboardEvent) => {
      if (event.key === 'ArrowRight' && currentSlide < slides.length - 1) {
        setDirection(1);
        setCurrentSlide(currentSlide + 1);
      } else if (event.key === 'ArrowLeft' && currentSlide > 0) {
        setDirection(-1);
        setCurrentSlide(currentSlide - 1);
      } else if (event.key === ' ') {
        event.preventDefault();
        setIsAutoPlay(!isAutoPlay);
      } else if (event.key === 'f' || event.key === 'F') {
        event.preventDefault();
        toggleFullscreen();
      }
    };

    window.addEventListener('keydown', handleKeyPress);
    return () => window.removeEventListener('keydown', handleKeyPress);
  }, [currentSlide, isAutoPlay]);

  const nextSlide = () => {
    if (currentSlide < slides.length - 1) {
      setDirection(1);
      setCurrentSlide(currentSlide + 1);
    }
  };

  const prevSlide = () => {
    if (currentSlide > 0) {
      setDirection(-1);
      setCurrentSlide(currentSlide - 1);
    }
  };

  const goToSlide = (index: number) => {
    setDirection(index > currentSlide ? 1 : -1);
    setCurrentSlide(index);
  };

  const slide = slides[currentSlide];
  const IconComponent = slide.icon;

  const slideVariants = {
    enter: (direction: number) => ({
      x: direction > 0 ? 300 : -300,
      opacity: 0,
    }),
    center: {
      zIndex: 1,
      x: 0,
      opacity: 1,
    },
    exit: (direction: number) => ({
      zIndex: 0,
      x: direction < 0 ? 300 : -300,
      opacity: 0,
    }),
  };

  return (
    <div className="min-h-screen bg-black relative overflow-hidden">
      <MatrixCodeRain />
      <CircuitNetwork />
      
      {/* Grid overlay */}
      <div className="absolute inset-0 bg-[linear-gradient(rgba(0,255,0,0.03)_1px,transparent_1px),linear-gradient(90deg,rgba(0,255,0,0.03)_1px,transparent_1px)] bg-[size:30px_30px]" />
      
      <div className="relative z-10 min-h-screen flex items-center justify-center p-8">
        <div className="w-full max-w-7xl h-[85vh] relative">
          
          <AnimatePresence mode="wait" custom={direction}>
            <motion.div
              key={currentSlide}
              custom={direction}
              variants={slideVariants}
              initial="enter"
              animate="center"
              exit="exit"
              transition={{
                x: { type: "spring", stiffness: 300, damping: 30 },
                opacity: { duration: 0.3 }
              }}
              className="absolute inset-0"
            >
              <div className="w-full h-full flex">
                
                {/* Content Section */}
                <div className="flex-1 flex flex-col justify-center pr-8">
                  
                  {/* Icon */}
                  <motion.div
                    initial={{ scale: 0 }}
                    animate={{ scale: 1 }}
                    transition={{ delay: 0.2, type: "spring", stiffness: 200 }}
                    className="mb-8"
                  >
                    <div className="w-20 h-20 bg-green-500 rounded-lg flex items-center justify-center shadow-lg">
                      <IconComponent className="w-10 h-10 text-black" strokeWidth={2} />
                    </div>
                  </motion.div>

                  {/* Title */}
                  <motion.h1
                    initial={{ y: 30, opacity: 0 }}
                    animate={{ y: 0, opacity: 1 }}
                    transition={{ delay: 0.3, duration: 0.6 }}
                    className="text-5xl lg:text-7xl font-bold text-white mb-8 leading-tight"
                    style={{ textShadow: '2px 2px 8px rgba(0, 0, 0, 0.8), 0 0 20px rgba(0, 255, 0, 0.3)' }}
                  >
                    {slide.title}
                  </motion.h1>

                  {/* Content based on slide type */}
                  {slide.type === 'intro' && (
                    <motion.div
                      initial={{ y: 20, opacity: 0 }}
                      animate={{ y: 0, opacity: 1 }}
                      transition={{ delay: 0.5, duration: 0.6 }}
                      className="space-y-6"
                    >
                      <p className="text-2xl text-green-400 font-medium" style={{ textShadow: '1px 1px 4px rgba(0, 0, 0, 0.8)' }}>
                        {slide.subtitle}
                      </p>
                      <p className="text-xl text-gray-300" style={{ textShadow: '1px 1px 4px rgba(0, 0, 0, 0.8)' }}>
                        Class {slide.class}
                      </p>
                      <p className="text-xl text-gray-200 leading-relaxed max-w-3xl" style={{ textShadow: '1px 1px 4px rgba(0, 0, 0, 0.8)' }}>
                        {slide.description}
                      </p>
                    </motion.div>
                  )}

                  {slide.type === 'content' && (
                    <motion.div
                      initial={{ y: 20, opacity: 0 }}
                      animate={{ y: 0, opacity: 1 }}
                      transition={{ delay: 0.5, duration: 0.6 }}
                      className="space-y-8"
                    >
                      {slide.points?.map((point, index) => (
                        <motion.div
                          key={index}
                          initial={{ x: -20, opacity: 0 }}
                          animate={{ x: 0, opacity: 1 }}
                          transition={{ delay: 0.7 + index * 0.1, duration: 0.4 }}
                          className="flex items-start space-x-6"
                        >
                          <div className="w-3 h-3 bg-green-500 rounded-full mt-3 flex-shrink-0 shadow-lg" 
                               style={{ boxShadow: '0 0 8px rgba(0, 255, 0, 0.6)' }} />
                          <p className="text-xl text-gray-200 leading-relaxed" 
                             style={{ textShadow: '1px 1px 4px rgba(0, 0, 0, 0.8)' }}>
                            {point}
                          </p>
                        </motion.div>
                      ))}
                    </motion.div>
                  )}

                  {slide.type === 'principle' && (
                    <motion.div
                      initial={{ y: 20, opacity: 0 }}
                      animate={{ y: 0, opacity: 1 }}
                      transition={{ delay: 0.5, duration: 0.6 }}
                      className="space-y-10"
                    >
                      <div className="space-y-4">
                        <h3 className="text-2xl font-semibold text-green-400 mb-4" 
                            style={{ textShadow: '1px 1px 4px rgba(0, 0, 0, 0.8), 0 0 10px rgba(0, 255, 0, 0.4)' }}>
                          Definition:
                        </h3>
                        <p className="text-xl text-gray-200 leading-relaxed pl-6 border-l-4 border-green-500" 
                           style={{ textShadow: '1px 1px 4px rgba(0, 0, 0, 0.8)' }}>
                          {slide.definition}
                        </p>
                      </div>
                      
                      <div className="space-y-4">
                        <h3 className="text-2xl font-semibold text-green-400 mb-4" 
                            style={{ textShadow: '1px 1px 4px rgba(0, 0, 0, 0.8), 0 0 10px rgba(0, 255, 0, 0.4)' }}>
                          Example:
                        </h3>
                        <p className="text-xl text-gray-200 leading-relaxed pl-6 border-l-4 border-green-400" 
                           style={{ textShadow: '1px 1px 4px rgba(0, 0, 0, 0.8)' }}>
                          {slide.example}
                        </p>
                      </div>
                      
                      <div className="space-y-4">
                        <h3 className="text-2xl font-semibold text-green-400 mb-4" 
                            style={{ textShadow: '1px 1px 4px rgba(0, 0, 0, 0.8), 0 0 10px rgba(0, 255, 0, 0.4)' }}>
                          Impact:
                        </h3>
                        <p className="text-xl text-gray-200 leading-relaxed pl-6 border-l-4 border-green-300" 
                           style={{ textShadow: '1px 1px 4px rgba(0, 0, 0, 0.8)' }}>
                          {slide.impact}
                        </p>
                      </div>
                    </motion.div>
                  )}

                  {slide.type === 'achievements' && (
                    <motion.div
                      initial={{ y: 20, opacity: 0 }}
                      animate={{ y: 0, opacity: 1 }}
                      transition={{ delay: 0.5, duration: 0.6 }}
                      className="space-y-8"
                    >
                      {slide.awards?.map((award, index) => {
                        const AwardIcon = award.icon;
                        return (
                          <motion.div
                            key={index}
                            initial={{ scale: 0.9, opacity: 0 }}
                            animate={{ scale: 1, opacity: 1 }}
                            transition={{ delay: 0.7 + index * 0.1, duration: 0.4 }}
                            className="flex items-start space-x-6"
                          >
                            <div className="bg-green-500 p-4 rounded-lg shadow-lg" 
                                 style={{ boxShadow: '0 0 15px rgba(0, 255, 0, 0.4)' }}>
                              <AwardIcon className="w-8 h-8 text-black" strokeWidth={2} />
                            </div>
                            <div>
                              <h3 className="text-2xl font-bold text-white mb-3" 
                                  style={{ textShadow: '1px 1px 4px rgba(0, 0, 0, 0.8), 0 0 10px rgba(0, 255, 0, 0.3)' }}>
                                {award.name}
                              </h3>
                              <p className="text-lg text-gray-300" 
                                 style={{ textShadow: '1px 1px 4px rgba(0, 0, 0, 0.8)' }}>
                                {award.description}
                              </p>
                            </div>
                          </motion.div>
                        );
                      })}
                    </motion.div>
                  )}

                  {slide.type === 'conclusion' && (
                    <motion.div
                      initial={{ y: 20, opacity: 0 }}
                      animate={{ y: 0, opacity: 1 }}
                      transition={{ delay: 0.5, duration: 0.6 }}
                      className="space-y-10"
                    >
                      <div className="space-y-8">
                        {slide.points?.map((point, index) => (
                          <motion.div
                            key={index}
                            initial={{ x: -20, opacity: 0 }}
                            animate={{ x: 0, opacity: 1 }}
                            transition={{ delay: 0.7 + index * 0.1, duration: 0.4 }}
                            className="flex items-start space-x-6"
                          >
                            <div className="w-3 h-3 bg-green-500 rounded-full mt-3 flex-shrink-0 shadow-lg" 
                                 style={{ boxShadow: '0 0 8px rgba(0, 255, 0, 0.6)' }} />
                            <p className="text-xl text-gray-200 leading-relaxed" 
                               style={{ textShadow: '1px 1px 4px rgba(0, 0, 0, 0.8)' }}>
                              {point}
                            </p>
                          </motion.div>
                        ))}
                      </div>
                      
                      {slide.quote && (
                        <motion.div
                          initial={{ scale: 0.95, opacity: 0 }}
                          animate={{ scale: 1, opacity: 1 }}
                          transition={{ delay: 1, duration: 0.6 }}
                          className="text-center mt-12 pt-8 border-t-2 border-green-500/30"
                        >
                          <p className="text-3xl font-light text-white leading-relaxed italic"
                             style={{ textShadow: '2px 2px 6px rgba(0, 0, 0, 0.8), 0 0 15px rgba(0, 255, 0, 0.4)' }}>
                            "{slide.quote}"
                          </p>
                        </motion.div>
                      )}
                    </motion.div>
                  )}
                </div>

                {/* Visual Section */}
                <div className="w-1/3 flex items-center justify-center relative">
                  <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,_rgba(0,255,0,0.1)_1px,_transparent_1px)] bg-[length:20px_20px] opacity-40" />
                  
                  <motion.div
                    initial={{ scale: 0 }}
                    animate={{ scale: 1 }}
                    transition={{ delay: 0.8, type: "spring", stiffness: 200 }}
                    className="relative z-10"
                  >
                    {slide.type === 'intro' && (
                      <div className="text-center">
                        <User className="w-32 h-32 mx-auto mb-6 text-green-400 drop-shadow-2xl" 
                              strokeWidth={1} 
                              style={{ filter: 'drop-shadow(0px 0px 20px rgba(0, 255, 0, 0.6))' }} />
                        <div className="text-lg font-mono text-green-400 px-6 py-4 rounded-lg backdrop-blur-sm border border-green-500/30"
                             style={{ 
                               backgroundColor: 'rgba(0, 0, 0, 0.7)',
                               textShadow: '0 0 10px rgba(0, 255, 0, 0.8)' 
                             }}>
                          &lt;pioneer&gt;<br/>
                          &nbsp;&nbsp;Barbara Liskov<br/>
                          &lt;/pioneer&gt;
                        </div>
                      </div>
                    )}
                    
                    {slide.visual === 'code' && (
                      <div className="text-green-400 font-mono text-lg space-y-3 px-8 py-6 rounded-lg backdrop-blur-sm border border-green-500/30"
                           style={{ 
                             backgroundColor: 'rgba(0, 0, 0, 0.7)',
                             textShadow: '0 0 8px rgba(0, 255, 0, 0.8)' 
                           }}>
                        <div>{'{'}</div>
                        <div>&nbsp;&nbsp;class Superclass</div>
                        <div>&nbsp;&nbsp;class Subclass</div>
                        <div>&nbsp;&nbsp;substitutable: true</div>
                        <div>{'}'}</div>
                      </div>
                    )}
                    
                    {!slide.visual && slide.type !== 'intro' && (
                      <IconComponent className="w-32 h-32 text-green-400 drop-shadow-2xl" 
                                     strokeWidth={1}
                                     style={{ filter: 'drop-shadow(0px 0px 20px rgba(0, 255, 0, 0.6))' }} />
                    )}
                  </motion.div>
                </div>

                {/* Slide Counter */}
                <div className="absolute bottom-8 left-8 px-4 py-2 rounded-lg backdrop-blur-sm border border-green-500/30"
                     style={{ backgroundColor: 'rgba(0, 0, 0, 0.7)' }}>
                  <span className="text-sm font-mono text-green-400" 
                        style={{ textShadow: '0 0 8px rgba(0, 255, 0, 0.8)' }}>
                    {currentSlide + 1} / {slides.length}
                  </span>
                </div>
              </div>
            </motion.div>
          </AnimatePresence>

          {/* Navigation Controls */}
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 1, duration: 0.8 }}
            className="absolute bottom-8 left-1/2 transform -translate-x-1/2 flex items-center space-x-4"
          >
            <Button
              onClick={prevSlide}
              disabled={currentSlide === 0}
              variant="outline"
              size="icon"
              className="w-12 h-12 rounded-lg backdrop-blur-sm border-green-500/30 hover:bg-green-500/20 disabled:opacity-30"
              style={{ backgroundColor: 'rgba(0, 0, 0, 0.7)' }}
            >
              <ChevronLeft className="w-5 h-5 text-green-400" />
            </Button>

            <Button
              onClick={() => setIsAutoPlay(!isAutoPlay)}
              variant="outline"
              size="icon"
              className="w-12 h-12 rounded-lg backdrop-blur-sm border-green-500/30 hover:bg-green-500/20"
              style={{ backgroundColor: 'rgba(0, 0, 0, 0.7)' }}
            >
              {isAutoPlay ? (
                <Pause className="w-5 h-5 text-green-400" />
              ) : (
                <Play className="w-5 h-5 text-green-400" />
              )}
            </Button>

            {/* Slide Indicators */}
            <div className="flex space-x-2 px-3 py-2 rounded-lg backdrop-blur-sm border border-green-500/30"
                 style={{ backgroundColor: 'rgba(0, 0, 0, 0.7)' }}>
              {slides.map((_, index) => (
                <button
                  key={index}
                  onClick={() => goToSlide(index)}
                  className={`transition-all duration-300 rounded-full ${
                    index === currentSlide 
                      ? 'w-6 h-3 bg-green-500' 
                      : 'w-3 h-3 bg-gray-600 hover:bg-gray-500'
                  }`}
                  style={index === currentSlide ? { boxShadow: '0 0 8px rgba(0, 255, 0, 0.6)' } : {}}
                />
              ))}
            </div>

            <Button
              onClick={nextSlide}
              disabled={currentSlide === slides.length - 1}
              variant="outline"
              size="icon"
              className="w-12 h-12 rounded-lg backdrop-blur-sm border-green-500/30 hover:bg-green-500/20 disabled:opacity-30"
              style={{ backgroundColor: 'rgba(0, 0, 0, 0.7)' }}
            >
              <ChevronRight className="w-5 h-5 text-green-400" />
            </Button>
          </motion.div>

          {/* Keyboard Navigation Hint */}
          <div className="absolute top-8 right-8 px-4 py-2 rounded-lg backdrop-blur-sm border border-green-500/30"
               style={{ backgroundColor: 'rgba(0, 0, 0, 0.7)' }}>
            <span className="text-xs text-green-400 font-mono" 
                  style={{ textShadow: '0 0 8px rgba(0, 255, 0, 0.8)' }}>
              ← → Keys | Space for Auto-play
            </span>
          </div>

          {/* Fullscreen Toggle Button */}
          <motion.div
            initial={{ opacity: 0, x: 50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 1.2, duration: 0.6 }}
            className="absolute top-8 right-8"
          >
            <Button
              onClick={toggleFullscreen}
              variant="outline"
              size="icon"
              className="w-10 h-10 rounded-lg backdrop-blur-sm border-green-500/30 hover:bg-green-500/20 transition-all duration-300"
              style={{ backgroundColor: 'rgba(0, 0, 0, 0.7)' }}
              title={isFullscreen ? 'Exit Fullscreen (F)' : 'Enter Fullscreen (F)'}
            >
              {isFullscreen ? (
                <Minimize className="w-4 h-4 text-green-400" />
              ) : (
                <Maximize className="w-4 h-4 text-green-400" />
              )}
            </Button>
          </motion.div>

          {/* Keyboard Navigation Hint - moved left to make room for fullscreen button */}
          <div className="absolute top-8 right-20 px-3 py-2 rounded-lg backdrop-blur-sm border border-green-500/30"
               style={{ backgroundColor: 'rgba(0, 0, 0, 0.7)' }}>
            <span className="text-xs text-green-400 font-mono" 
                  style={{ textShadow: '0 0 8px rgba(0, 255, 0, 0.8)' }}>
              ← → Keys | Space | F for Fullscreen
            </span>
          </div>
        </div>
      </div>
    </div>
  );
}