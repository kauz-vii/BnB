import { useState, useEffect } from 'react';
import { GoogleMap } from './GoogleMap';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Alert, AlertDescription } from './ui/alert';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { 
  MapPin, 
  Compass, 
  Navigation, 
  Users, 
  Star,
  TrendingUp,
  Trophy,
  Target,
  Route,
  Locate,
  AlertCircle
} from 'lucide-react';
import type { User } from '@supabase/supabase-js';

// Direct configuration to avoid import issues
const MARKR_CONFIG = {
  googleMaps: {
    apiKey: (() => {
      try {
        // Check localStorage first for development
        const localKey = typeof window !== 'undefined' ? localStorage.getItem('MARKR_GOOGLE_MAPS_API_KEY') : null;
        if (localKey && localKey !== 'DEMO_MODE') {
          return localKey;
        }
        
        // Check environment variables
        const envKey = (window as any)?.import?.meta?.env?.VITE_GOOGLE_MAPS_API_KEY || 
                      (import.meta as any)?.env?.VITE_GOOGLE_MAPS_API_KEY;
        if (envKey && envKey !== 'YOUR_GOOGLE_MAPS_API_KEY' && envKey !== 'DEMO_MODE') {
          return envKey;
        }
        
        return "DEMO_MODE";
      } catch (error) {
        return "DEMO_MODE";
      }
    })(),
  },
  app: {
    name: "Markr",
    defaultLocation: {
      lat: 20.5937,
      lng: 78.9629,
      zoom: 5
    }
  }
};

interface MapViewProps {
  onAddMarker: () => void;
  user: User | null;
}

// Featured locations in India
const featuredLocations = [
  {
    id: 'featured-1',
    name: 'India Gate',
    coordinates: [28.6129, 77.2295] as [number, number],
    description: 'Iconic war memorial in New Delhi',
    totalMarkers: 247,
    category: 'Attraction'
  },
  {
    id: 'featured-2', 
    name: 'Gateway of India',
    coordinates: [18.9220, 72.8347] as [number, number],
    description: 'Historic monument in Mumbai',
    totalMarkers: 189,
    category: 'Attraction'
  },
  {
    id: 'featured-3',
    name: 'Howrah Bridge',
    coordinates: [22.5858, 88.3469] as [number, number],
    description: 'Iconic cantilever bridge in Kolkata',
    totalMarkers: 164,
    category: 'Attraction'
  },
  {
    id: 'featured-4',
    name: 'Charminar',
    coordinates: [17.3616, 78.4747] as [number, number],
    description: 'Historic monument in Hyderabad',
    totalMarkers: 143,
    category: 'Attraction'
  },
  {
    id: 'featured-5',
    name: 'Marina Beach',
    coordinates: [13.0475, 80.2824] as [number, number],
    description: 'Urban beach in Chennai',
    totalMarkers: 198,
    category: 'Attraction'
  }
];

export function MapView({ onAddMarker, user }: MapViewProps) {
  const [currentCenter, setCurrentCenter] = useState<[number, number]>([
    MARKR_CONFIG.app.defaultLocation.lat, 
    MARKR_CONFIG.app.defaultLocation.lng
  ]);
  const [currentZoom, setCurrentZoom] = useState(MARKR_CONFIG.app.defaultLocation.zoom);
  const [showWelcome, setShowWelcome] = useState(!user);
  const [userLocation, setUserLocation] = useState<[number, number] | null>(null);
  const [showDirections, setShowDirections] = useState(false);
  const [directionsFrom, setDirectionsFrom] = useState<[number, number] | null>(null);
  const [directionsTo, setDirectionsTo] = useState<[number, number] | null>(null);
  const [mapStats, setMapStats] = useState({
    totalUsers: 4247,
    totalMarkers: 28432,
    activeExplorers: 387
  });
  
  // Sample markers for demonstration
  const [markers, setMarkers] = useState([
    {
      id: 'marker-1',
      position: [28.6129, 77.2295] as [number, number],
      title: 'India Gate Food Court',
      type: 'food' as const,
      info: {
        name: 'India Gate Food Court',
        type: 'food',
        description: 'Popular food stalls near India Gate',
        address: 'Rajpath, New Delhi'
      }
    },
    {
      id: 'marker-2',
      position: [18.9220, 72.8347] as [number, number],
      title: 'Gateway Cafe',
      type: 'food' as const,
      info: {
        name: 'Gateway Cafe',
        type: 'food',
        description: 'Cafe with sea view near Gateway of India',
        address: 'Apollo Bunder, Mumbai'
      }
    },
    {
      id: 'marker-3',
      position: [22.5858, 88.3469] as [number, number],
      title: 'Howrah Bridge Viewpoint',
      type: 'attraction' as const,
      info: {
        name: 'Howrah Bridge Viewpoint',
        type: 'attraction',
        description: 'Best viewpoint for bridge photography',
        address: 'Strand Road, Kolkata'
      }
    }
  ]);

  // Auto-hide welcome message after 5 seconds
  useEffect(() => {
    if (!user && showWelcome) {
      const timer = setTimeout(() => setShowWelcome(false), 5000);
      return () => clearTimeout(timer);
    }
  }, [user, showWelcome]);

  const handleMarkerAdd = (latlng: { lat: number; lng: number }) => {
    console.log('New marker requested at:', latlng);
    // This will trigger the AddMarkerModal
    onAddMarker();
  };

  const handleMarkerClick = (marker: any) => {
    console.log('Marker clicked:', marker);
    // Future: Open marker details modal or show in sidebar
  };

  const jumpToLocation = (coordinates: [number, number]) => {
    setCurrentCenter(coordinates);
    setCurrentZoom(15);
  };

  const getUserLocation = () => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          const { latitude, longitude } = position.coords;
          setUserLocation([latitude, longitude]);
          setCurrentCenter([latitude, longitude]);
          setCurrentZoom(16);
        },
        (error) => {
          console.error('Error getting location:', error);
          alert('Unable to get your location. Please enable location services.');
          // Fallback to India center
          setCurrentCenter([MARKR_CONFIG.app.defaultLocation.lat, MARKR_CONFIG.app.defaultLocation.lng]);
          setCurrentZoom(MARKR_CONFIG.app.defaultLocation.zoom);
        }
      );
    } else {
      alert('Geolocation is not supported by this browser.');
    }
  };

  const getDirections = (to: [number, number]) => {
    if (userLocation) {
      setDirectionsFrom(userLocation);
      setDirectionsTo(to);
      setShowDirections(true);
    } else {
      getUserLocation();
      setTimeout(() => {
        if (userLocation) {
          setDirectionsFrom(userLocation);
          setDirectionsTo(to);
          setShowDirections(true);
        }
      }, 1000);
    }
  };

  const clearDirections = () => {
    setShowDirections(false);
    setDirectionsFrom(null);
    setDirectionsTo(null);
  };

  return (
    <div className="h-full bg-gradient-to-br from-blue-50 via-indigo-50 to-emerald-50 dark:from-gray-900 dark:via-gray-800 dark:to-gray-900 relative">
      {/* API Key Alert */}
      {MARKR_CONFIG.googleMaps.apiKey === 'DEMO_MODE' && (
        <Alert className="absolute top-4 left-1/2 transform -translate-x-1/2 z-[1001] max-w-md border-orange-200 bg-orange-50 dark:bg-orange-900/20">
          <AlertCircle className="h-4 w-4 text-orange-600" />
          <AlertDescription className="text-orange-800 dark:text-orange-200">
            <span className="font-medium">Demo Mode:</span> Configure Google Maps API key for full functionality.
            <Button
              variant="link"
              size="sm"
              className="p-0 h-auto ml-2 text-orange-600 hover:text-orange-800"
              onClick={() => window.open(window.location.origin + '?setup=maps', '_blank')}
            >
              Set up now
            </Button>
          </AlertDescription>
        </Alert>
      )}

      {/* Main Google Map */}
      <GoogleMap
        center={currentCenter}
        zoom={currentZoom}
        markers={markers}
        onMarkerClick={handleMarkerClick}
        onMapClick={(coordinates) => {
          console.log('Map clicked at:', coordinates);
          if (user) {
            handleMarkerAdd({ lat: coordinates[0], lng: coordinates[1] });
          }
        }}
        userLocation={userLocation}
        apiKey={MARKR_CONFIG.googleMaps.apiKey}
        showDirections={showDirections}
        directionsFrom={directionsFrom || undefined}
        directionsTo={directionsTo || undefined}
      />

      {/* Welcome Overlay for New Users */}
      {showWelcome && !user && (
        <div className="absolute inset-0 z-[1100] bg-black/40 backdrop-blur-sm flex items-center justify-center p-4">
          <Card className="max-w-lg glassmorphism border-white/20 dark:border-gray-700/20 shadow-2xl">
            <CardHeader className="text-center">
              <div className="w-16 h-16 bg-gradient-to-r from-blue-600 to-emerald-500 rounded-full mx-auto mb-4 flex items-center justify-center">
                <MapPin className="w-8 h-8 text-white" />
              </div>
              <CardTitle className="text-2xl text-gray-900 dark:text-gray-100">
                Welcome to {MARKR_CONFIG.app.name}
              </CardTitle>
            </CardHeader>
            <CardContent className="text-center space-y-4">
              <p className="text-gray-600 dark:text-gray-300">
                Discover amazing places through the eyes of fellow travelers. 
                Explore interactive maps with real insights from the community.
              </p>
              <div className="flex justify-center gap-4 text-sm text-gray-500 dark:text-gray-400">
                <div className="flex items-center gap-1">
                  <Users className="w-4 h-4" />
                  <span>{mapStats.totalUsers.toLocaleString()} explorers</span>
                </div>
                <div className="flex items-center gap-1">
                  <MapPin className="w-4 h-4" />
                  <span>{mapStats.totalMarkers.toLocaleString()} markers</span>
                </div>
              </div>
              <Button 
                onClick={() => setShowWelcome(false)}
                className="bg-gradient-to-r from-blue-600 to-emerald-500 hover:from-blue-700 hover:to-emerald-600 text-white px-8"
              >
                Start Exploring
              </Button>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Quick Actions Sidebar */}
      <div className="absolute top-20 left-4 z-[1000] space-y-3 max-w-[280px]">
        {/* Location Controls */}
        <Card className="glassmorphism border-white/20 dark:border-gray-700/20 shadow-xl">
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center gap-2 text-sm text-gray-800 dark:text-gray-200">
              <Navigation className="w-4 h-4" />
              Quick Navigation
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-2">
            <Button
              onClick={getUserLocation}
              variant="outline"
              size="sm"
              className="w-full justify-start bg-white/50 dark:bg-gray-800/50 border-white/30 dark:border-gray-600/30 hover:bg-white/70 dark:hover:bg-gray-700/70"
            >
              <Target className="w-4 h-4 mr-2" />
              My Location
            </Button>
            <div className="space-y-1">
              {featuredLocations.map((location) => (
                <div key={location.id} className="flex gap-1">
                  <Button
                    onClick={() => jumpToLocation(location.coordinates)}
                    variant="ghost"
                    size="sm"
                    className="flex-1 justify-between text-xs hover:bg-white/20 dark:hover:bg-gray-800/20"
                  >
                    <span className="flex items-center gap-2">
                      <Compass className="w-3 h-3" />
                      {location.name}
                    </span>
                    <Badge variant="secondary" className="text-xs">
                      {location.totalMarkers}
                    </Badge>
                  </Button>
                  <Button
                    onClick={() => getDirections(location.coordinates)}
                    variant="ghost"
                    size="sm"
                    className="w-8 h-8 p-0 hover:bg-blue-100 dark:hover:bg-blue-900/20"
                    title="Get Directions"
                  >
                    <Route className="w-3 h-3" />
                  </Button>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Real-time Stats */}
        <Card className="glassmorphism border-white/20 dark:border-gray-700/20 shadow-xl">
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center gap-2 text-sm text-gray-800 dark:text-gray-200">
              <TrendingUp className="w-4 h-4" />
              Live Stats
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs text-gray-600 dark:text-gray-400">Active Now</span>
              <div className="flex items-center gap-1 text-emerald-600 dark:text-emerald-400">
                <div className="w-2 h-2 bg-emerald-500 rounded-full animate-pulse" />
                <span className="font-medium text-sm">{mapStats.activeExplorers}</span>
              </div>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-xs text-gray-600 dark:text-gray-400">Total Explorers</span>
              <span className="font-medium text-sm text-blue-600 dark:text-blue-400">
                {mapStats.totalUsers.toLocaleString()}
              </span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-xs text-gray-600 dark:text-gray-400">Markers Created</span>
              <span className="font-medium text-sm text-slate-600 dark:text-slate-400">
                {mapStats.totalMarkers.toLocaleString()}
              </span>
            </div>
            {user && (
              <div className="pt-2 border-t border-white/20 dark:border-gray-600/20">
                <div className="flex items-center justify-between">
                  <span className="text-xs text-gray-600 dark:text-gray-400">Your Rank</span>
                  <div className="flex items-center gap-1">
                    <Trophy className="w-3 h-3 text-yellow-500" />
                    <span className="font-medium text-sm text-yellow-600 dark:text-yellow-400">#42</span>
                  </div>
                </div>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Pro tip for authenticated users */}
        {user && (
          <Card className="glassmorphism border-emerald-500/20 bg-emerald-50/50 dark:bg-emerald-900/20 shadow-xl">
            <CardContent className="p-4">
              <div className="flex items-start gap-3">
                <div className="w-8 h-8 bg-emerald-500 rounded-full flex items-center justify-center flex-shrink-0">
                  <Star className="w-4 h-4 text-white" />
                </div>
                <div>
                  <h4 className="font-medium text-emerald-800 dark:text-emerald-200 text-sm mb-1">
                    Pro Tip
                  </h4>
                  <p className="text-xs text-emerald-700 dark:text-emerald-300">
                    Long-press anywhere on the map to quickly add a marker, or use the + button for guided creation.
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Directions Panel */}
        {showDirections && (
          <Card className="glassmorphism border-blue-500/20 bg-blue-50/50 dark:bg-blue-900/20 shadow-xl mt-3">
            <CardHeader className="pb-3">
              <CardTitle className="flex items-center justify-between text-sm text-blue-800 dark:text-blue-200">
                <span className="flex items-center gap-2">
                  <Route className="w-4 h-4" />
                  Navigation Active
                </span>
                <Button
                  onClick={clearDirections}
                  variant="ghost"
                  size="sm"
                  className="h-6 w-6 p-0 text-blue-600 hover:text-blue-800"
                >
                  ×
                </Button>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="text-xs text-blue-700 dark:text-blue-300">
                <div className="flex items-center gap-2 mb-1">
                  <div className="w-2 h-2 bg-blue-500 rounded-full" />
                  <span>From: Your Location</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 bg-red-500 rounded-full" />
                  <span>To: Selected Destination</span>
                </div>
              </div>
              <p className="text-xs text-blue-600 dark:text-blue-400">
                Follow the blue route on the map for turn-by-turn directions.
              </p>
            </CardContent>
          </Card>
        )}
      </div>

      {/* Mobile-optimized bottom panel */}
      <div className="absolute bottom-4 right-4 z-[1000] md:hidden">
        <Card className="glassmorphism border-white/20 dark:border-gray-700/20 shadow-xl">
          <CardContent className="p-3">
            <div className="flex items-center gap-3 text-xs">
              <div className="flex items-center gap-1 text-blue-600 dark:text-blue-400">
                <Users className="w-3 h-3" />
                <span>{mapStats.activeExplorers}</span>
              </div>
              <div className="w-1 h-1 bg-gray-400 rounded-full" />
              <div className="flex items-center gap-1 text-emerald-600 dark:text-emerald-400">
                <MapPin className="w-3 h-3" />
                <span>{mapStats.totalMarkers.toLocaleString()}</span>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}