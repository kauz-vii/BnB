import { motion } from 'framer-motion';
import { Star, Award, Film, Heart, Zap, Shield } from 'lucide-react';

export default function IntroSlide() {
  const achievements = [
    { icon: Film, text: "3x Golden Globe Nominee", delay: 1.2 },
    { icon: Award, text: "Academy Award Nominee", delay: 1.4 },
    { icon: Star, text: "Hollywood Walk of Fame", delay: 1.6 },
    { icon: Zap, text: "Iron Man Legacy", delay: 1.8 }
  ];

  const quotes = [
    "I am Iron Man.",
    "Sometimes you gotta run before you can walk.",
    "The point is that you gotta live with your choices.",
    "Genius, billionaire, playboy, philanthropist."
  ];

  return (
    <div className="min-h-screen bg-iron-gradient relative overflow-hidden flex items-center justify-center">
      {/* Background Grid */}
      <div className="absolute inset-0 tech-grid opacity-10"></div>
      
      {/* Floating Particles */}
      <div className="absolute inset-0">
        {[...Array(20)].map((_, i) => (
          <motion.div
            key={i}
            className="absolute w-1 h-1 bg-iron-gold rounded-full"
            style={{
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
            }}
            animate={{
              y: [-20, -40, -20],
              opacity: [0.3, 1, 0.3],
            }}
            transition={{
              duration: 3 + Math.random() * 2,
              repeat: Infinity,
              delay: Math.random() * 2,
            }}
          />
        ))}
      </div>

      {/* Corner Accents */}
      <div className="absolute top-0 left-0 w-32 h-32 border-l-4 border-t-4 border-iron-gold opacity-60"></div>
      <div className="absolute top-0 right-0 w-32 h-32 border-r-4 border-t-4 border-iron-gold opacity-60"></div>
      <div className="absolute bottom-0 left-0 w-32 h-32 border-l-4 border-b-4 border-iron-gold opacity-60"></div>
      <div className="absolute bottom-0 right-0 w-32 h-32 border-r-4 border-b-4 border-iron-gold opacity-60"></div>

      {/* Main Content */}
      <div className="relative z-10 max-w-6xl mx-auto px-8 text-center">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -50 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1, ease: "easeOut" }}
          className="mb-8"
        >
          <motion.h1 
            className="text-6xl md:text-8xl font-poppins font-black text-iron-white mb-4 heading-shadow"
            animate={{ 
              textShadow: [
                "2px 2px 6px rgba(139, 21, 56, 0.8)",
                "2px 2px 6px rgba(184, 134, 11, 0.8)",
                "2px 2px 6px rgba(139, 21, 56, 0.8)"
              ]
            }}
            transition={{ duration: 3, repeat: Infinity }}
          >
            MY IDOL
          </motion.h1>
          <motion.div
            initial={{ width: 0 }}
            animate={{ width: "100%" }}
            transition={{ duration: 1.5, delay: 0.5 }}
            className="h-1 bg-gradient-to-r from-iron-red via-iron-gold to-iron-red mx-auto max-w-md"
          />
        </motion.div>

        {/* Robert Downey Jr. Section */}
        <motion.div
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 1, delay: 0.3 }}
          className="mb-12"
        >
          {/* Arc Reactor Effect */}
          <div className="relative mb-8">
            <motion.div
              className="w-32 h-32 mx-auto bg-gradient-to-br from-iron-gold to-iron-bright-gold rounded-full flex items-center justify-center relative"
              animate={{ 
                boxShadow: [
                  "0 0 20px rgba(184, 134, 11, 0.5)",
                  "0 0 40px rgba(184, 134, 11, 0.8)",
                  "0 0 20px rgba(184, 134, 11, 0.5)"
                ]
              }}
              transition={{ duration: 2, repeat: Infinity }}
            >
              <Shield className="w-16 h-16 text-iron-black" />
              <motion.div
                className="absolute inset-0 border-4 border-iron-white rounded-full"
                animate={{ rotate: 360 }}
                transition={{ duration: 10, repeat: Infinity, ease: "linear" }}
              />
            </motion.div>
          </div>

          <motion.h2 
            className="text-4xl md:text-6xl font-poppins font-black text-iron-gold mb-4 heading-shadow"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.8 }}
          >
            ROBERT DOWNEY JR.
          </motion.h2>
          
          <motion.p 
            className="text-xl md:text-2xl text-iron-light-gray font-roboto max-w-3xl mx-auto leading-relaxed"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 1 }}
          >
            The man who brought Tony Stark to life and became the heart of the Marvel Cinematic Universe. 
            A journey of redemption, brilliance, and inspiration that changed Hollywood forever.
          </motion.p>
        </motion.div>

        {/* Achievements Grid */}
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1, delay: 1 }}
          className="grid grid-cols-2 md:grid-cols-4 gap-6 mb-12"
        >
          {achievements.map((achievement, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, scale: 0 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: achievement.delay, type: "spring", stiffness: 200 }}
              className="bg-iron-card p-6 rounded-lg border border-iron-dark-gray hover:border-iron-gold transition-all duration-300"
              whileHover={{ scale: 1.05, y: -5 }}
            >
              <achievement.icon className="w-8 h-8 text-iron-gold mx-auto mb-3" />
              <p className="text-iron-white text-sm font-medium">{achievement.text}</p>
            </motion.div>
          ))}
        </motion.div>

        {/* Iconic Quote */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 2 }}
          className="mb-12"
        >
          <motion.blockquote 
            className="text-2xl md:text-3xl font-poppins font-bold text-iron-gold italic mb-4"
            animate={{ 
              textShadow: [
                "2px 2px 4px rgba(0, 0, 0, 0.8)",
                "2px 2px 8px rgba(184, 134, 11, 0.6)",
                "2px 2px 4px rgba(0, 0, 0, 0.8)"
              ]
            }}
            transition={{ duration: 4, repeat: Infinity }}
          >
            "I am Iron Man."
          </motion.blockquote>
          <motion.p 
            className="text-iron-light-gray"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 2.2 }}
          >
            - The moment that changed everything
          </motion.p>
        </motion.div>

        {/* Student Information */}
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1, delay: 2.5 }}
          className="bg-iron-card p-8 rounded-lg border border-iron-dark-gray max-w-md mx-auto"
        >
          <motion.div
            className="flex items-center justify-center mb-4"
            whileHover={{ scale: 1.1 }}
          >
            <Heart className="w-6 h-6 text-iron-red mr-2" />
            <span className="text-iron-white font-semibold text-lg">Presented by</span>
          </motion.div>
          
          <motion.h3 
            className="text-2xl font-poppins font-bold text-iron-gold mb-2 heading-shadow"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 2.8 }}
          >
            PRUTHVIRAJ PAWAR
          </motion.h3>
          
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 3 }}
            className="space-y-1"
          >
            <p className="text-iron-light-gray font-medium">Class: 216-B</p>
            <motion.div
              className="h-px bg-gradient-to-r from-transparent via-iron-gold to-transparent"
              initial={{ width: 0 }}
              animate={{ width: "100%" }}
              transition={{ delay: 3.2, duration: 1 }}
            />
          </motion.div>
        </motion.div>

        {/* Floating Icons */}
        <div className="absolute top-1/4 left-10 hidden lg:block">
          <motion.div
            animate={{ 
              y: [-10, 10, -10],
              rotate: [0, 5, 0, -5, 0]
            }}
            transition={{ duration: 4, repeat: Infinity }}
          >
            <Film className="w-12 h-12 text-iron-gold opacity-30" />
          </motion.div>
        </div>

        <div className="absolute top-1/3 right-10 hidden lg:block">
          <motion.div
            animate={{ 
              y: [10, -10, 10],
              rotate: [0, -5, 0, 5, 0]
            }}
            transition={{ duration: 3, repeat: Infinity, delay: 1 }}
          >
            <Award className="w-10 h-10 text-iron-red opacity-30" />
          </motion.div>
        </div>

        <div className="absolute bottom-1/4 left-20 hidden lg:block">
          <motion.div
            animate={{ 
              y: [-5, 15, -5],
              x: [-5, 5, -5]
            }}
            transition={{ duration: 5, repeat: Infinity, delay: 2 }}
          >
            <Star className="w-8 h-8 text-iron-bright-gold opacity-40" />
          </motion.div>
        </div>
      </div>

      {/* Bottom Glow Effect */}
      <div className="absolute bottom-0 left-1/2 transform -translate-x-1/2 w-96 h-32 bg-gradient-to-t from-iron-gold to-transparent opacity-20 blur-3xl"></div>
    </div>
  );
}