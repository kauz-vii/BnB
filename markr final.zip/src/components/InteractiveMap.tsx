import React, { useState, useRef, useEffect, useCallback, useMemo } from 'react';
import { Button } from "./ui/button";
import { Badge } from "./ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "./ui/dialog";
import { Input } from "./ui/input";
import { Textarea } from "./ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./ui/select";
import { Label } from "./ui/label";
import { 
  Utensils, 
  Car, 
  Camera, 
  MapPin, 
  Star,
  Plus,
  Layers,
  StickyNote,
  ZoomIn,
  ZoomOut,
  Trash2,
  Upload,
  X
} from "lucide-react";
import type { User } from '@supabase/supabase-js';

interface MapMarker {
  id: string;
  title: string;
  latitude: number;
  longitude: number;
  category: 'Food' | 'Toilet' | 'Attraction' | 'Other';
  description?: string;
  photo?: string;
  creator: string;
  createdAt: string;
}

interface InteractiveMapProps {
  markers?: MapMarker[];
  center?: [number, number];
  zoom?: number;
  onMarkerAdd?: (latlng: { lat: number; lng: number }) => void;
  onMarkerClick?: (marker: MapMarker) => void;
  showAddButton?: boolean;
  user: User | null;
}

const categoryIcons = {
  Food: Utensils,
  Toilet: Car,
  Attraction: Camera,
  Other: StickyNote
};

const categoryColors = {
  Food: "#F59E0B",
  Toilet: "#3B82F6", 
  Attraction: "#10B981",
  Other: "#6B7280"
};

// Local storage utilities
const MARKERS_STORAGE_KEY = 'wanderxp_markers';

const getStoredMarkers = (): MapMarker[] => {
  try {
    const stored = sessionStorage.getItem(MARKERS_STORAGE_KEY);
    return stored ? JSON.parse(stored) : [];
  } catch {
    return [];
  }
};

const saveMarkersToStorage = (markers: MapMarker[]) => {
  try {
    sessionStorage.setItem(MARKERS_STORAGE_KEY, JSON.stringify(markers));
  } catch (error) {
    console.error('Failed to save markers:', error);
  }
};

// Performance-optimized tile map component with throttled rendering
function TileMap({ 
  center, 
  zoom, 
  onMapClick, 
  onMapLongPress,
  markers, 
  onMarkerClick, 
  onZoomChange 
}: {
  center: [number, number];
  zoom: number;
  onMapClick: (lat: number, lng: number) => void;
  onMapLongPress: (lat: number, lng: number) => void;
  markers: MapMarker[];
  onMarkerClick: (marker: MapMarker) => void;
  onZoomChange: (newZoom: number) => void;
}) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const animationFrameRef = useRef<number | null>(null);
  const lastDrawTimeRef = useRef<number>(0);
  const redrawThrottleMs = 16; // ~60fps throttling

  const [mapState, setMapState] = useState({
    center,
    zoom,
    dragging: false,
    lastMousePos: { x: 0, y: 0 },
    longPressTimer: null as NodeJS.Timeout | null,
    isLongPress: false,
    needsRedraw: true
  });

  // Limit markers for performance (max 200 as per spec)
  const visibleMarkers = useMemo(() => {
    return markers.slice(0, 200);
  }, [markers]);

  // Convert lat/lng to tile coordinates
  const latLngToTile = useCallback((lat: number, lng: number, z: number) => {
    const x = Math.floor((lng + 180) / 360 * Math.pow(2, z));
    const y = Math.floor((1 - Math.log(Math.tan(lat * Math.PI / 180) + 1 / Math.cos(lat * Math.PI / 180)) / Math.PI) / 2 * Math.pow(2, z));
    return { x, y };
  }, []);

  // Convert lat/lng to pixel coordinates
  const latLngToPixel = useCallback((lat: number, lng: number) => {
    const canvas = canvasRef.current;
    if (!canvas) return { x: 0, y: 0 };
    
    const centerTile = latLngToTile(mapState.center[0], mapState.center[1], mapState.zoom);
    const markerTile = latLngToTile(lat, lng, mapState.zoom);
    
    const x = canvas.width / 2 + (markerTile.x - centerTile.x) * 256;
    const y = canvas.height / 2 + (markerTile.y - centerTile.y) * 256;
    
    return { x, y };
  }, [mapState, latLngToTile]);

  // Convert pixel coordinates to lat/lng
  const pixelToLatLng = useCallback((x: number, y: number) => {
    const canvas = canvasRef.current;
    if (!canvas) return { lat: 0, lng: 0 };
    
    const centerTile = latLngToTile(mapState.center[0], mapState.center[1], mapState.zoom);
    const tileX = centerTile.x + (x - canvas.width / 2) / 256;
    const tileY = centerTile.y + (y - canvas.height / 2) / 256;
    
    const lng = tileX / Math.pow(2, mapState.zoom) * 360 - 180;
    const lat = Math.atan(Math.sinh(Math.PI * (1 - 2 * tileY / Math.pow(2, mapState.zoom)))) * 180 / Math.PI;
    
    return { lat, lng };
  }, [mapState, latLngToTile]);

  // Load and draw OSM tiles
  const drawTiles = useCallback(async () => {
    const canvas = canvasRef.current;
    const ctx = canvas?.getContext('2d');
    if (!canvas || !ctx) return;

    // Set canvas size to match container
    const container = containerRef.current;
    if (container) {
      canvas.width = container.clientWidth;
      canvas.height = container.clientHeight;
    }

    ctx.clearRect(0, 0, canvas.width, canvas.height);
    
    // Draw background
    ctx.fillStyle = '#f0f9ff';
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    const centerTile = latLngToTile(mapState.center[0], mapState.center[1], mapState.zoom);
    const tilesX = Math.ceil(canvas.width / 256) + 2;
    const tilesY = Math.ceil(canvas.height / 256) + 2;
    
    const startX = centerTile.x - Math.floor(tilesX / 2);
    const startY = centerTile.y - Math.floor(tilesY / 2);

    // Load and draw tiles
    const promises: Promise<void>[] = [];
    for (let x = 0; x < tilesX; x++) {
      for (let y = 0; y < tilesY; y++) {
        const tileX = startX + x;
        const tileY = startY + y;
        
        if (tileX < 0 || tileY < 0 || tileX >= Math.pow(2, mapState.zoom) || tileY >= Math.pow(2, mapState.zoom)) {
          continue;
        }

        const promise = new Promise<void>((resolve) => {
          const img = new Image();
          img.crossOrigin = 'anonymous';
          img.onload = () => {
            const pixelX = canvas.width / 2 + (tileX - centerTile.x) * 256;
            const pixelY = canvas.height / 2 + (tileY - centerTile.y) * 256;
            ctx.drawImage(img, pixelX, pixelY, 256, 256);
            resolve();
          };
          img.onerror = () => resolve();
          img.src = `https://tile.openstreetmap.org/${mapState.zoom}/${tileX}/${tileY}.png`;
        });
        promises.push(promise);
      }
    }

    await Promise.all(promises);
  }, [mapState, latLngToTile]);

  // Optimized batch marker rendering with vector pins
  const drawMarkers = useCallback(() => {
    const canvas = canvasRef.current;
    const ctx = canvas?.getContext('2d');
    if (!canvas || !ctx) return;

    // Batch render markers for better performance
    ctx.save();
    
    visibleMarkers.forEach(marker => {
      const pos = latLngToPixel(marker.latitude, marker.longitude);
      const color = categoryColors[marker.category];
      
      // Skip markers outside visible area for performance
      if (pos.x < -20 || pos.x > canvas.width + 20 || pos.y < -20 || pos.y > canvas.height + 20) {
        return;
      }
      
      // Draw lightweight vector pin (smaller size as per spec)
      ctx.beginPath();
      
      // Subtle shadow (reduced from previous version)
      ctx.beginPath();
      ctx.arc(pos.x + 1, pos.y + 1, 8, 0, 2 * Math.PI);
      ctx.fillStyle = 'rgba(0, 0, 0, 0.1)';
      ctx.fill();
      
      // Main dot pin
      ctx.beginPath();
      ctx.arc(pos.x, pos.y, 8, 0, 2 * Math.PI);
      ctx.fillStyle = color;
      ctx.fill();
      ctx.strokeStyle = '#ffffff';
      ctx.lineWidth = 2;
      ctx.stroke();
      
      // Small category indicator (dot instead of emoji for performance)
      ctx.beginPath();
      ctx.arc(pos.x, pos.y, 3, 0, 2 * Math.PI);
      ctx.fillStyle = '#ffffff';
      ctx.fill();
    });
    
    ctx.restore();
  }, [visibleMarkers, latLngToPixel]);

  // Throttled redraw function for smooth performance
  const throttledRedraw = useCallback(() => {
    const now = Date.now();
    if (now - lastDrawTimeRef.current < redrawThrottleMs) {
      if (animationFrameRef.current) {
        cancelAnimationFrame(animationFrameRef.current);
      }
      animationFrameRef.current = requestAnimationFrame(() => {
        drawTiles();
        drawMarkers();
        lastDrawTimeRef.current = Date.now();
      });
      return;
    }
    
    lastDrawTimeRef.current = now;
    drawTiles();
    drawMarkers();
  }, [drawTiles, drawMarkers]);

  // Cooperative gesture handling (less aggressive than greedy)
  const handleMouseDown = useCallback((e: React.MouseEvent<HTMLCanvasElement>) => {
    // Require Ctrl/Cmd key for some interactions (cooperative mode)
    if (!e.ctrlKey && !e.metaKey && e.detail === 1) {
      // Single click without modifier - check for marker click first
      const canvas = canvasRef.current;
      if (!canvas) return;

      const rect = canvas.getBoundingClientRect();
      const x = e.clientX - rect.left;
      const y = e.clientY - rect.top;

      // Check marker click first
      const clickedMarker = visibleMarkers.find(marker => {
        const pos = latLngToPixel(marker.latitude, marker.longitude);
        const distance = Math.sqrt(Math.pow(x - pos.x, 2) + Math.pow(y - pos.y, 2));
        return distance <= 8;
      });

      if (clickedMarker) {
        onMarkerClick(clickedMarker);
        return;
      }
    }

    const canvas = canvasRef.current;
    if (!canvas) return;

    const rect = canvas.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;

    setMapState(prev => ({
      ...prev,
      dragging: true,
      lastMousePos: { x: e.clientX, y: e.clientY },
      isLongPress: false
    }));

    // Start long press timer (slightly longer for cooperative mode)
    const timer = setTimeout(() => {
      setMapState(prev => ({ ...prev, isLongPress: true }));
      const { lat, lng } = pixelToLatLng(x, y);
      onMapLongPress(lat, lng);
    }, 1000);

    setMapState(prev => ({ ...prev, longPressTimer: timer }));
  }, [pixelToLatLng, onMapLongPress, visibleMarkers, latLngToPixel, onMarkerClick]);

  const handleMouseMove = useCallback((e: React.MouseEvent<HTMLCanvasElement>) => {
    if (!mapState.dragging) return;

    const deltaX = e.clientX - mapState.lastMousePos.x;
    const deltaY = e.clientY - mapState.lastMousePos.y;

    // Clear long press timer if moving
    if (mapState.longPressTimer) {
      clearTimeout(mapState.longPressTimer);
      setMapState(prev => ({ ...prev, longPressTimer: null }));
    }

    // Smooth pan with momentum damping
    const smoothingFactor = 0.8;
    const newCenter = [...mapState.center] as [number, number];
    const scale = 360 / Math.pow(2, mapState.zoom) / 256;
    newCenter[1] -= (deltaX * scale * smoothingFactor);
    newCenter[0] += (deltaY * scale * smoothingFactor);

    setMapState(prev => ({
      ...prev,
      center: newCenter,
      lastMousePos: { x: e.clientX, y: e.clientY },
      needsRedraw: true
    }));
  }, [mapState]);

  const handleMouseUp = useCallback((e: React.MouseEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    // Clear long press timer
    if (mapState.longPressTimer) {
      clearTimeout(mapState.longPressTimer);
    }

    if (!mapState.isLongPress && !mapState.dragging) {
      const rect = canvas.getBoundingClientRect();
      const x = e.clientX - rect.left;
      const y = e.clientY - rect.top;

      // Check if clicking on a marker (using smaller hit area for dot pins)
      const clickedMarker = visibleMarkers.find(marker => {
        const pos = latLngToPixel(marker.latitude, marker.longitude);
        const distance = Math.sqrt(Math.pow(x - pos.x, 2) + Math.pow(y - pos.y, 2));
        return distance <= 8; // Smaller hit area for lightweight markers
      });

      if (clickedMarker) {
        onMarkerClick(clickedMarker);
      } else {
        const { lat, lng } = pixelToLatLng(x, y);
        onMapClick(lat, lng);
      }
    }

    setMapState(prev => ({
      ...prev,
      dragging: false,
      longPressTimer: null,
      isLongPress: false
    }));
  }, [mapState, visibleMarkers, latLngToPixel, pixelToLatLng, onMapClick, onMarkerClick]);

  // Smooth scroll zoom with cooperative gesture handling
  const handleWheel = useCallback((e: React.WheelEvent<HTMLCanvasElement>) => {
    e.preventDefault();
    
    // Smooth zoom increments for better UX
    const zoomSensitivity = 0.1;
    const delta = e.deltaY > 0 ? -zoomSensitivity : zoomSensitivity;
    const newZoom = Math.max(1, Math.min(18, mapState.zoom + delta));
    
    setMapState(prev => ({ ...prev, zoom: newZoom, needsRedraw: true }));
    onZoomChange(newZoom);
  }, [mapState.zoom, onZoomChange]);

  // Handle double-click zoom
  const handleDoubleClick = useCallback((e: React.MouseEvent<HTMLCanvasElement>) => {
    e.preventDefault();
    const newZoom = Math.min(18, mapState.zoom + 2);
    setMapState(prev => ({ ...prev, zoom: newZoom }));
    onZoomChange(newZoom);
  }, [mapState.zoom, onZoomChange]);

  // Optimized rendering with throttling
  useEffect(() => {
    if (mapState.needsRedraw) {
      throttledRedraw();
      setMapState(prev => ({ ...prev, needsRedraw: false }));
    }
  }, [mapState.needsRedraw, throttledRedraw]);

  useEffect(() => {
    setMapState(prev => ({ ...prev, needsRedraw: true }));
  }, [mapState.center, mapState.zoom]);

  useEffect(() => {
    // Debounced marker redraw to avoid excessive renders
    const timer = setTimeout(() => {
      if (canvasRef.current) {
        drawMarkers();
      }
    }, 50);
    return () => clearTimeout(timer);
  }, [visibleMarkers, drawMarkers]);

  // Cleanup timer on unmount
  useEffect(() => {
    return () => {
      if (mapState.longPressTimer) {
        clearTimeout(mapState.longPressTimer);
      }
    };
  }, [mapState.longPressTimer]);

  return (
    <div ref={containerRef} className="relative w-full h-full">
      <canvas
        ref={canvasRef}
        className="w-full h-full cursor-move rounded-xl select-none"
        style={{ 
          minHeight: '500px', 
          touchAction: 'pan-x pan-y', // Cooperative gesture handling
          willChange: 'transform' // Performance optimization
        }}
        onMouseDown={handleMouseDown}
        onMouseMove={handleMouseMove}
        onMouseUp={handleMouseUp}
        onWheel={handleWheel}
        onDoubleClick={handleDoubleClick}
      />
      
      {/* Attribution - Required by OpenStreetMap */}
      <div className="absolute bottom-2 right-2 z-10 glassmorphism rounded px-2 py-1 text-xs text-gray-600 dark:text-gray-400 shadow-sm">
        © <a href="https://www.openstreetmap.org/copyright" target="_blank" rel="noopener noreferrer" className="underline">OpenStreetMap</a> contributors
      </div>
    </div>
  );
}

export function InteractiveMap({ 
  markers = [], 
  center = [40.7128, -74.0060], 
  zoom = 13, 
  onMarkerAdd,
  onMarkerClick,
  showAddButton = true,
  user
}: InteractiveMapProps) {
  const [showLayers, setShowLayers] = useState(false);
  const [selectedLayers, setSelectedLayers] = useState(['Food', 'Attraction', 'Other']);
  const [addingMarker, setAddingMarker] = useState(false);
  const [selectedMarker, setSelectedMarker] = useState<MapMarker | null>(null);
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
  const [pendingLocation, setPendingLocation] = useState<{lat: number, lng: number} | null>(null);
  const [localMarkers, setLocalMarkers] = useState<MapMarker[]>(() => getStoredMarkers());
  const [mapZoom, setMapZoom] = useState(zoom);

  // Form state for marker creation
  const [markerForm, setMarkerForm] = useState({
    title: '',
    description: '',
    category: 'Other' as 'Food' | 'Toilet' | 'Attraction' | 'Other',
    photo: null as File | null
  });

  // Mock data for demonstration
  const mockMarkers: MapMarker[] = [
    {
      id: 'demo-1',
      title: "Joe's Coffee Shop",
      latitude: 40.7589,
      longitude: -73.9851,
      category: 'Food',
      description: 'Amazing espresso and cozy atmosphere. Great for remote work!',
      creator: 'Demo User',
      createdAt: '2024-01-20T10:30:00Z'
    },
    {
      id: 'demo-2',
      title: 'Central Park Entrance',
      latitude: 40.7829,
      longitude: -73.9654,
      category: 'Attraction',
      description: 'Beautiful park entrance with stunning architecture',
      creator: 'Demo User',
      createdAt: '2024-01-19T15:45:00Z'
    }
  ];

  // Optimized marker filtering and limiting
  const allMarkers = useMemo(() => 
    [...markers, ...mockMarkers, ...localMarkers], 
    [markers, mockMarkers, localMarkers]
  );
  
  const filteredMarkers = useMemo(() => 
    allMarkers
      .filter(marker => selectedLayers.includes(marker.category))
      .slice(0, 200), // Performance limit as per spec
    [allMarkers, selectedLayers]
  );

  const toggleLayer = (category: string) => {
    setSelectedLayers(prev => 
      prev.includes(category) 
        ? prev.filter(c => c !== category)
        : [...prev, category]
    );
  };

  const handleMapClick = (lat: number, lng: number) => {
    if (addingMarker && user) {
      setPendingLocation({ lat, lng });
      setShowCreateModal(true);
      setAddingMarker(false);
    }
  };

  const handleMapLongPress = (lat: number, lng: number) => {
    if (user) {
      setPendingLocation({ lat, lng });
      setShowCreateModal(true);
    }
  };

  const handleMarkerClick = (marker: MapMarker) => {
    setSelectedMarker(marker);
    if (onMarkerClick) {
      onMarkerClick(marker);
    }
  };

  const handleZoom = (delta: number) => {
    const newZoom = Math.max(1, Math.min(18, mapZoom + delta));
    setMapZoom(newZoom);
  };

  const handleCreateMarker = () => {
    if (!pendingLocation || !user || !markerForm.title.trim()) return;

    const newMarker: MapMarker = {
      id: `marker-${Date.now()}`,
      title: markerForm.title.trim(),
      latitude: pendingLocation.lat,
      longitude: pendingLocation.lng,
      category: markerForm.category,
      description: markerForm.description.trim() || undefined,
      creator: user.email || 'Anonymous',
      createdAt: new Date().toISOString()
    };

    const updatedMarkers = [...localMarkers, newMarker];
    setLocalMarkers(updatedMarkers);
    saveMarkersToStorage(updatedMarkers);

    // Reset form
    setMarkerForm({
      title: '',
      description: '',
      category: 'Other',
      photo: null
    });
    setPendingLocation(null);
    setShowCreateModal(false);

    if (onMarkerAdd) {
      onMarkerAdd(pendingLocation);
    }
  };

  const handleDeleteMarker = () => {
    if (!selectedMarker) return;

    const updatedMarkers = localMarkers.filter(m => m.id !== selectedMarker.id);
    setLocalMarkers(updatedMarkers);
    saveMarkersToStorage(updatedMarkers);
    
    setSelectedMarker(null);
    setShowDeleteConfirm(false);
  };

  const canDeleteMarker = selectedMarker && localMarkers.some(m => m.id === selectedMarker.id);

  return (
    <div className="relative w-full h-full">
      <TileMap
        center={center}
        zoom={mapZoom}
        onMapClick={handleMapClick}
        onMapLongPress={handleMapLongPress}
        markers={filteredMarkers}
        onMarkerClick={handleMarkerClick}
        onZoomChange={setMapZoom}
      />

      {/* Instructions overlay */}
      <div className="absolute top-4 left-1/2 transform -translate-x-1/2 z-[1000] glassmorphism rounded-xl p-3 border border-white/20 dark:border-gray-700/20 pointer-events-none shadow-sm">
        <h3 className="font-bold text-slate-800 dark:text-slate-200 mb-1 text-sm">Optimized OpenStreetMap</h3>
        <p className="text-xs text-slate-600 dark:text-slate-300">
          {user ? 
            'Smooth scroll zoom • Drag to pan • Ctrl+click for interactions • Long-press to add markers' : 
            'Smooth scroll zoom • Drag to pan • Cooperative gestures • Sign in to add markers'
          }
        </p>
      </div>

      {/* Zoom controls */}
      <div className="absolute top-4 left-4 z-[1000] space-y-2">
        <Button
          onClick={() => handleZoom(1)}
          className="glassmorphism hover:bg-white/20 dark:hover:bg-gray-800/20 border border-white/20 dark:border-gray-700/20 text-gray-700 dark:text-gray-300 shadow-lg"
          size="sm"
        >
          <ZoomIn className="w-4 h-4" />
        </Button>
        <Button
          onClick={() => handleZoom(-1)}
          className="glassmorphism hover:bg-white/20 dark:hover:bg-gray-800/20 border border-white/20 dark:border-gray-700/20 text-gray-700 dark:text-gray-300 shadow-lg"
          size="sm"
        >
          <ZoomOut className="w-4 h-4" />
        </Button>
        <div className="glassmorphism rounded-lg px-2 py-1 text-xs text-gray-600 dark:text-gray-400">
          Zoom: {mapZoom}
        </div>
      </div>

      {/* Floating Controls */}
      <div className="absolute top-4 right-4 z-[1000] space-y-2">
        {/* Layer Toggle */}
        <div className="relative">
          <Button
            onClick={() => setShowLayers(!showLayers)}
            className="glassmorphism hover:bg-white/20 dark:hover:bg-gray-800/20 border border-white/20 dark:border-gray-700/20 text-gray-700 dark:text-gray-300 shadow-lg"
            size="sm"
          >
            <Layers className="w-4 h-4" />
          </Button>
          
          {showLayers && (
            <div className="absolute top-12 right-0 glassmorphism border border-white/20 dark:border-gray-700/20 rounded-xl shadow-2xl p-4 min-w-[200px]">
              <h4 className="font-bold text-gray-900 dark:text-gray-100 mb-3">Map Layers</h4>
              <div className="space-y-2">
                {Object.entries(categoryIcons).map(([category, Icon]) => (
                  <label key={category} className="flex items-center gap-2 cursor-pointer hover:bg-white/10 dark:hover:bg-gray-800/10 p-2 rounded-lg transition-colors">
                    <input
                      type="checkbox"
                      checked={selectedLayers.includes(category)}
                      onChange={() => toggleLayer(category)}
                      className="rounded border-gray-300 dark:border-gray-600 text-blue-600 focus:ring-blue-500"
                    />
                    <div 
                      className="w-4 h-4 rounded-full border-2 border-white"
                      style={{ backgroundColor: categoryColors[category as keyof typeof categoryColors] }}
                    />
                    <Icon className="w-4 h-4 text-gray-600 dark:text-gray-400" />
                    <span className="text-sm text-gray-700 dark:text-gray-300">{category}</span>
                  </label>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Add Marker Button */}
        {showAddButton && user && (
          <Button
            onClick={() => setAddingMarker(!addingMarker)}
            className={`shadow-lg transition-all duration-200 ${
              addingMarker 
                ? "bg-emerald-500 hover:bg-emerald-600 text-white shadow-emerald-500/25" 
                : "bg-gradient-to-r from-blue-600 to-emerald-500 hover:from-blue-700 hover:to-emerald-600 text-white shadow-blue-500/25"
            }`}
            size="sm"
            title="Add Marker"
          >
            <Plus className="w-4 h-4 mr-2" />
            {addingMarker ? "Click map" : "Add Marker"}
          </Button>
        )}

        {/* Guest prompt for add marker */}
        {showAddButton && !user && (
          <div className="glassmorphism border border-white/20 dark:border-gray-700/20 rounded-xl p-3 text-center">
            <p className="text-xs text-gray-600 dark:text-gray-400 mb-2">Sign in to add markers</p>
            <Button size="sm" variant="outline" className="text-xs">
              Sign In
            </Button>
          </div>
        )}
      </div>

      {/* Instructions for adding marker */}
      {addingMarker && user && (
        <div className="absolute bottom-4 left-1/2 transform -translate-x-1/2 z-[1000]">
          <div className="bg-emerald-500 text-white px-4 py-2 rounded-lg shadow-lg shadow-emerald-500/25 animate-pulse">
            <p className="text-sm font-medium">Click on the map or long-press to place a marker</p>
          </div>
        </div>
      )}

      {/* Optimized Map Statistics */}
      <div className="absolute bottom-4 left-4 z-[1000]">
        <div className="glassmorphism border border-white/20 dark:border-gray-700/20 rounded-xl p-3 shadow-sm">
          <div className="flex items-center space-x-3 text-xs font-medium">
            <span className="text-blue-600 dark:text-blue-400">
              {filteredMarkers.length}/{allMarkers.length} visible
            </span>
            <span className="text-slate-400">•</span>
            <span className="text-emerald-600 dark:text-emerald-400">
              {localMarkers.length} yours
            </span>
            {filteredMarkers.length >= 200 && (
              <>
                <span className="text-slate-400">•</span>
                <span className="text-orange-500 text-xs">
                  Limited for performance
                </span>
              </>
            )}
          </div>
        </div>
      </div>

      {/* Marker Detail Popup */}
      {selectedMarker && (
        <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 z-[1000]">
          <div className="glassmorphism rounded-xl shadow-2xl p-6 min-w-[300px] max-w-[400px] border border-white/20 dark:border-gray-700/20">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <div 
                  className="w-8 h-8 rounded-full flex items-center justify-center text-white"
                  style={{ backgroundColor: categoryColors[selectedMarker.category] }}
                >
                  {React.createElement(categoryIcons[selectedMarker.category], {
                    className: "w-4 h-4"
                  })}
                </div>
                <h4 className="font-bold text-slate-800 dark:text-slate-200">{selectedMarker.title}</h4>
              </div>
              <div className="flex gap-1">
                {canDeleteMarker && (
                  <Button
                    onClick={() => setShowDeleteConfirm(true)}
                    variant="ghost"
                    size="sm"
                    className="h-6 w-6 p-0 text-red-500 hover:text-red-600"
                    title="Delete marker"
                  >
                    <Trash2 className="w-3 h-3" />
                  </Button>
                )}
                <Button
                  onClick={() => setSelectedMarker(null)}
                  variant="ghost"
                  size="sm"
                  className="h-6 w-6 p-0"
                >
                  <X className="w-3 h-3" />
                </Button>
              </div>
            </div>
            
            <Badge 
              className="mb-3 text-white"
              style={{ backgroundColor: categoryColors[selectedMarker.category] }}
            >
              {selectedMarker.category}
            </Badge>
            
            {selectedMarker.description && (
              <p className="text-sm text-slate-600 dark:text-slate-300 mb-3">{selectedMarker.description}</p>
            )}

            <div className="flex items-center justify-between text-xs text-gray-500 dark:text-gray-400 pt-2 border-t border-gray-200 dark:border-gray-600">
              <span>Added by {selectedMarker.creator}</span>
              <span>{new Date(selectedMarker.createdAt).toLocaleDateString()}</span>
            </div>
          </div>
        </div>
      )}

      {/* Create Marker Modal */}
      <Dialog open={showCreateModal} onOpenChange={setShowCreateModal}>
        <DialogContent className="sm:max-w-[425px]">
          <DialogHeader>
            <DialogTitle>Add New Marker</DialogTitle>
            <DialogDescription>
              Create a new marker at the selected location. Fill in the details below to help others discover this place.
            </DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="grid gap-2">
              <Label htmlFor="title">Title</Label>
              <Input
                id="title"
                value={markerForm.title}
                onChange={(e) => setMarkerForm(prev => ({ ...prev, title: e.target.value }))}
                placeholder="Enter marker title"
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="description">Description</Label>
              <Textarea
                id="description"
                value={markerForm.description}
                onChange={(e) => setMarkerForm(prev => ({ ...prev, description: e.target.value }))}
                placeholder="Enter description (optional)"
                rows={3}
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="category">Category</Label>
              <Select value={markerForm.category} onValueChange={(value: any) => setMarkerForm(prev => ({ ...prev, category: value }))}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Food">Food</SelectItem>
                  <SelectItem value="Toilet">Toilet</SelectItem>
                  <SelectItem value="Attraction">Attraction</SelectItem>
                  <SelectItem value="Other">Other</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="grid gap-2">
              <Label htmlFor="photo">Upload Photo (optional)</Label>
              <div className="flex items-center gap-2">
                <Button variant="outline" size="sm" className="text-xs">
                  <Upload className="w-3 h-3 mr-1" />
                  Choose File
                </Button>
                <span className="text-xs text-gray-500">Coming soon</span>
              </div>
            </div>
          </div>
          <div className="flex justify-end gap-2">
            <Button variant="outline" onClick={() => setShowCreateModal(false)}>
              Cancel
            </Button>
            <Button 
              onClick={handleCreateMarker}
              disabled={!markerForm.title.trim()}
              className="bg-gradient-to-r from-blue-600 to-emerald-500 hover:from-blue-700 hover:to-emerald-600"
            >
              Create Marker
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation Dialog */}
      <Dialog open={showDeleteConfirm} onOpenChange={setShowDeleteConfirm}>
        <DialogContent className="sm:max-w-[400px]">
          <DialogHeader>
            <DialogTitle>Delete Marker</DialogTitle>
            <DialogDescription>
              Are you sure you want to delete this marker? This action cannot be undone.
            </DialogDescription>
          </DialogHeader>
          <div className="flex justify-end gap-2 mt-4">
            <Button variant="outline" onClick={() => setShowDeleteConfirm(false)}>
              Cancel
            </Button>
            <Button 
              variant="destructive"
              onClick={handleDeleteMarker}
            >
              Delete
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}