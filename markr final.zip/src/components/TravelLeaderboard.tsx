import { Trophy, Medal, Crown, Globe, Users, MapPin, Loader2, RefreshCw } from 'lucide-react';
import { Card } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { useState } from 'react';
import { useLeaderboard } from '../hooks/useLeaderboard';
import { useAuth } from '../hooks/useAuth';

export function Leaderboard() {
  const [activeFilter, setActiveFilter] = useState<'global' | 'city' | 'friends'>('global');
  const { leaderboard, loading, error, refresh } = useLeaderboard();
  const { user, profile } = useAuth();

  const getRankIcon = (rank: number) => {
    switch (rank) {
      case 1: return <Crown className="w-5 h-5 text-yellow-500" />;
      case 2: return <Medal className="w-5 h-5 text-gray-400" />;
      case 3: return <Medal className="w-5 h-5 text-orange-600" />;
      default: return <span className="w-5 h-5 flex items-center justify-center text-slate-600 font-medium">{rank}</span>;
    }
  };

  const getRankBackground = (rank: number) => {
    switch (rank) {
      case 1: return 'bg-gradient-to-r from-yellow-50 to-yellow-100 border-yellow-200';
      case 2: return 'bg-gradient-to-r from-gray-50 to-gray-100 border-gray-200';
      case 3: return 'bg-gradient-to-r from-orange-50 to-orange-100 border-orange-200';
      default: return 'bg-white border-slate-200';
    }
  };

  const filters = [
    { id: 'global' as const, label: 'Global', icon: Globe },
    { id: 'city' as const, label: 'City', icon: MapPin },
    { id: 'friends' as const, label: 'Friends', icon: Users },
  ];

  return (
    <div className="p-8 max-w-5xl mx-auto space-y-8 animate-fade-in">
      {/* Header */}
      <Card className="p-8 bg-gradient-to-r from-blue-50/80 to-emerald-50/80 backdrop-blur-xl border-0 shadow-2xl border border-white/20">
        <div className="flex items-center space-x-4 mb-6">
          <div className="p-3 bg-gradient-to-br from-yellow-400 to-yellow-600 rounded-2xl shadow-xl">
            <Trophy className="w-10 h-10 text-white" />
          </div>
          <h1 className="text-4xl font-black text-slate-800 bg-gradient-to-r from-blue-600 to-emerald-500 bg-clip-text text-transparent">
            Top Explorers
          </h1>
        </div>
        <p className="text-slate-600 font-medium text-lg">Compete with fellow travelers and climb the leaderboard!</p>
      </Card>

      {/* Filters */}
      <Card className="p-6 border-0 shadow-xl bg-white/80 backdrop-blur-xl">
        <div className="flex items-center justify-between">
          <div className="flex space-x-3">
            {filters.map((filter) => (
              <Button
                key={filter.id}
                variant={activeFilter === filter.id ? "default" : "outline"}
                onClick={() => setActiveFilter(filter.id)}
                className={`flex items-center space-x-3 px-6 py-3 rounded-xl font-semibold transition-all duration-200 hover-lift ${
                  activeFilter === filter.id 
                    ? 'bg-gradient-to-r from-blue-600 to-emerald-500 hover:from-blue-700 hover:to-emerald-600 shadow-lg' 
                    : 'hover:bg-blue-50'
                }`}
              >
                <filter.icon className="w-5 h-5" />
                <span>{filter.label}</span>
              </Button>
            ))}
          </div>
          <Badge variant="secondary" className="bg-gradient-to-r from-blue-50 to-emerald-50 text-slate-600 px-4 py-2 rounded-xl font-semibold">
            Updated 5 minutes ago
          </Badge>
        </div>
      </Card>

      {/* Leaderboard */}
      <Card className="border-0 shadow-xl overflow-hidden">
        <div className="p-6 bg-gradient-to-r from-slate-50 to-slate-100 border-b">
          <div className="flex items-center justify-between">
            <h2 className="text-xl font-bold text-slate-800">Leaderboard Rankings</h2>
            <Button
              variant="outline"
              size="sm"
              onClick={refresh}
              disabled={loading}
              className="flex items-center space-x-2"
            >
              <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
              <span>Refresh</span>
            </Button>
          </div>
        </div>
        
        {loading ? (
          <div className="p-8 flex items-center justify-center">
            <Loader2 className="w-8 h-8 animate-spin text-blue-600" />
          </div>
        ) : error ? (
          <div className="p-8 text-center">
            <p className="text-red-600 mb-4">Error loading leaderboard: {error}</p>
            <Button onClick={refresh} variant="outline">
              Try Again
            </Button>
          </div>
        ) : (
          <div className="divide-y divide-slate-100">
            {leaderboard.map((user, index) => (
              <div 
                key={user.id}
                className={`p-4 hover:bg-slate-50 transition-all duration-200 hover:scale-[1.01] ${getRankBackground(user.rank)} ${
                  user.rank <= 3 ? 'border-l-4' : ''
                }`}
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-4">
                    <div className="flex items-center justify-center w-10">
                      {getRankIcon(user.rank)}
                    </div>
                    
                    <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-emerald-500 rounded-full flex items-center justify-center shadow-md">
                      <span className="text-white font-bold">{user.username.charAt(0).toUpperCase()}</span>
                    </div>
                    
                    <div>
                      <div className="flex items-center space-x-2">
                        <h3 className="font-medium text-slate-800">{user.username}</h3>
                        <Badge variant="outline" className="text-xs">
                          Level {user.level}
                        </Badge>
                      </div>
                      <p className="text-sm text-slate-500">{user.placesExplored} places explored</p>
                    </div>
                  </div>
                  
                  <div className="text-right">
                    <p className="text-lg font-bold text-slate-800">{user.xp.toLocaleString()}</p>
                    <p className="text-sm text-slate-500">XP</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </Card>

      {/* Your Ranking */}
      {user && profile && (
        <Card className="p-4 bg-gradient-to-r from-blue-50 to-emerald-50 border-2 border-blue-200 shadow-xl">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <div className="w-10 h-10 bg-gradient-to-br from-blue-600 to-emerald-500 rounded-full flex items-center justify-center shadow-md">
                <span className="text-white font-bold">{profile.name.charAt(0).toUpperCase()}</span>
              </div>
              <div>
                <h3 className="font-medium text-slate-800">{profile.name} (You)</h3>
                <p className="text-sm text-slate-600">Your current ranking</p>
              </div>
            </div>
            <div className="text-right">
              <div className="flex items-center space-x-2">
                <span className="text-2xl font-bold text-slate-800">
                  #{leaderboard.findIndex(u => u.id === user.id) + 1 || 'Unranked'}
                </span>
                <Badge className="bg-gradient-to-r from-blue-600 to-emerald-500 text-white">
                  Level {profile.level}
                </Badge>
              </div>
              <p className="text-sm text-slate-500">{profile.xp.toLocaleString()} XP</p>
            </div>
          </div>
        </Card>
      )}
    </div>
  );
}