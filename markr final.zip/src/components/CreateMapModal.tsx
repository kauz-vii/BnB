import { useState } from 'react';
import { X, MapPin, Globe, Lock, Loader2 } from 'lucide-react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from './ui/dialog';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Textarea } from './ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Label } from './ui/label';
import { apiCall } from '../utils/supabase/client';
import { useAuth } from '../hooks/useAuth';

interface CreateMapModalProps {
  isOpen: boolean;
  onOpenChange: (open: boolean) => void;
}

export function CreateMapModal({ isOpen, onOpenChange }: CreateMapModalProps) {
  const [formData, setFormData] = useState({
    title: '',
    description: '',
    visibility: 'public'
  });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const { refreshProfile } = useAuth();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError(null);

    try {
      await apiCall('/maps', {
        method: 'POST',
        body: JSON.stringify(formData),
      });

      // Refresh user profile to update stats
      await refreshProfile();
      
      onOpenChange(false);
      // Reset form
      setFormData({ title: '', description: '', visibility: 'public' });
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  return (
    <Dialog open={isOpen} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-lg bg-white/90 backdrop-blur-xl border border-white/20 shadow-2xl">
        <DialogHeader>
          <DialogTitle className="flex items-center space-x-3 text-xl">
            <div className="p-2 bg-gradient-to-br from-blue-500 to-emerald-500 rounded-xl">
              <MapPin className="w-6 h-6 text-white" />
            </div>
            <span className="bg-gradient-to-r from-blue-600 to-emerald-500 bg-clip-text text-transparent font-bold">
              Create New Map
            </span>
          </DialogTitle>
          <DialogDescription className="text-slate-600 font-medium">
            Create a new map to share with the community. Add markers and locations to help other travelers discover amazing places.
          </DialogDescription>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="space-y-3">
            <Label htmlFor="title" className="font-semibold text-slate-700">Map Title</Label>
            <Input
              id="title"
              placeholder="Enter your map title..."
              value={formData.title}
              onChange={(e) => handleInputChange('title', e.target.value)}
              required
              className="bg-white/70 backdrop-blur-sm border-white/30 focus:border-blue-400 focus:ring-2 focus:ring-blue-200 rounded-xl py-3 px-4 transition-all duration-200"
            />
          </div>

          <div className="space-y-3">
            <Label htmlFor="description" className="font-semibold text-slate-700">Description</Label>
            <Textarea
              id="description"
              placeholder="Describe your map and what makes it special..."
              value={formData.description}
              onChange={(e) => handleInputChange('description', e.target.value)}
              rows={4}
              className="bg-white/70 backdrop-blur-sm border-white/30 focus:border-blue-400 focus:ring-2 focus:ring-blue-200 rounded-xl resize-none"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="visibility">Visibility</Label>
            <Select 
              value={formData.visibility} 
              onValueChange={(value) => handleInputChange('visibility', value)}
            >
              <SelectTrigger className="focus:border-blue-500 focus:ring-1 focus:ring-blue-500">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="public">
                  <div className="flex items-center space-x-2">
                    <Globe className="w-4 h-4 text-emerald-600" />
                    <span>Public - Anyone can view</span>
                  </div>
                </SelectItem>
                <SelectItem value="private">
                  <div className="flex items-center space-x-2">
                    <Lock className="w-4 h-4 text-slate-600" />
                    <span>Private - Only you can view</span>
                  </div>
                </SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="bg-blue-50 p-4 rounded-lg border border-blue-200">
            <div className="flex items-start space-x-3">
              <MapPin className="w-5 h-5 text-blue-600 mt-0.5 flex-shrink-0" />
              <div>
                <h4 className="font-medium text-blue-800 mb-1">Pro Tip</h4>
                <p className="text-sm text-blue-700">
                  Create public maps to share with the community and earn XP! 
                  Other users can discover your maps and add their own markers.
                </p>
              </div>
            </div>
          </div>

          {error && (
            <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg text-sm">
              {error}
            </div>
          )}

          <div className="flex space-x-3 pt-4">
            <Button
              type="button"
              variant="outline"
              onClick={() => onOpenChange(false)}
              className="flex-1"
              disabled={loading}
            >
              Cancel
            </Button>
            <Button
              type="submit"
              className="flex-1 bg-gradient-to-r from-blue-600 to-emerald-500 hover:from-blue-700 hover:to-emerald-600"
              disabled={!formData.title.trim() || loading}
            >
              {loading && <Loader2 className="w-4 h-4 mr-2 animate-spin" />}
              Create Map
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}