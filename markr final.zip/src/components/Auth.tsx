import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Eye, EyeOff, Mail, Lock, User, ArrowRight } from 'lucide-react';
import { useAuth } from '../contexts/DataProvider';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Card } from './ui/card';
import { Label } from './ui/label';

export default function Auth() {
  const { login, register } = useAuth();
  const [isLogin, setIsLogin] = useState(true);
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [formData, setFormData] = useState({
    username: '',
    email: '',
    password: '',
    confirmPassword: ''
  });
  const [errors, setErrors] = useState<Record<string, string>>({});

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setErrors({});

    try {
      // Basic validation
      const newErrors: Record<string, string> = {};
      
      if (!formData.email) newErrors.email = 'Email is required';
      if (!formData.password) newErrors.password = 'Password is required';
      
      if (!isLogin) {
        if (!formData.username) newErrors.username = 'Username is required';
        if (formData.password !== formData.confirmPassword) {
          newErrors.confirmPassword = 'Passwords do not match';
        }
      }

      if (Object.keys(newErrors).length > 0) {
        setErrors(newErrors);
        setLoading(false);
        return;
      }

      if (isLogin) {
        await login(formData.email, formData.password);
      } else {
        await register(formData.username, formData.email, formData.password);
      }
    } catch (error) {
      setErrors({ submit: 'Authentication failed. Please try again.' });
    } finally {
      setLoading(false);
    }
  };

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
    if (errors[field]) {
      setErrors(prev => ({ ...prev, [field]: '' }));
    }
  };

  return (
    <div className="min-h-screen bg-iron-gradient flex items-center justify-center p-6">
      {/* Background Grid */}
      <div className="absolute inset-0 tech-grid opacity-20"></div>
      
      {/* Corner Elements */}
      <div className="absolute top-0 left-0 w-16 h-16 border-l-2 border-t-2 border-iron-gold opacity-60"></div>
      <div className="absolute top-0 right-0 w-16 h-16 border-r-2 border-t-2 border-iron-gold opacity-60"></div>
      <div className="absolute bottom-0 left-0 w-16 h-16 border-l-2 border-b-2 border-iron-gold opacity-60"></div>
      <div className="absolute bottom-0 right-0 w-16 h-16 border-r-2 border-b-2 border-iron-gold opacity-60"></div>

      <motion.div
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.5 }}
        className="w-full max-w-md relative z-10"
      >
        {/* Logo */}
        <div className="text-center mb-8">
          <motion.div
            initial={{ y: -20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: 0.2 }}
            className="flex items-center justify-center space-x-2 mb-4"
          >
            <div className="w-12 h-12 bg-gradient-to-br from-iron-red to-iron-gold rounded-lg flex items-center justify-center">
              <div className="w-6 h-6 bg-iron-white rounded-full"></div>
            </div>
            <span className="text-3xl font-poppins font-black text-iron-white">
              TechQ&A
            </span>
          </motion.div>
          <p className="text-iron-gray">
            Join the community of developers sharing knowledge
          </p>
        </div>

        <Card className="p-8 bg-iron-card border-iron-dark-gray">
          {/* Tab Switcher */}
          <div className="flex mb-6 bg-iron-black/30 rounded-lg p-1">
            <button
              className={`flex-1 py-2 px-4 rounded-md text-sm font-semibold transition-all ${
                isLogin
                  ? 'bg-iron-gold text-iron-black'
                  : 'text-iron-gray hover:text-iron-white'
              }`}
              onClick={() => setIsLogin(true)}
            >
              Sign In
            </button>
            <button
              className={`flex-1 py-2 px-4 rounded-md text-sm font-semibold transition-all ${
                !isLogin
                  ? 'bg-iron-gold text-iron-black'
                  : 'text-iron-gray hover:text-iron-white'
              }`}
              onClick={() => setIsLogin(false)}
            >
              Sign Up
            </button>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            <AnimatePresence mode="wait">
              {!isLogin && (
                <motion.div
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: 'auto' }}
                  exit={{ opacity: 0, height: 0 }}
                  transition={{ duration: 0.3 }}
                >
                  <Label htmlFor="username" className="text-iron-white">
                    Username
                  </Label>
                  <div className="relative">
                    <User className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-iron-gray" />
                    <Input
                      id="username"
                      type="text"
                      placeholder="Choose a username"
                      value={formData.username}
                      onChange={(e) => handleInputChange('username', e.target.value)}
                      className={`pl-10 bg-iron-black/50 border-iron-dark-gray text-iron-white placeholder-iron-gray focus:border-iron-gold ${
                        errors.username ? 'border-iron-red' : ''
                      }`}
                    />
                  </div>
                  {errors.username && (
                    <p className="text-iron-red text-sm mt-1">{errors.username}</p>
                  )}
                </motion.div>
              )}
            </AnimatePresence>

            <div>
              <Label htmlFor="email" className="text-iron-white">
                Email
              </Label>
              <div className="relative">
                <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-iron-gray" />
                <Input
                  id="email"
                  type="email"
                  placeholder="Enter your email"
                  value={formData.email}
                  onChange={(e) => handleInputChange('email', e.target.value)}
                  className={`pl-10 bg-iron-black/50 border-iron-dark-gray text-iron-white placeholder-iron-gray focus:border-iron-gold ${
                    errors.email ? 'border-iron-red' : ''
                  }`}
                />
              </div>
              {errors.email && (
                <p className="text-iron-red text-sm mt-1">{errors.email}</p>
              )}
            </div>

            <div>
              <Label htmlFor="password" className="text-iron-white">
                Password
              </Label>
              <div className="relative">
                <Lock className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-iron-gray" />
                <Input
                  id="password"
                  type={showPassword ? 'text' : 'password'}
                  placeholder="Enter your password"
                  value={formData.password}
                  onChange={(e) => handleInputChange('password', e.target.value)}
                  className={`pl-10 pr-10 bg-iron-black/50 border-iron-dark-gray text-iron-white placeholder-iron-gray focus:border-iron-gold ${
                    errors.password ? 'border-iron-red' : ''
                  }`}
                />
                <button
                  type="button"
                  className="absolute right-3 top-1/2 transform -translate-y-1/2 text-iron-gray hover:text-iron-white"
                  onClick={() => setShowPassword(!showPassword)}
                >
                  {showPassword ? (
                    <EyeOff className="w-4 h-4" />
                  ) : (
                    <Eye className="w-4 h-4" />
                  )}
                </button>
              </div>
              {errors.password && (
                <p className="text-iron-red text-sm mt-1">{errors.password}</p>
              )}
            </div>

            <AnimatePresence mode="wait">
              {!isLogin && (
                <motion.div
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: 'auto' }}
                  exit={{ opacity: 0, height: 0 }}
                  transition={{ duration: 0.3 }}
                >
                  <Label htmlFor="confirmPassword" className="text-iron-white">
                    Confirm Password
                  </Label>
                  <div className="relative">
                    <Lock className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-iron-gray" />
                    <Input
                      id="confirmPassword"
                      type={showPassword ? 'text' : 'password'}
                      placeholder="Confirm your password"
                      value={formData.confirmPassword}
                      onChange={(e) => handleInputChange('confirmPassword', e.target.value)}
                      className={`pl-10 bg-iron-black/50 border-iron-dark-gray text-iron-white placeholder-iron-gray focus:border-iron-gold ${
                        errors.confirmPassword ? 'border-iron-red' : ''
                      }`}
                    />
                  </div>
                  {errors.confirmPassword && (
                    <p className="text-iron-red text-sm mt-1">{errors.confirmPassword}</p>
                  )}
                </motion.div>
              )}
            </AnimatePresence>

            {errors.submit && (
              <div className="p-3 bg-iron-red/20 border border-iron-red rounded-lg">
                <p className="text-iron-red text-sm">{errors.submit}</p>
              </div>
            )}

            <Button
              type="submit"
              disabled={loading}
              className="w-full bg-iron-gold hover:bg-iron-bright-gold text-iron-black font-semibold py-3 flex items-center justify-center space-x-2"
            >
              {loading ? (
                <motion.div
                  animate={{ rotate: 360 }}
                  transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
                  className="w-4 h-4 border-2 border-iron-black border-t-transparent rounded-full"
                />
              ) : (
                <>
                  <span>{isLogin ? 'Sign In' : 'Create Account'}</span>
                  <ArrowRight className="w-4 h-4" />
                </>
              )}
            </Button>
          </form>

          {/* Additional Options */}
          <div className="mt-6 text-center">
            <p className="text-iron-gray text-sm">
              {isLogin ? "Don't have an account?" : "Already have an account?"}
              <button
                className="text-iron-gold hover:text-iron-bright-gold ml-1 font-semibold"
                onClick={() => setIsLogin(!isLogin)}
              >
                {isLogin ? 'Sign up' : 'Sign in'}
              </button>
            </p>
          </div>

          {isLogin && (
            <div className="mt-4 text-center">
              <button className="text-iron-gray hover:text-iron-white text-sm">
                Forgot your password?
              </button>
            </div>
          )}
        </Card>

        {/* Features Preview */}
        <motion.div
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.6 }}
          className="mt-8 text-center"
        >
          <p className="text-iron-gray text-sm mb-4">Join our community to:</p>
          <div className="grid grid-cols-2 gap-2 text-sm">
            <div className="text-iron-light-gray">✓ Ask technical questions</div>
            <div className="text-iron-light-gray">✓ Share your knowledge</div>
            <div className="text-iron-light-gray">✓ Build your reputation</div>
            <div className="text-iron-light-gray">✓ Connect with developers</div>
          </div>
        </motion.div>
      </motion.div>
    </div>
  );
}