import { useState, useEffect } from 'react';
import { GoogleMap } from './GoogleMap';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Input } from './ui/input';
import { 
  Shield, 
  Phone, 
  Heart, 
  Home, 
  ShoppingBag, 
  UtensilsCrossed, 
  MapPin,
  Navigation,
  Search,
  AlertTriangle,
  Clock,
  Star,
  Users
} from 'lucide-react';
import type { User } from '@supabase/supabase-js';

// Direct configuration to avoid import issues
const RELIEF_CONFIG = {
  googleMaps: {
    apiKey: (() => {
      try {
        return (window as any)?.import?.meta?.env?.VITE_GOOGLE_MAPS_API_KEY || 
               (import.meta as any)?.env?.VITE_GOOGLE_MAPS_API_KEY || 
               "DEMO_MODE";
      } catch (error) {
        return "DEMO_MODE";
      }
    })(),
  }
};

interface ReliefPointsProps {
  user: User | null;
}

interface ReliefLocation {
  id: string;
  name: string;
  state: string;
  coordinates: [number, number];
  description: string;
  emergencyContacts: string[];
  reliefCenters: ReliefCenter[];
}

interface ReliefCenter {
  id: string;
  name: string;
  type: 'shelter' | 'food' | 'medical' | 'safe-point' | 'shop' | 'emergency';
  coordinates: [number, number];
  address: string;
  phone: string;
  isActive: boolean;
  capacity?: number;
  services: string[];
  lastUpdated: string;
}

// Sample data for Indian relief points
const reliefLocations: ReliefLocation[] = [
  {
    id: 'mumbai',
    name: 'Mumbai',
    state: 'Maharashtra',
    coordinates: [19.0760, 72.8777],
    description: 'Financial capital with extensive emergency infrastructure',
    emergencyContacts: ['100', '101', '102', '1077'],
    reliefCenters: [
      {
        id: 'mumbai-1',
        name: 'Bandra Relief Center',
        type: 'shelter',
        coordinates: [19.0596, 72.8295],
        address: 'Bandra West, Mumbai',
        phone: '+91-22-26420001',
        isActive: true,
        capacity: 500,
        services: ['Emergency Shelter', 'Food Distribution', 'Medical Aid'],
        lastUpdated: '2025-01-13T10:00:00Z'
      },
      {
        id: 'mumbai-2',
        name: 'Sion Hospital',
        type: 'medical',
        coordinates: [19.0433, 72.8626],
        address: 'Sion, Mumbai',
        phone: '+91-22-24076901',
        isActive: true,
        services: ['Emergency Care', 'Trauma Center', '24/7 Ambulance'],
        lastUpdated: '2025-01-13T09:30:00Z'
      },
      {
        id: 'mumbai-3',
        name: 'Andheri Food Distribution',
        type: 'food',
        coordinates: [19.1136, 72.8697],
        address: 'Andheri East, Mumbai',
        phone: '+91-22-26820011',
        isActive: true,
        capacity: 1000,
        services: ['Free Meals', 'Water Supply', 'Baby Food'],
        lastUpdated: '2025-01-13T08:45:00Z'
      },
      {
        id: 'mumbai-4',
        name: 'Dadar Safe Point',
        type: 'safe-point',
        coordinates: [19.0178, 72.8478],
        address: 'Dadar, Mumbai',
        phone: '+91-22-24142001',
        isActive: true,
        services: ['Police Station', 'Emergency Communication', 'Safe Zone'],
        lastUpdated: '2025-01-13T11:15:00Z'
      },
      {
        id: 'mumbai-5',
        name: 'Emergency Supplies Store',
        type: 'shop',
        coordinates: [19.0896, 72.8656],
        address: 'Borivali West, Mumbai',
        phone: '+91-22-28920011',
        isActive: true,
        services: ['Emergency Supplies', 'Medicines', 'Basic Necessities'],
        lastUpdated: '2025-01-13T07:20:00Z'
      }
    ]
  },
  {
    id: 'delhi',
    name: 'Delhi',
    state: 'Delhi',
    coordinates: [28.6139, 77.2090],
    description: 'National capital with comprehensive emergency services',
    emergencyContacts: ['100', '101', '102', '1098'],
    reliefCenters: [
      {
        id: 'delhi-1',
        name: 'Central Delhi Relief Hub',
        type: 'shelter',
        coordinates: [28.6304, 77.2177],
        address: 'Connaught Place, New Delhi',
        phone: '+91-11-23363814',
        isActive: true,
        capacity: 800,
        services: ['Emergency Shelter', 'Food', 'Medical Support'],
        lastUpdated: '2025-01-13T12:00:00Z'
      },
      {
        id: 'delhi-2',
        name: 'AIIMS Emergency',
        type: 'medical',
        coordinates: [28.5672, 77.2100],
        address: 'Ansari Nagar, New Delhi',
        phone: '+91-11-26588500',
        isActive: true,
        services: ['Trauma Center', 'ICU', 'Emergency Surgery'],
        lastUpdated: '2025-01-13T11:45:00Z'
      },
      {
        id: 'delhi-3',
        name: 'Chandni Chowk Food Center',
        type: 'food',
        coordinates: [28.6506, 77.2334],
        address: 'Chandni Chowk, Delhi',
        phone: '+91-11-23961234',
        isActive: true,
        capacity: 1200,
        services: ['Community Kitchen', 'Water', 'Packed Meals'],
        lastUpdated: '2025-01-13T10:30:00Z'
      }
    ]
  },
  {
    id: 'chennai',
    name: 'Chennai',
    state: 'Tamil Nadu',
    coordinates: [13.0827, 80.2707],
    description: 'Coastal city with cyclone and flood relief infrastructure',
    emergencyContacts: ['100', '101', '102', '1073'],
    reliefCenters: [
      {
        id: 'chennai-1',
        name: 'Marina Beach Relief Station',
        type: 'emergency',
        coordinates: [13.0475, 80.2824],
        address: 'Marina Beach, Chennai',
        phone: '+91-44-28544444',
        isActive: true,
        services: ['Coastal Rescue', 'Emergency Evacuation', 'First Aid'],
        lastUpdated: '2025-01-13T09:15:00Z'
      },
      {
        id: 'chennai-2',
        name: 'T. Nagar Community Shelter',
        type: 'shelter',
        coordinates: [13.0418, 80.2341],
        address: 'T. Nagar, Chennai',
        phone: '+91-44-24335678',
        isActive: true,
        capacity: 600,
        services: ['Temporary Housing', 'Family Support', 'Child Care'],
        lastUpdated: '2025-01-13T08:00:00Z'
      }
    ]
  },
  {
    id: 'kolkata',
    name: 'Kolkata',
    state: 'West Bengal',
    coordinates: [22.5726, 88.3639],
    description: 'Eastern hub with monsoon and cyclone preparedness',
    emergencyContacts: ['100', '101', '102', '1091'],
    reliefCenters: [
      {
        id: 'kolkata-1',
        name: 'Park Street Emergency Center',
        type: 'emergency',
        coordinates: [22.5448, 88.3426],
        address: 'Park Street, Kolkata',
        phone: '+91-33-22298765',
        isActive: true,
        services: ['Emergency Coordination', 'Rescue Operations', 'Medical Support'],
        lastUpdated: '2025-01-13T10:45:00Z'
      },
      {
        id: 'kolkata-2',
        name: 'Howrah Relief Kitchen',
        type: 'food',
        coordinates: [22.5958, 88.2636],
        address: 'Howrah, Kolkata',
        phone: '+91-33-26548901',
        isActive: true,
        capacity: 800,
        services: ['Community Meals', 'Food Packets', 'Water Distribution'],
        lastUpdated: '2025-01-13T09:30:00Z'
      }
    ]
  },
  {
    id: 'bangalore',
    name: 'Bangalore',
    state: 'Karnataka',
    coordinates: [12.9716, 77.5946],
    description: 'Technology hub with modern emergency response systems',
    emergencyContacts: ['100', '101', '102', '1077'],
    reliefCenters: [
      {
        id: 'bangalore-1',
        name: 'Electronic City Relief Hub',
        type: 'shelter',
        coordinates: [12.8456, 77.6603],
        address: 'Electronic City, Bangalore',
        phone: '+91-80-28520000',
        isActive: true,
        capacity: 400,
        services: ['Tech-enabled Shelter', 'WiFi Access', 'Device Charging'],
        lastUpdated: '2025-01-13T11:00:00Z'
      },
      {
        id: 'bangalore-2',
        name: 'Brigade Road Medical Point',
        type: 'medical',
        coordinates: [12.9716, 77.6197],
        address: 'Brigade Road, Bangalore',
        phone: '+91-80-25589876',
        isActive: true,
        services: ['Emergency Medical', 'Pharmacy', 'Ambulance Service'],
        lastUpdated: '2025-01-13T10:15:00Z'
      }
    ]
  }
];

const typeIcons = {
  shelter: Home,
  food: UtensilsCrossed,
  medical: Heart,
  'safe-point': Shield,
  shop: ShoppingBag,
  emergency: AlertTriangle
};

const typeColors = {
  shelter: 'bg-blue-500',
  food: 'bg-orange-500',
  medical: 'bg-red-500',
  'safe-point': 'bg-green-500',
  shop: 'bg-purple-500',
  emergency: 'bg-yellow-500'
};

export function ReliefPoints({ user }: ReliefPointsProps) {
  const [selectedLocation, setSelectedLocation] = useState<ReliefLocation>(reliefLocations[0]);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedType, setSelectedType] = useState<string>('all');
  const [currentPosition, setCurrentPosition] = useState<[number, number] | null>(null);
  const [isEmergency, setIsEmergency] = useState(false);

  useEffect(() => {
    // Get user's current location
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          setCurrentPosition([position.coords.latitude, position.coords.longitude]);
        },
        (error) => {
          console.error('Error getting location:', error);
        }
      );
    }
  }, []);

  const filteredCenters = selectedLocation.reliefCenters.filter(center => {
    const matchesSearch = center.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         center.address.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesType = selectedType === 'all' || center.type === selectedType;
    return matchesSearch && matchesType;
  });

  const handleEmergencyCall = (number: string) => {
    if (typeof window !== 'undefined') {
      window.open(`tel:${number}`, '_self');
    }
  };

  const getDirections = (coordinates: [number, number]) => {
    if (currentPosition) {
      const googleMapsUrl = `https://www.google.com/maps/dir/${currentPosition[0]},${currentPosition[1]}/${coordinates[0]},${coordinates[1]}`;
      window.open(googleMapsUrl, '_blank');
    } else {
      alert('Location permission required for directions');
    }
  };

  return (
    <div className="h-full bg-gradient-to-br from-blue-50 via-indigo-50 to-emerald-50 dark:from-gray-900 dark:via-gray-800 dark:to-gray-900 relative">
      {/* Emergency Alert */}
      {isEmergency && (
        <div className="absolute top-0 left-0 right-0 z-50 bg-red-500 text-white p-4 text-center">
          <div className="flex items-center justify-center gap-2">
            <AlertTriangle className="w-5 h-5" />
            <span className="font-semibold">EMERGENCY MODE ACTIVATED</span>
            <Button
              size="sm"
              variant="outline"
              onClick={() => setIsEmergency(false)}
              className="ml-4 bg-white text-red-500 hover:bg-red-50"
            >
              Deactivate
            </Button>
          </div>
        </div>
      )}

      <div className="flex h-full">
        {/* Sidebar */}
        <div className="w-full md:w-1/3 lg:w-1/4 bg-white/80 dark:bg-gray-900/80 backdrop-blur-lg border-r border-gray-200 dark:border-gray-700 overflow-y-auto">
          <div className="p-6 border-b border-gray-200 dark:border-gray-700">
            <h1 className="text-2xl font-bold text-gray-900 dark:text-white mb-2">
              Relief Points
            </h1>
            <p className="text-sm text-gray-600 dark:text-gray-300 mb-4">
              Emergency services and relief centers across India
            </p>

            {/* Emergency Button */}
            <Button
              onClick={() => setIsEmergency(!isEmergency)}
              className={`w-full mb-4 ${
                isEmergency 
                  ? 'bg-red-500 hover:bg-red-600' 
                  : 'bg-red-500 hover:bg-red-600'
              }`}
            >
              <AlertTriangle className="w-4 h-4 mr-2" />
              {isEmergency ? 'Emergency Active' : 'Emergency Mode'}
            </Button>

            {/* Location Selector */}
            <div className="mb-4">
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                Select Location
              </label>
              <select
                value={selectedLocation.id}
                onChange={(e) => {
                  const location = reliefLocations.find(l => l.id === e.target.value);
                  if (location) setSelectedLocation(location);
                }}
                className="w-full p-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-800 text-gray-900 dark:text-white"
              >
                {reliefLocations.map(location => (
                  <option key={location.id} value={location.id}>
                    {location.name}, {location.state}
                  </option>
                ))}
              </select>
            </div>

            {/* Search */}
            <div className="relative mb-4">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
              <Input
                placeholder="Search relief centers..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10"
              />
            </div>

            {/* Type Filter */}
            <div className="mb-4">
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                Filter by Type
              </label>
              <select
                value={selectedType}
                onChange={(e) => setSelectedType(e.target.value)}
                className="w-full p-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-800 text-gray-900 dark:text-white"
              >
                <option value="all">All Types</option>
                <option value="emergency">Emergency</option>
                <option value="shelter">Shelter</option>
                <option value="food">Food</option>
                <option value="medical">Medical</option>
                <option value="safe-point">Safe Points</option>
                <option value="shop">Shops</option>
              </select>
            </div>

            {/* Emergency Contacts */}
            <Card className="mb-4 bg-red-50 dark:bg-red-900/20 border-red-200 dark:border-red-800">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm text-red-800 dark:text-red-200 flex items-center gap-2">
                  <Phone className="w-4 h-4" />
                  Emergency Contacts
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                {selectedLocation.emergencyContacts.map((contact, index) => (
                  <Button
                    key={index}
                    onClick={() => handleEmergencyCall(contact)}
                    variant="outline"
                    size="sm"
                    className="w-full justify-start bg-red-100 dark:bg-red-800/30 border-red-300 dark:border-red-700 text-red-700 dark:text-red-300 hover:bg-red-200 dark:hover:bg-red-800/50"
                  >
                    <Phone className="w-3 h-3 mr-2" />
                    {contact}
                  </Button>
                ))}
              </CardContent>
            </Card>
          </div>

          {/* Relief Centers List */}
          <div className="p-6 space-y-4">
            {filteredCenters.map((center) => {
              const IconComponent = typeIcons[center.type];
              const colorClass = typeColors[center.type];
              
              return (
                <Card key={center.id} className="hover:shadow-lg transition-shadow">
                  <CardContent className="p-4">
                    <div className="flex items-start gap-3">
                      <div className={`w-10 h-10 ${colorClass} rounded-lg flex items-center justify-center flex-shrink-0`}>
                        <IconComponent className="w-5 h-5 text-white" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-start justify-between mb-1">
                          <h3 className="font-semibold text-gray-900 dark:text-white text-sm truncate">
                            {center.name}
                          </h3>
                          <Badge
                            variant={center.isActive ? "default" : "secondary"}
                            className={`text-xs ml-2 ${center.isActive ? 'bg-green-500' : 'bg-gray-500'}`}
                          >
                            {center.isActive ? 'Active' : 'Inactive'}
                          </Badge>
                        </div>
                        <p className="text-xs text-gray-600 dark:text-gray-300 mb-2">
                          {center.address}
                        </p>
                        <div className="flex items-center gap-2 mb-2">
                          <Phone className="w-3 h-3 text-gray-400" />
                          <span className="text-xs text-gray-600 dark:text-gray-300">
                            {center.phone}
                          </span>
                        </div>
                        {center.capacity && (
                          <div className="flex items-center gap-2 mb-2">
                            <Users className="w-3 h-3 text-gray-400" />
                            <span className="text-xs text-gray-600 dark:text-gray-300">
                              Capacity: {center.capacity}
                            </span>
                          </div>
                        )}
                        <div className="flex flex-wrap gap-1 mb-3">
                          {center.services.slice(0, 2).map((service, index) => (
                            <Badge key={index} variant="outline" className="text-xs">
                              {service}
                            </Badge>
                          ))}
                          {center.services.length > 2 && (
                            <Badge variant="outline" className="text-xs">
                              +{center.services.length - 2} more
                            </Badge>
                          )}
                        </div>
                        <div className="flex gap-2">
                          <Button
                            size="sm"
                            onClick={() => getDirections(center.coordinates)}
                            className="flex-1 text-xs"
                          >
                            <Navigation className="w-3 h-3 mr-1" />
                            Directions
                          </Button>
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => handleEmergencyCall(center.phone)}
                            className="text-xs"
                          >
                            <Phone className="w-3 h-3" />
                          </Button>
                        </div>
                        <div className="flex items-center gap-1 mt-2">
                          <Clock className="w-3 h-3 text-gray-400" />
                          <span className="text-xs text-gray-500 dark:text-gray-400">
                            Updated: {new Date(center.lastUpdated).toLocaleTimeString()}
                          </span>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </div>

        {/* Map */}
        <div className="flex-1 relative">
          <GoogleMap
            center={selectedLocation.coordinates}
            zoom={11}
            markers={filteredCenters.map(center => ({
              id: center.id,
              position: center.coordinates,
              title: center.name,
              type: center.type,
              info: {
                name: center.name,
                type: center.type,
                address: center.address,
                phone: center.phone,
                services: center.services,
                isActive: center.isActive
              }
            }))}
            onMarkerClick={(marker) => {
              console.log('Relief center selected:', marker);
            }}
            userLocation={currentPosition}
            apiKey={RELIEF_CONFIG.googleMaps.apiKey}
          />
        </div>
      </div>
    </div>
  );
}