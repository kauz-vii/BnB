import { useState, useEffect } from 'react';
import { Bookmark, MapPin, Users, Star, Calendar, Search, Filter, Grid, List, Heart, Share, MoreHorizontal } from 'lucide-react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Badge } from './ui/badge';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger, DropdownMenuSeparator } from './ui/dropdown-menu';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import type { User } from '@supabase/supabase-js';

interface SavedMap {
  id: string;
  title: string;
  description: string;
  creator: string;
  creatorId: string;
  category: string;
  location: string;
  rating: number;
  reviewCount: number;
  markerCount: number;
  isPublic: boolean;
  tags: string[];
  savedAt: string;
  lastVisited?: string;
  thumbnail?: string;
  distance?: number;
}

interface SavedMapsProps {
  user: User | null;
}

export function SavedMaps({ user }: SavedMapsProps) {
  const [savedMaps, setSavedMaps] = useState<SavedMap[]>([]);
  const [filteredMaps, setFilteredMaps] = useState<SavedMap[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('all');
  const [sortBy, setSortBy] = useState('saved_date');
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const [loading, setLoading] = useState(true);

  // Mock data - will be replaced with Supabase queries
  const mockSavedMaps: SavedMap[] = [
    {
      id: '1',
      title: 'Hidden Gems of Brooklyn',
      description: 'A curated collection of lesser-known spots in Brooklyn including vintage shops, secret gardens, and local eateries',
      creator: 'Sarah Chen',
      creatorId: 'user2',
      category: 'Exploration',
      location: 'Brooklyn, NY',
      rating: 4.8,
      reviewCount: 124,
      markerCount: 15,
      isPublic: true,
      tags: ['local', 'hidden gems', 'brooklyn', 'authentic'],
      savedAt: '2024-01-15T10:00:00Z',
      lastVisited: '2024-01-20T14:30:00Z',
      distance: 2.5
    },
    {
      id: '2',
      title: 'Coffee Shop Work Tour',
      description: 'Best coffee shops with WiFi and cozy atmosphere for remote work across Manhattan',
      creator: 'Mike Rodriguez',
      creatorId: 'user3',
      category: 'Work & Study',
      location: 'Manhattan, NY',
      rating: 4.6,
      reviewCount: 89,
      markerCount: 12,
      isPublic: true,
      tags: ['coffee', 'wifi', 'remote work', 'manhattan'],
      savedAt: '2024-01-12T09:15:00Z',
      lastVisited: '2024-01-18T11:45:00Z',
      distance: 1.8
    },
    {
      id: '3',
      title: 'Photography Spots NYC',
      description: 'Stunning photography locations throughout New York City for both sunrise and sunset shots',
      creator: 'Emma Thompson',
      creatorId: 'user4',
      category: 'Photography',
      location: 'New York City',
      rating: 4.9,
      reviewCount: 201,
      markerCount: 25,
      isPublic: true,
      tags: ['photography', 'sunrise', 'sunset', 'nyc', 'instagram'],
      savedAt: '2024-01-08T16:20:00Z',
      distance: 3.2
    },
    {
      id: '4',
      title: 'Family Fun Central Park',
      description: 'Kid-friendly activities and spots throughout Central Park perfect for family outings',
      creator: 'David Kim',
      creatorId: 'user5',
      category: 'Family & Kids',
      location: 'Central Park, NY',
      rating: 4.7,
      reviewCount: 156,
      markerCount: 18,
      isPublic: true,
      tags: ['family', 'kids', 'central park', 'outdoor'],
      savedAt: '2024-01-05T13:30:00Z',
      lastVisited: '2024-01-15T10:00:00Z',
      distance: 0.8
    },
    {
      id: '5',
      title: 'Late Night Eats',
      description: 'The best places to grab food after midnight in the city that never sleeps',
      creator: 'Alex Johnson',
      creatorId: 'user1',
      category: 'Food & Dining',
      location: 'Multiple Boroughs',
      rating: 4.4,
      reviewCount: 78,
      markerCount: 22,
      isPublic: true,
      tags: ['late night', 'food', 'dining', '24/7'],
      savedAt: '2024-01-03T22:45:00Z',
      distance: 4.1
    }
  ];

  useEffect(() => {
    // Simulate API call
    setTimeout(() => {
      setSavedMaps(mockSavedMaps);
      setFilteredMaps(mockSavedMaps);
      setLoading(false);
    }, 1000);
  }, []);

  useEffect(() => {
    let filtered = savedMaps;

    // Search filter
    if (searchQuery) {
      filtered = filtered.filter(map => 
        map.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        map.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
        map.tags.some(tag => tag.toLowerCase().includes(searchQuery.toLowerCase()))
      );
    }

    // Category filter
    if (categoryFilter !== 'all') {
      filtered = filtered.filter(map => map.category === categoryFilter);
    }

    // Sort
    switch (sortBy) {
      case 'saved_date':
        filtered.sort((a, b) => new Date(b.savedAt).getTime() - new Date(a.savedAt).getTime());
        break;
      case 'rating':
        filtered.sort((a, b) => b.rating - a.rating);
        break;
      case 'distance':
        filtered.sort((a, b) => (a.distance || 0) - (b.distance || 0));
        break;
      case 'popularity':
        filtered.sort((a, b) => b.reviewCount - a.reviewCount);
        break;
    }

    setFilteredMaps(filtered);
  }, [savedMaps, searchQuery, categoryFilter, sortBy]);

  const categories = ['all', 'Exploration', 'Food & Dining', 'Photography', 'Work & Study', 'Family & Kids'];

  const removeSavedMap = (mapId: string) => {
    setSavedMaps(maps => maps.filter(m => m.id !== mapId));
  };

  if (!user) {
    return (
      <div className="h-full flex items-center justify-center bg-gradient-to-br from-blue-50 via-indigo-50 to-emerald-50">
        <div className="text-center space-y-4">
          <div className="w-24 h-24 bg-gradient-to-r from-blue-500 to-emerald-500 rounded-full flex items-center justify-center mx-auto">
            <Bookmark className="w-12 h-12 text-white" />
          </div>
          <h2 className="text-2xl font-bold text-slate-800">Sign in to view saved maps</h2>
          <p className="text-slate-600">Keep track of your favorite maps and discover new places</p>
        </div>
      </div>
    );
  }

  return (
    <div className="h-full bg-gradient-to-br from-blue-50 via-indigo-50 to-emerald-50 p-6 overflow-y-auto">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Header */}
        <div className="bg-white/80 backdrop-blur-xl rounded-2xl shadow-xl p-6 border border-white/20">
          <div className="flex items-center justify-between mb-6">
            <div>
              <h1 className="text-3xl font-bold bg-gradient-to-r from-blue-600 to-emerald-500 bg-clip-text text-transparent">
                Saved Maps
              </h1>
              <p className="text-slate-600 mt-2">Your collection of favorite maps and places</p>
            </div>
            <Badge className="bg-gradient-to-r from-blue-500 to-emerald-500 text-white text-lg px-4 py-2">
              {savedMaps.length} Maps Saved
            </Badge>
          </div>

          {/* Search and Filters */}
          <div className="flex flex-col md:flex-row gap-4 items-center">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400 w-5 h-5" />
              <Input
                placeholder="Search saved maps..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10 bg-white/70 border-white/30 focus:bg-white"
              />
            </div>
            
            <Select value={categoryFilter} onValueChange={setCategoryFilter}>
              <SelectTrigger className="w-full md:w-48 bg-white/70 border-white/30">
                <SelectValue placeholder="Category" />
              </SelectTrigger>
              <SelectContent>
                {categories.map(category => (
                  <SelectItem key={category} value={category}>
                    {category === 'all' ? 'All Categories' : category}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>

            <Select value={sortBy} onValueChange={setSortBy}>
              <SelectTrigger className="w-full md:w-48 bg-white/70 border-white/30">
                <SelectValue placeholder="Sort by" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="saved_date">Recently Saved</SelectItem>
                <SelectItem value="rating">Highest Rated</SelectItem>
                <SelectItem value="distance">Nearest</SelectItem>
                <SelectItem value="popularity">Most Popular</SelectItem>
              </SelectContent>
            </Select>

            <div className="flex bg-white/70 rounded-lg border border-white/30">
              <Button
                variant={viewMode === 'grid' ? 'default' : 'ghost'}
                size="sm"
                onClick={() => setViewMode('grid')}
                className="rounded-r-none"
              >
                <Grid className="w-4 h-4" />
              </Button>
              <Button
                variant={viewMode === 'list' ? 'default' : 'ghost'}
                size="sm"
                onClick={() => setViewMode('list')}
                className="rounded-l-none"
              >
                <List className="w-4 h-4" />
              </Button>
            </div>
          </div>
        </div>

        {/* Maps Grid/List */}
        <div className="bg-white/80 backdrop-blur-xl rounded-2xl shadow-xl border border-white/20 p-6">
          {loading ? (
            <div className={`grid ${viewMode === 'grid' ? 'grid-cols-1 md:grid-cols-2 lg:grid-cols-3' : 'grid-cols-1'} gap-6`}>
              {[1, 2, 3, 4, 5, 6].map((i) => (
                <div key={i} className="animate-pulse">
                  <div className="h-48 bg-slate-200 rounded-xl"></div>
                </div>
              ))}
            </div>
          ) : (
            <>
              {filteredMaps.length > 0 ? (
                <div className={`grid ${viewMode === 'grid' ? 'grid-cols-1 md:grid-cols-2 lg:grid-cols-3' : 'grid-cols-1'} gap-6`}>
                  {filteredMaps.map((map) => (
                    <Card key={map.id} className={`hover-lift transition-all duration-200 hover:shadow-xl bg-white/60 backdrop-blur-sm border border-white/30 ${viewMode === 'list' ? 'flex flex-row' : ''}`}>
                      {viewMode === 'grid' ? (
                        <>
                          <CardHeader className="pb-3">
                            <div className="flex items-start justify-between">
                              <div className="flex-1">
                                <CardTitle className="text-lg font-bold text-slate-800 line-clamp-1">
                                  {map.title}
                                </CardTitle>
                                <p className="text-sm text-slate-600 mt-1">by {map.creator}</p>
                              </div>
                              <DropdownMenu>
                                <DropdownMenuTrigger asChild>
                                  <Button variant="ghost" size="sm" className="p-2">
                                    <MoreHorizontal className="w-4 h-4" />
                                  </Button>
                                </DropdownMenuTrigger>
                                <DropdownMenuContent align="end">
                                  <DropdownMenuItem>
                                    <Share className="w-4 h-4 mr-2" />
                                    Share Map
                                  </DropdownMenuItem>
                                  <DropdownMenuSeparator />
                                  <DropdownMenuItem 
                                    className="text-red-600"
                                    onClick={() => removeSavedMap(map.id)}
                                  >
                                    <Heart className="w-4 h-4 mr-2" />
                                    Remove from Saved
                                  </DropdownMenuItem>
                                </DropdownMenuContent>
                              </DropdownMenu>
                            </div>
                          </CardHeader>
                          <CardContent className="pt-0">
                            <p className="text-sm text-slate-600 line-clamp-2 mb-4">
                              {map.description}
                            </p>
                            
                            <div className="space-y-3">
                              <div className="flex items-center justify-between text-sm">
                                <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-200">
                                  {map.category}
                                </Badge>
                                <div className="flex items-center space-x-1 text-yellow-600">
                                  <Star className="w-4 h-4 fill-current" />
                                  <span className="font-medium">{map.rating}</span>
                                  <span className="text-slate-500">({map.reviewCount})</span>
                                </div>
                              </div>
                              
                              <div className="flex items-center justify-between text-sm text-slate-500">
                                <div className="flex items-center space-x-1">
                                  <MapPin className="w-4 h-4" />
                                  <span>{map.markerCount} markers</span>
                                </div>
                                {map.distance && (
                                  <div className="flex items-center space-x-1">
                                    <span>{map.distance} km away</span>
                                  </div>
                                )}
                              </div>
                              
                              <div className="flex items-center justify-between text-xs text-slate-400">
                                <div className="flex items-center space-x-1">
                                  <Calendar className="w-3 h-3" />
                                  <span>Saved {new Date(map.savedAt).toLocaleDateString()}</span>
                                </div>
                                {map.lastVisited && (
                                  <span>Last visited {new Date(map.lastVisited).toLocaleDateString()}</span>
                                )}
                              </div>
                              
                              <div className="flex flex-wrap gap-1 mt-2">
                                {map.tags.slice(0, 3).map(tag => (
                                  <Badge key={tag} variant="secondary" className="text-xs bg-slate-100 text-slate-600">
                                    {tag}
                                  </Badge>
                                ))}
                                {map.tags.length > 3 && (
                                  <Badge variant="secondary" className="text-xs bg-slate-100 text-slate-600">
                                    +{map.tags.length - 3}
                                  </Badge>
                                )}
                              </div>
                            </div>
                          </CardContent>
                        </>
                      ) : (
                        <CardContent className="p-6 flex items-center space-x-6 w-full">
                          <div className="flex-1">
                            <div className="flex items-start justify-between mb-2">
                              <div>
                                <h3 className="font-bold text-lg text-slate-800">{map.title}</h3>
                                <p className="text-sm text-slate-600">by {map.creator}</p>
                              </div>
                              <div className="flex items-center space-x-2">
                                <div className="flex items-center space-x-1 text-yellow-600">
                                  <Star className="w-4 h-4 fill-current" />
                                  <span className="font-medium">{map.rating}</span>
                                </div>
                                <DropdownMenu>
                                  <DropdownMenuTrigger asChild>
                                    <Button variant="ghost" size="sm" className="p-2">
                                      <MoreHorizontal className="w-4 h-4" />
                                    </Button>
                                  </DropdownMenuTrigger>
                                  <DropdownMenuContent align="end">
                                    <DropdownMenuItem>
                                      <Share className="w-4 h-4 mr-2" />
                                      Share Map
                                    </DropdownMenuItem>
                                    <DropdownMenuSeparator />
                                    <DropdownMenuItem 
                                      className="text-red-600"
                                      onClick={() => removeSavedMap(map.id)}
                                    >
                                      <Heart className="w-4 h-4 mr-2" />
                                      Remove from Saved
                                    </DropdownMenuItem>
                                  </DropdownMenuContent>
                                </DropdownMenu>
                              </div>
                            </div>
                            
                            <p className="text-slate-600 mb-3 line-clamp-2">{map.description}</p>
                            
                            <div className="flex items-center space-x-4 text-sm text-slate-500">
                              <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-200">
                                {map.category}
                              </Badge>
                              <div className="flex items-center space-x-1">
                                <MapPin className="w-4 h-4" />
                                <span>{map.markerCount} markers</span>
                              </div>
                              {map.distance && <span>{map.distance} km away</span>}
                              <span>Saved {new Date(map.savedAt).toLocaleDateString()}</span>
                            </div>
                          </div>
                        </CardContent>
                      )}
                    </Card>
                  ))}
                </div>
              ) : (
                <div className="text-center py-12">
                  <div className="w-16 h-16 bg-slate-200 rounded-full flex items-center justify-center mx-auto mb-4">
                    <Bookmark className="w-8 h-8 text-slate-400" />
                  </div>
                  <h3 className="font-semibold text-slate-600 mb-2">No saved maps found</h3>
                  <p className="text-slate-500 mb-4">
                    {searchQuery || categoryFilter !== 'all' 
                      ? 'Try adjusting your search or filters'
                      : 'Start exploring and save maps you love'
                    }
                  </p>
                  <Button className="bg-gradient-to-r from-blue-600 to-emerald-500 hover:from-blue-700 hover:to-emerald-600">
                    Explore Maps
                  </Button>
                </div>
              )}
            </>
          )}
        </div>
      </div>
    </div>
  );
}