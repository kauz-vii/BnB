export interface User {
  id: string;
  username: string;
  email: string;
  avatarUrl?: string;
  bio?: string;
  reputation: number;
  level: number;
  createdAt: Date;
  features: string[];
}

export interface Question {
  id: string;
  title: string;
  body: string;
  authorId: string;
  author: User;
  tags: string[];
  createdAt: Date;
  updatedAt: Date;
  score: number;
  hotRank: number;
  acceptedAnswerId?: string;
  answers: Answer[];
  votes: Vote[];
  views: number;
  isClosed: boolean;
}

export interface Answer {
  id: string;
  questionId: string;
  authorId: string;
  author: User;
  body: string;
  createdAt: Date;
  updatedAt: Date;
  score: number;
  isAccepted: boolean;
  ratings: AskerRating[];
  comments: Comment[];
  votes: Vote[];
}

export interface Comment {
  id: string;
  authorId: string;
  author: User;
  answerId?: string;
  questionId?: string;
  body: string;
  createdAt: Date;
}

export interface Vote {
  id: string;
  userId: string;
  questionId?: string;
  answerId?: string;
  type: 'UP' | 'DOWN';
  createdAt: Date;
}

export interface AskerRating {
  id: string;
  questionId: string;
  answerId: string;
  raterId: string;
  answererId: string;
  stars: number; // 1-5
  createdAt: Date;
}

export interface Tag {
  id: string;
  name: string;
  questionsCount?: number;
}

export interface Notification {
  id: string;
  userId: string;
  type: 'ANSWER_POSTED' | 'ANSWER_ACCEPTED' | 'RATING_RECEIVED' | 'DM' | 'MENTION';
  data: any;
  read: boolean;
  createdAt: Date;
}

export interface Level {
  level: number;
  minReputation: number;
  name: string;
  features: string[];
  perks: string[];
}

export interface ReputationActivity {
  id: string;
  userId: string;
  type: 'ANSWER_UPVOTE' | 'ANSWER_DOWNVOTE' | 'QUESTION_UPVOTE' | 'QUESTION_DOWNVOTE' | 'ANSWER_ACCEPTED' | 'ASKER_RATING';
  points: number;
  description: string;
  createdAt: Date;
}

export interface FeedFilters {
  sort: 'hot' | 'new' | 'unanswered' | 'trending';
  tags: string[];
  timeRange?: 'today' | 'week' | 'month' | 'all';
}

export const LEVELS: Level[] = [
  {
    level: 1,
    minReputation: 0,
    name: 'Newbie',
    features: ['ASK_QUESTION', 'ANSWER_QUESTION', 'COMMENT'],
    perks: ['Ask and answer questions', 'Comment on posts', '10 min post cooldown']
  },
  {
    level: 2,
    minReputation: 50,
    name: 'Contributor',
    features: ['DM', 'IMAGE_UPLOAD'],
    perks: ['Direct messaging', 'Upload images', 'Reduced cooldown (5 min)']
  },
  {
    level: 3,
    minReputation: 150,
    name: 'Helpful',
    features: ['GROUP_CHAT', 'TAG_SUGGEST'],
    perks: ['Create group chats', 'Suggest new tags', 'Edit own posts (5 min window)']
  },
  {
    level: 4,
    minReputation: 400,
    name: 'Expert',
    features: ['VIDEO_CALL', 'EDIT_POSTS'],
    perks: ['Video calls in chats', 'Edit own posts with history', '2 min cooldown']
  },
  {
    level: 5,
    minReputation: 900,
    name: 'Guru',
    features: ['CREATE_TAGS', 'FEATURED_ANSWERS'],
    perks: ['Create new tags', 'Feature answers', 'No post cooldown']
  },
  {
    level: 6,
    minReputation: 1600,
    name: 'Moderator',
    features: ['COMMUNITY_MOD', 'CLOSE_QUESTIONS'],
    perks: ['Community moderation', 'Close/reopen questions', 'Weighted votes']
  }
];

export const REPUTATION_POINTS = {
  ANSWER_UPVOTE: 10,
  ANSWER_DOWNVOTE: -2,
  QUESTION_UPVOTE: 5,
  QUESTION_DOWNVOTE: -2,
  ANSWER_ACCEPTED_ANSWERER: 15,
  ANSWER_ACCEPTED_ASKER: 2,
  ASKER_RATING_BASE: 3, // multiplied by (stars - 3), so ranges from -6 to +6
};