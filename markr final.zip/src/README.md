# Markr - Interactive Relief Points & Maps Platform

Markr is a comprehensive mapping platform focused on India, featuring emergency relief points, interactive maps, and community-driven location sharing.

## Features

- **Interactive Google Maps Integration** with fallback for demo mode
- **Emergency Relief Points** - Comprehensive database of emergency services across major Indian cities
- **Real-time Directions** using Google Maps API
- **Responsive Design** - Works seamlessly on desktop and mobile
- **Dark Mode Support**
- **User Authentication** with Supabase
- **Gamification System** with XP and achievements

## Quick Start

### Environment Setup

1. Copy the environment example file:
   ```bash
   cp env.example .env
   ```

2. Configure your environment variables in `.env`:
   ```bash
   # Google Maps API Key (Optional - app works in demo mode without it)
   VITE_GOOGLE_MAPS_API_KEY=your_google_maps_api_key_here
   
   # Supabase Configuration (Optional for basic functionality)
   VITE_SUPABASE_URL=your_supabase_url_here
   VITE_SUPABASE_ANON_KEY=your_supabase_anon_key_here
   ```

### Google Maps API Setup (Optional)

To enable full Google Maps integration:

1. Go to [Google Cloud Console](https://console.cloud.google.com/)
2. Create a new project or select an existing one
3. Enable the following APIs:
   - Maps JavaScript API
   - Places API
   - Directions API
4. Create credentials (API Key)
5. Add your API key to the `.env` file

**Note**: The app works in demo mode without an API key, showing a fallback interface.

### Supabase Setup (Optional)

For user authentication and data persistence:

1. Create a new project at [Supabase](https://supabase.com)
2. Get your project URL and anon key from Settings > API
3. Add them to your `.env` file

## Architecture

### Components Structure

- `/components/GoogleMap.tsx` - Google Maps integration with fallback
- `/components/ReliefPoints.tsx` - Emergency relief points system
- `/components/MapView.tsx` - Main map interface
- `/components/Navbar.tsx` - Navigation with mobile responsiveness
- `/components/TravelSidebar.tsx` - Collapsible sidebar navigation
- `/config/index.ts` - Centralized configuration management

### Key Features

#### Relief Points System
- **Mumbai, Delhi, Chennai, Kolkata, Bangalore** coverage
- Emergency contacts for each city
- Types: Shelter, Food, Medical, Safe Points, Shops, Emergency
- Real-time status indicators
- Direct calling and directions integration

#### Responsive Design
- Mobile-first approach
- Collapsible sidebar on mobile
- Touch-friendly interface
- Adaptive layouts for different screen sizes

#### Error Handling
- Graceful fallbacks for missing API keys
- Network error handling
- User-friendly error messages

## Development

### Available Scripts

- `npm run dev` - Start development server
- `npm run build` - Build for production
- `npm run preview` - Preview production build

### Browser Compatibility

- Modern browsers with ES2020+ support
- Mobile browsers (Safari, Chrome, Firefox)
- Progressive Web App ready

### Technology Stack

- **Frontend**: React 18, TypeScript, Tailwind CSS v4
- **Maps**: Google Maps JavaScript API with fallback
- **Icons**: Lucide React
- **UI Components**: Custom component library
- **Backend**: Supabase (optional)
- **Styling**: Tailwind CSS with custom design system

## Configuration

The app uses a centralized configuration system in `/config/index.ts` that safely handles environment variables and provides fallbacks:

```typescript
export const config = {
  googleMaps: {
    apiKey: "API_KEY_OR_DEMO_MODE"
  },
  app: {
    name: "Markr",
    defaultLocation: {
      lat: 20.5937, // Center of India
      lng: 78.9629,
      zoom: 5
    }
  }
};
```

## Indian Relief Points Data

The app includes a comprehensive database of relief points across major Indian cities:

- **Emergency Contacts**: 100, 101, 102, city-specific numbers
- **Relief Centers**: Shelters, food distribution, medical centers
- **Real-time Status**: Active/inactive status tracking
- **Services**: Detailed service descriptions for each location

## Deployment

### Environment Variables for Production

```bash
VITE_GOOGLE_MAPS_API_KEY=your_production_api_key
VITE_SUPABASE_URL=your_production_supabase_url
VITE_SUPABASE_ANON_KEY=your_production_supabase_key
```

### Build Process

```bash
npm run build
```

The built files will be in the `dist` directory, ready for deployment to any static hosting service.

## Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Test thoroughly
5. Submit a pull request

## License

MIT License - see LICENSE file for details

---

**Note**: This application is designed to work in demo mode without any external API keys, making it easy to run and test locally. All external integrations are optional and the app gracefully handles missing configurations.