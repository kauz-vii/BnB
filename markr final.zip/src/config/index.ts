// Configuration for Markr application
export const config = {
  googleMaps: {
    apiKey: (() => {
      try {
        // Check localStorage first for development
        const localKey = typeof window !== 'undefined' ? localStorage.getItem('MARKR_GOOGLE_MAPS_API_KEY') : null;
        if (localKey && localKey !== 'DEMO_MODE') {
          return localKey;
        }
        
        // Check environment variables
        const envKey = import.meta.env?.VITE_GOOGLE_MAPS_API_KEY;
        if (envKey && envKey !== 'YOUR_GOOGLE_MAPS_API_KEY' && envKey !== 'DEMO_MODE') {
          return envKey;
        }
        
        return "DEMO_MODE";
      } catch (error) {
        return "DEMO_MODE";
      }
    })(),
  },
  supabase: {
    url: (() => {
      try {
        return import.meta.env?.VITE_SUPABASE_URL || "";
      } catch (error) {
        return "";
      }
    })(),
    anonKey: (() => {
      try {
        return import.meta.env?.VITE_SUPABASE_ANON_KEY || "";
      } catch (error) {
        return "";
      }
    })(),
  },
  app: {
    name: "Markr",
    version: "1.0.0",
    defaultLocation: {
      // Center of India
      lat: 20.5937,
      lng: 78.9629,
      zoom: 5
    }
  },
  backend: {
    baseUrl: "https://wander-xp-5fcbc584.base44.app",
    apiVersion: "v1"
  }
};

export default config;