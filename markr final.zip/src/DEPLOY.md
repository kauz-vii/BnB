# 🚀 TravelMapX Backend Deployment

## Quick Start

Deploy your TravelMapX backend in 3 simple steps:

### 1. Make Script Executable
```bash
chmod +x deploy-backend.sh
```

### 2. Run Deployment
```bash
./deploy-backend.sh
```

### 3. Test Backend
Open your app and click "Backend Test" in the sidebar to verify all endpoints are working.

## What Gets Deployed

✅ **Clean Function Structure**: Single `travel-api` function  
✅ **All API Endpoints**: Auth, maps, leaderboard, location, directions  
✅ **Database Tables**: KV store for user data  
✅ **Health Monitoring**: Built-in health check endpoint  

## Troubleshooting

### 403 Permission Error
- Ensure you're logged in: `supabase login`
- Link your project: `supabase link --project-ref YOUR_PROJECT_ID`
- Check your project has Edge Functions enabled

### Function Not Responding
- Wait 30 seconds for cold start
- Check logs: `supabase functions logs travel-api`
- Test health endpoint manually

### Database Errors
- Run: `supabase db reset --linked`
- Check migration files exist

## Manual Deployment

If the script doesn't work, deploy manually:

```bash
# Deploy function
supabase functions deploy travel-api

# Setup database
supabase db reset --linked

# Test health endpoint
curl https://YOUR_PROJECT_ID.supabase.co/functions/v1/travel-api/health
```

## API Endpoints

Once deployed, your backend provides:

- **Authentication**: User signup, OAuth profiles
- **Maps**: CRUD operations with permissions  
- **Leaderboard**: Real-time rankings by XP, maps, places
- **Location**: Mock GPS coordinates for testing
- **Directions**: Route planning between coordinates
- **Search**: Full-text search across content
- **Activity**: Social feed of user actions

## Success Indicators

✅ Health endpoint returns `{"status": "healthy"}`  
✅ Backend Test component shows all green checks  
✅ App functions without API errors  
✅ User signup and map creation work  

Your TravelMapX backend is production-ready! 🗺️✨