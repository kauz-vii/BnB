# TravelMapX Backend Setup

## Quick Start

The easiest way to set up your TravelMapX backend is to use our automated setup script:

```bash
# Make the setup script executable
chmod +x scripts/setup-backend.sh

# Run the setup
./scripts/setup-backend.sh
```

This script will:
1. ✅ Verify Supabase CLI installation
2. ✅ Check project connection
3. 📊 Set up database tables
4. 🚀 Deploy the Edge Function
5. 🧪 Test all endpoints

## Manual Setup

If you prefer to set up manually:

### 1. Install Supabase CLI
```bash
npm install -g supabase
```

### 2. Connect to Your Project
```bash
supabase login
supabase link --project-ref YOUR_PROJECT_ID
```

### 3. Set Up Database
```bash
supabase db reset --linked
```

### 4. Deploy Function
```bash
supabase functions deploy make-server-52837870
```

### 5. Test Deployment
```bash
curl https://YOUR_PROJECT_ID.supabase.co/functions/v1/make-server-52837870/health
```

## Troubleshooting

### 403 Deployment Error
This usually means:
- **Project not linked**: Run `supabase link --project-ref YOUR_PROJECT_ID`
- **Wrong permissions**: Make sure you have admin access to the Supabase project
- **Edge Functions not enabled**: Check your Supabase plan includes Edge Functions

### Function Not Responding
- Check logs: `supabase functions logs make-server-52837870`
- Verify database migration: `supabase db reset --linked`
- Wait a few minutes for cold start

### Backend Test Component
Use the built-in Backend Test component in your app:
1. Open your TravelMapX app
2. Navigate to the Backend Test section
3. Run connectivity tests to verify all endpoints

## API Documentation

Once deployed, your backend provides these endpoints:

- **Authentication**: User signup, OAuth, profile management
- **Maps**: Create, read, update, delete maps with full permissions
- **Markers**: Add POIs to maps with categories and metadata
- **Leaderboard**: Real-time rankings by XP, maps, places, distance
- **Location**: Mock GPS coordinates for testing
- **Directions**: Route planning between coordinates
- **Search**: Full-text search across maps, users, markers
- **Activity**: Social feed of user actions
- **File Upload**: Avatar and map image management

## Support

If you encounter issues:

1. **Check the setup script output** for specific error messages
2. **View function logs**: `supabase functions logs make-server-52837870`
3. **Test individual endpoints** using the Backend Test component
4. **Verify environment variables** in your Supabase dashboard

The backend includes comprehensive error handling and logging to help diagnose any issues.