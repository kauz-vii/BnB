import { createClient } from '@supabase/supabase-js';
import { projectId, publicAnonKey } from './info';

export const supabase = createClient(
  `https://${projectId}.supabase.co`,
  publicAnonKey
);

// API helper functions - Using existing Markr backend
const API_BASE = 'https://wander-xp-5fcbc584.base44.app';

export async function apiCall(endpoint: string, options: RequestInit = {}) {
  const session = await supabase.auth.getSession();
  const token = session.data.session?.access_token || publicAnonKey;

  const response = await fetch(`${API_BASE}${endpoint}`, {
    ...options,
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${token}`,
      ...options.headers,
    },
  });

  if (!response.ok) {
    const error = await response.json().catch(() => ({ error: 'Request failed' }));
    throw new Error(error.error || `HTTP ${response.status}: ${response.statusText}`);
  }

  return response.json();
}

// File upload helper
export async function uploadFile(file: File, type: 'avatar' | 'map_image') {
  const session = await supabase.auth.getSession();
  const token = session.data.session?.access_token;
  
  if (!token) {
    throw new Error('Authentication required for file upload');
  }
  
  const formData = new FormData();
  formData.append('file', file);
  formData.append('type', type);
  
  const response = await fetch(`${API_BASE}/upload`, {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${token}`,
    },
    body: formData,
  });
  
  if (!response.ok) {
    const error = await response.json().catch(() => ({ error: 'Upload failed' }));
    throw new Error(error.error || 'Upload failed');
  }
  
  return response.json();
}

// OAuth helper functions
export async function signInWithOAuth(provider: 'google' | 'github' | 'discord') {
  try {
    const { data, error } = await supabase.auth.signInWithOAuth({
      provider,
      options: {
        redirectTo: `${window.location.origin}`,
        queryParams: {
          access_type: 'offline',
          prompt: 'consent',
        },
      },
    });
    
    if (error) throw error;
    return { data, error: null };
  } catch (error: any) {
    return { data: null, error };
  }
}

// Real-time subscriptions helper
export function subscribeToUserProfile(userId: string, callback: (profile: any) => void) {
  // Since we're using KV store, we'll implement a polling mechanism
  // In a real-time database, this would use actual subscriptions
  let intervalId: NodeJS.Timeout;
  
  const pollProfile = async () => {
    try {
      const profile = await apiCall('/profile');
      callback(profile);
    } catch (error) {
      console.error('Error polling profile:', error);
    }
  };
  
  // Poll every 30 seconds
  intervalId = setInterval(pollProfile, 30000);
  
  // Initial fetch
  pollProfile();
  
  // Return unsubscribe function
  return () => {
    if (intervalId) {
      clearInterval(intervalId);
    }
  };
}

// Activity feed subscription
export function subscribeToActivity(callback: (activities: any[]) => void) {
  let intervalId: NodeJS.Timeout;
  
  const pollActivity = async () => {
    try {
      const { activities } = await apiCall('/activity?limit=20');
      callback(activities);
    } catch (error) {
      console.error('Error polling activity:', error);
    }
  };
  
  // Poll every 60 seconds
  intervalId = setInterval(pollActivity, 60000);
  
  // Initial fetch
  pollActivity();
  
  return () => {
    if (intervalId) {
      clearInterval(intervalId);
    }
  };
}

// Search helper
export async function searchContent(query: string, type: 'all' | 'maps' | 'users' = 'all', limit = 20) {
  if (!query || query.length < 2) {
    throw new Error('Search query must be at least 2 characters');
  }
  
  return apiCall(`/search?q=${encodeURIComponent(query)}&type=${type}&limit=${limit}`);
}