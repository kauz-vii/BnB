# Google Maps API Setup for Markr

This guide will help you set up Google Maps integration for the Markr application.

## Why is this needed?

Google Maps provides interactive mapping functionality including:
- Interactive map viewing and navigation
- Marker placement and management  
- Directions and routing
- Location services
- Custom map styling

## Quick Setup (Development)

1. **Access Setup Tool**: Navigate to the "Google Maps Setup" section in the sidebar, or visit `[your-app-url]?setup=maps`

2. **Get API Key**: Click "Open Console" to go to Google Cloud Console

3. **Configure Key**: Follow the step-by-step instructions in the setup tool

4. **Test**: Enter your API key in the setup form to validate and activate

## Production Setup

### 1. Get Google Maps API Key

1. Go to [Google Cloud Console](https://console.cloud.google.com/)
2. Create a new project or select existing project
3. Enable the **Maps JavaScript API**:
   - Go to "APIs & Services" > "Library"
   - Search for "Maps JavaScript API"
   - Click "Enable"

4. Create API Key:
   - Go to "APIs & Services" > "Credentials"  
   - Click "Create Credentials" > "API Key"
   - Copy the generated key

### 2. Secure Your API Key

**Important**: Restrict your API key for security:

1. In Google Cloud Console, go to "Credentials"
2. Click on your API key
3. Under "API restrictions", select "Restrict key"
4. Choose "Maps JavaScript API"
5. Under "Website restrictions", add your domain(s)

### 3. Set Environment Variable

Add to your `.env.local` file:
```
VITE_GOOGLE_MAPS_API_KEY=your_actual_api_key_here
```

Or set as environment variable in your deployment platform.

## API Key Costs

- Google Maps provides a generous free tier
- $200 monthly credit (covers ~28,000 map loads)
- Pay-as-you-go pricing after free tier
- Most small to medium applications stay within free limits

## Security Best Practices

1. **Never commit API keys to version control**
2. **Always use domain restrictions in production**
3. **Monitor usage in Google Cloud Console**
4. **Set up billing alerts to avoid unexpected charges**
5. **Use environment variables for all deployments**

## Troubleshooting

### Common Issues

**"This page can't load Google Maps correctly"**
- Check that your API key is valid
- Ensure Maps JavaScript API is enabled
- Verify domain restrictions allow your current domain

**Maps not loading in development**
- Check browser console for errors
- Verify API key is set in environment variables or localStorage
- Ensure no ad blockers are interfering

**Billing/quota issues**
- Check Google Cloud Console for quota status
- Verify billing account is set up if needed
- Monitor daily usage in the console

### Getting Help

1. Check the browser console for specific error messages
2. Verify API key permissions in Google Cloud Console
3. Use the in-app setup tool to validate your configuration
4. Check Google Maps Platform documentation

## Development Mode

For development convenience, Markr provides:

- **In-app setup tool** for quick API key configuration
- **localStorage storage** for temporary API key storage  
- **Fallback map display** when no API key is configured
- **Clear error messages** and setup guidance

The application will work in "demo mode" without an API key, but with limited functionality.