# TravelMapX Backend Integration Guide

This guide explains how to use the complete backend API system for TravelMapX.

## Overview

The TravelMapX backend provides a comprehensive API for:
- User authentication and profiles
- Map and marker management
- Real-time leaderboards
- Activity feeds
- Search functionality
- File uploads
- Location services
- Route planning

## Architecture

### Backend Stack
- **Runtime**: Deno with Hono framework
- **Database**: Supabase KV Store
- **Authentication**: Supabase Auth
- **Storage**: Supabase Storage
- **Real-time**: Polling-based updates

### API Endpoints

All endpoints are prefixed with `/make-server-52837870/`

#### Authentication
- `POST /auth/signup` - User registration
- `POST /auth/oauth` - OAuth provider setup
- `POST /auth/oauth-profile` - OAuth profile creation

#### User Profiles
- `GET /profile` - Get user profile
- `PUT /profile` - Update user profile
- `GET /profile/stats` - Get user statistics

#### Maps
- `POST /maps` - Create a new map
- `GET /maps` - List maps with filtering
- `GET /maps/:id` - Get specific map
- `PUT /maps/:id` - Update map
- `DELETE /maps/:id` - Delete map
- `POST /maps/:id/like` - Like/unlike map

#### Markers
- `POST /maps/:id/markers` - Add marker to map
- `PUT /maps/:mapId/markers/:markerId` - Update marker
- `DELETE /maps/:mapId/markers/:markerId` - Delete marker

#### Leaderboard
- `GET /leaderboard` - Get leaderboard rankings

#### Location & Directions
- `GET /user-location` - Get user location (mock GPS)
- `GET /directions` - Get route between two points

#### Activity & Search
- `GET /activity` - Get activity feed
- `GET /search` - Search maps, users, and markers

#### File Upload
- `POST /upload` - Upload files (avatars, map images)

#### Health Check
- `GET /health` - Server health status

## Usage Examples

### 1. Using API Helpers

```typescript
import { travelMapAPI } from '../api/backend-endpoints';

// Create a map
const newMap = await travelMapAPI.maps.create({
  title: "My Travel Map",
  description: "Places I've visited",
  visibility: "public",
  tags: ["travel", "vacation"]
});

// Get leaderboard
const leaderboard = await travelMapAPI.leaderboard.get({
  type: 'xp',
  limit: 10
});

// Add a marker
const marker = await travelMapAPI.markers.create(mapId, {
  category: 'food',
  title: 'Great Restaurant',
  notes: 'Amazing pasta!',
  lat: 40.7128,
  lng: -74.0060
});
```

### 2. Using React Hooks

```typescript
import { useMapsAPI, useLeaderboardAPI, useLocationAPI } from '../hooks/useAPI';

function MyComponent() {
  const { createMap, loading: mapLoading } = useMapsAPI();
  const { getLeaderboard, data: leaderboard } = useLeaderboardAPI();
  const { getUserLocation, data: location } = useLocationAPI();

  const handleCreateMap = async () => {
    await createMap({
      title: "New Map",
      visibility: "public"
    });
  };

  // Component JSX...
}
```

### 3. Authentication Integration

```typescript
import { useAuth } from '../hooks/useAuth';

function AuthComponent() {
  const { signUp, signIn, signInWithProvider } = useAuth();

  const handleSignUp = async () => {
    const { data, error } = await signUp(
      'user@example.com',
      'password123',
      'John Doe'
    );
    if (error) {
      console.error('Signup failed:', error);
    }
  };

  const handleOAuthSignIn = async () => {
    const { data, error } = await signInWithProvider('google');
    if (error) {
      console.error('OAuth failed:', error);
    }
  };
}
```

## Data Models

### User Profile
```typescript
interface UserProfile {
  id: string;
  name: string;
  email: string;
  level: number;
  xp: number;
  totalDistance: number;
  placesExplored: number;
  mapsContributed: number;
  achievements: string[];
  badges: string[];
  preferences: {
    theme: 'light' | 'dark';
    notifications: boolean;
    privacy: 'public' | 'private';
  };
  stats: {
    loginStreak: number;
    lastLogin: string;
    totalSessions: number;
  };
}
```

### Map Data
```typescript
interface MapData {
  id: string;
  title: string;
  description?: string;
  visibility: 'public' | 'private' | 'unlisted';
  tags: string[];
  centerCoords: { lat: number; lng: number };
  createdBy: string;
  markers: MarkerData[];
  stats: {
    views: number;
    likes: number;
    forks: number;
  };
}
```

### Marker Data
```typescript
interface MarkerData {
  id: string;
  category: 'food' | 'toilets' | 'attractions' | 'notes' | 'transport' | 'accommodation' | 'shopping';
  title: string;
  notes?: string;
  lat: number;
  lng: number;
  address?: string;
  tags: string[];
  createdBy: string;
}
```

## Features

### Gamification System
- **XP Points**: Users earn XP for various actions
  - Creating a map: +50 XP
  - Adding a marker: +10 XP
  - Map being liked: +5 XP
- **Levels**: Calculated from XP (Level = floor(XP/100) + 1)
- **Achievements**: Earned for milestones
- **Leaderboards**: Rankings by XP, maps created, places explored

### Real-time Updates
- Activity feeds with user actions
- Leaderboard updates
- Map interaction tracking

### Search & Discovery
- Full-text search across maps, users, markers
- Tag-based filtering
- Popularity sorting

### File Management
- Avatar uploads
- Map image attachments
- Automatic file optimization

### Mock Services
- **GPS Location**: Returns randomized realistic coordinates
- **Routing**: Calculates basic routes with distance/duration
- **Geocoding**: Basic address resolution

## Error Handling

The API uses standard HTTP status codes:
- `200` - Success
- `400` - Bad Request (validation errors)
- `401` - Unauthorized (authentication required)
- `403` - Forbidden (permission denied)
- `404` - Not Found
- `500` - Internal Server Error

Error responses follow this format:
```json
{
  "error": "Error message description"
}
```

## Security

### Authentication
- JWT-based authentication via Supabase Auth
- OAuth providers: Google, GitHub, Discord
- Automatic session management

### Authorization
- User-based access control
- Private/public map visibility
- Owner-only editing permissions

### Data Validation
- Input sanitization
- Coordinate validation
- File type/size restrictions

## Performance

### Optimization Features
- Pagination for large datasets
- Efficient key-value storage
- Automatic data cleanup
- Request throttling

### Monitoring
- Health check endpoint
- Error logging
- Activity tracking

## Getting Started

1. **Set up Supabase**: Configure your Supabase project with the required environment variables
2. **Deploy server**: Deploy the Hono server to Supabase Edge Functions
3. **Configure auth**: Set up OAuth providers in Supabase dashboard
4. **Test endpoints**: Use the health check endpoint to verify deployment

## Environment Variables

Required environment variables:
- `SUPABASE_URL` - Your Supabase project URL
- `SUPABASE_SERVICE_ROLE_KEY` - Service role key for server operations

## Support

For issues or questions:
1. Check the health endpoint: `/make-server-52837870/health`
2. Review server logs in Supabase dashboard
3. Verify environment variables are set correctly
4. Test with sample API calls using the provided helpers