import { ReactNode } from 'react';
import { AuthProvider } from './AuthContext';
import { QuestionsProvider } from './QuestionsContext';
import { AnswersProvider } from './AnswersContext';
import { VotesProvider } from './VotesContext';
import { TagsProvider } from './TagsContext';
import { NotificationsProvider } from './NotificationsContext';

interface DataProviderProps {
  children: ReactNode;
}

export function DataProvider({ children }: DataProviderProps) {
  return (
    <AuthProvider>
      <TagsProvider>
        <QuestionsProvider>
          <AnswersProvider>
            <VotesProvider>
              <NotificationsProvider>
                {children}
              </NotificationsProvider>
            </VotesProvider>
          </AnswersProvider>
        </QuestionsProvider>
      </TagsProvider>
    </AuthProvider>
  );
}

// Export all contexts for easy access
export { useAuth } from './AuthContext';
export { useQuestions } from './QuestionsContext';
export { useAnswers } from './AnswersContext';
export { useVotes } from './VotesContext';
export { useTags } from './TagsContext';
export { useNotifications } from './NotificationsContext';