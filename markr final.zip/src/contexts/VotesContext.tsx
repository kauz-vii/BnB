import { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { Vote } from '../types';

interface VotesContextType {
  votes: Vote[];
  getUserVote: (userId: string, questionId?: string, answerId?: string) => Vote | null;
  castVote: (userId: string, type: 'UP' | 'DOWN', questionId?: string, answerId?: string) => Promise<void>;
  removeVote: (userId: string, questionId?: string, answerId?: string) => void;
  getVoteScore: (questionId?: string, answerId?: string) => number;
  isLoading: boolean;
}

const VotesContext = createContext<VotesContextType | null>(null);

export function useVotes() {
  const context = useContext(VotesContext);
  if (!context) throw new Error('useVotes must be used within VotesProvider');
  return context;
}

interface VotesProviderProps {
  children: ReactNode;
}

export function VotesProvider({ children }: VotesProviderProps) {
  const [votes, setVotes] = useState<Vote[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  // Initialize mock votes data
  useEffect(() => {
    const loadVotes = () => {
      // Check for stored votes
      const storedVotes = localStorage.getItem('qa_votes');
      if (storedVotes) {
        const parsed = JSON.parse(storedVotes);
        // Convert date strings back to Date objects
        const votesWithDates = parsed.map((v: any) => ({
          ...v,
          createdAt: new Date(v.createdAt)
        }));
        setVotes(votesWithDates);
      } else {
        // Initialize with mock data
        const mockVotes: Vote[] = [
          // Question votes
          { id: 'v1', userId: '1', questionId: 'q1', type: 'UP', createdAt: new Date(Date.now() - 3600000) },
          { id: 'v2', userId: '3', questionId: 'q1', type: 'UP', createdAt: new Date(Date.now() - 3300000) },
          { id: 'v3', userId: '4', questionId: 'q1', type: 'UP', createdAt: new Date(Date.now() - 3000000) },
          { id: 'v4', userId: '5', questionId: 'q1', type: 'UP', createdAt: new Date(Date.now() - 2700000) },
          
          { id: 'v5', userId: '1', questionId: 'q2', type: 'UP', createdAt: new Date(Date.now() - 7200000) },
          { id: 'v6', userId: '2', questionId: 'q2', type: 'UP', createdAt: new Date(Date.now() - 6900000) },
          { id: 'v7', userId: '4', questionId: 'q2', type: 'UP', createdAt: new Date(Date.now() - 6600000) },
          
          { id: 'v8', userId: '1', questionId: 'q3', type: 'UP', createdAt: new Date(Date.now() - 10800000) },
          { id: 'v9', userId: '2', questionId: 'q3', type: 'UP', createdAt: new Date(Date.now() - 10500000) },
          { id: 'v10', userId: '3', questionId: 'q3', type: 'UP', createdAt: new Date(Date.now() - 10200000) },
          { id: 'v11', userId: '5', questionId: 'q3', type: 'UP', createdAt: new Date(Date.now() - 9900000) },
          
          // Answer votes
          { id: 'v12', userId: '1', answerId: 'a1', type: 'UP', createdAt: new Date(Date.now() - 1800000) },
          { id: 'v13', userId: '2', answerId: 'a1', type: 'UP', createdAt: new Date(Date.now() - 1500000) },
          { id: 'v14', userId: '4', answerId: 'a1', type: 'UP', createdAt: new Date(Date.now() - 1200000) },
          { id: 'v15', userId: '5', answerId: 'a1', type: 'UP', createdAt: new Date(Date.now() - 900000) },
          
          { id: 'v16', userId: '1', answerId: 'a2', type: 'UP', createdAt: new Date(Date.now() - 900000) },
          { id: 'v17', userId: '3', answerId: 'a2', type: 'UP', createdAt: new Date(Date.now() - 600000) },
          
          { id: 'v18', userId: '2', answerId: 'a3', type: 'UP', createdAt: new Date(Date.now() - 5400000) },
          { id: 'v19', userId: '3', answerId: 'a3', type: 'UP', createdAt: new Date(Date.now() - 5100000) },
          { id: 'v20', userId: '4', answerId: 'a3', type: 'UP', createdAt: new Date(Date.now() - 4800000) },
          
          { id: 'v21', userId: '1', answerId: 'a4', type: 'UP', createdAt: new Date(Date.now() - 3600000) },
          { id: 'v22', userId: '3', answerId: 'a4', type: 'UP', createdAt: new Date(Date.now() - 3300000) },
          { id: 'v23', userId: '4', answerId: 'a4', type: 'UP', createdAt: new Date(Date.now() - 3000000) },
          { id: 'v24', userId: '5', answerId: 'a4', type: 'UP', createdAt: new Date(Date.now() - 2700000) }
        ];

        setVotes(mockVotes);
        localStorage.setItem('qa_votes', JSON.stringify(mockVotes));
      }
      setIsLoading(false);
    };

    loadVotes();
  }, []);

  // Save votes to localStorage whenever votes change
  useEffect(() => {
    if (votes.length > 0) {
      localStorage.setItem('qa_votes', JSON.stringify(votes));
    }
  }, [votes]);

  const getUserVote = (userId: string, questionId?: string, answerId?: string): Vote | null => {
    return votes.find(v => 
      v.userId === userId && 
      v.questionId === questionId && 
      v.answerId === answerId
    ) || null;
  };

  const castVote = async (userId: string, type: 'UP' | 'DOWN', questionId?: string, answerId?: string): Promise<void> => {
    // Check if user has already voted on this item
    const existingVote = getUserVote(userId, questionId, answerId);
    
    if (existingVote) {
      if (existingVote.type === type) {
        // Same vote type - remove the vote (toggle off)
        removeVote(userId, questionId, answerId);
        return;
      } else {
        // Different vote type - update the existing vote
        setVotes(prev => prev.map(v => 
          v.id === existingVote.id 
            ? { ...v, type, createdAt: new Date() }
            : v
        ));
        return;
      }
    }

    // Create new vote
    const newVote: Vote = {
      id: `v${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
      userId,
      questionId,
      answerId,
      type,
      createdAt: new Date()
    };

    setVotes(prev => [...prev, newVote]);
  };

  const removeVote = (userId: string, questionId?: string, answerId?: string) => {
    setVotes(prev => prev.filter(v => !(
      v.userId === userId && 
      v.questionId === questionId && 
      v.answerId === answerId
    )));
  };

  const getVoteScore = (questionId?: string, answerId?: string): number => {
    const relevantVotes = votes.filter(v => 
      v.questionId === questionId && v.answerId === answerId
    );
    
    return relevantVotes.reduce((score, vote) => {
      return score + (vote.type === 'UP' ? 1 : -1);
    }, 0);
  };

  const value: VotesContextType = {
    votes,
    getUserVote,
    castVote,
    removeVote,
    getVoteScore,
    isLoading
  };

  return (
    <VotesContext.Provider value={value}>
      {children}
    </VotesContext.Provider>
  );
}