import { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { Question, FeedFilters } from '../types';
import { getUserById } from './AuthContext';

interface QuestionsContextType {
  questions: Question[];
  getQuestionById: (id: string) => Question | null;
  createQuestion: (title: string, body: string, tags: string[], authorId: string) => Promise<Question>;
  updateQuestion: (id: string, updates: Partial<Question>) => void;
  deleteQuestion: (id: string) => void;
  getQuestionsByAuthor: (authorId: string) => Question[];
  getFilteredQuestions: (filters: FeedFilters) => Question[];
  incrementViews: (id: string) => void;
  closeQuestion: (id: string) => void;
  isLoading: boolean;
}

const QuestionsContext = createContext<QuestionsContextType | null>(null);

export function useQuestions() {
  const context = useContext(QuestionsContext);
  if (!context) throw new Error('useQuestions must be used within QuestionsProvider');
  return context;
}

interface QuestionsProviderProps {
  children: ReactNode;
}

export function QuestionsProvider({ children }: QuestionsProviderProps) {
  const [questions, setQuestions] = useState<Question[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  // Initialize mock questions data
  useEffect(() => {
    const loadQuestions = () => {
      // Check for stored questions
      const storedQuestions = localStorage.getItem('qa_questions');
      if (storedQuestions) {
        const parsed = JSON.parse(storedQuestions);
        // Convert date strings back to Date objects
        const questionsWithDates = parsed.map((q: any) => ({
          ...q,
          createdAt: new Date(q.createdAt),
          updatedAt: new Date(q.updatedAt),
          author: getUserById(q.authorId) || q.author
        }));
        setQuestions(questionsWithDates);
      } else {
        // Initialize with mock data
        const mockQuestions: Question[] = [
          {
            id: 'q1',
            title: 'How to implement user authentication with JWT tokens in a React application?',
            body: `I am trying to build a secure authentication system for my React app using JWT tokens. What are the best practices for storing tokens securely and managing user sessions?

Here's what I've tried so far:

1. Storing tokens in localStorage
2. Using httpOnly cookies  
3. Implementing refresh token rotation

**My current implementation:**

\`\`\`javascript
const login = async (credentials) => {
  const response = await fetch('/api/auth/login', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(credentials)
  });
  const { token } = await response.json();
  localStorage.setItem('token', token);
};
\`\`\`

However, I'm concerned about XSS attacks and token security. What would be the recommended approach?`,
            authorId: '2',
            author: getUserById('2')!,
            tags: ['react', 'javascript', 'authentication', 'jwt', 'security'],
            createdAt: new Date(Date.now() - 3600000), // 1 hour ago
            updatedAt: new Date(Date.now() - 3600000),
            score: 23,
            hotRank: 0.95,
            acceptedAnswerId: null,
            answers: [],
            votes: [],
            views: 456,
            isClosed: false
          },
          {
            id: 'q2',
            title: 'Best practices for API error handling in Node.js?',
            body: `What are the most effective strategies for handling errors in a Node.js REST API? Should I use middleware or handle errors in each route?

I'm particularly interested in:
- Global error handling patterns
- Custom error classes
- Error logging and monitoring
- Client-friendly error responses

My current setup is using Express.js with MongoDB.`,
            authorId: '3',
            author: getUserById('3')!,
            tags: ['node.js', 'express', 'error-handling', 'api', 'backend'],
            createdAt: new Date(Date.now() - 7200000), // 2 hours ago
            updatedAt: new Date(Date.now() - 7200000),
            score: 15,
            hotRank: 0.87,
            acceptedAnswerId: null,
            answers: [],
            votes: [],
            views: 234,
            isClosed: false
          },
          {
            id: 'q3',
            title: 'How to optimize React component re-renders?',
            body: `My React application is experiencing performance issues due to unnecessary re-renders. What techniques can I use to optimize component performance?

**Current issues:**
- Large lists rendering slowly
- Parent components re-rendering all children
- Context causing widespread re-renders

**What I've tried:**
- React.memo()
- useMemo() and useCallback()
- Code splitting

Looking for more advanced optimization techniques and best practices.`,
            authorId: '4',
            author: getUserById('4')!,
            tags: ['react', 'performance', 'optimization', 'hooks'],
            createdAt: new Date(Date.now() - 10800000), // 3 hours ago
            updatedAt: new Date(Date.now() - 5400000), // updated 1.5 hours ago
            score: 42,
            hotRank: 0.92,
            acceptedAnswerId: null,
            answers: [],
            votes: [],
            views: 1205,
            isClosed: false
          },
          {
            id: 'q4',
            title: 'Database design for a social media platform',
            body: `I need advice on designing a scalable database schema for a social media application. What are the key considerations for user relationships, posts, and feeds?

**Requirements:**
- Support for millions of users
- Real-time feeds
- Complex relationships (friends, followers, groups)
- Post interactions (likes, comments, shares)

Should I use SQL or NoSQL? What about hybrid approaches?`,
            authorId: '5',
            author: getUserById('5')!,
            tags: ['database', 'postgresql', 'schema-design', 'scalability'],
            createdAt: new Date(Date.now() - 14400000), // 4 hours ago
            updatedAt: new Date(Date.now() - 14400000),
            score: 8,
            hotRank: 0.73,
            acceptedAnswerId: null,
            answers: [],
            votes: [],
            views: 156,
            isClosed: false
          },
          {
            id: 'q5',
            title: 'TypeScript generics with React components',
            body: `I'm struggling to understand how to properly use TypeScript generics with React components. Can someone explain with practical examples?

Specifically, I want to create a generic data table component that can work with different data types while maintaining type safety.`,
            authorId: '1',
            author: getUserById('1')!,
            tags: ['typescript', 'react', 'generics', 'components'],
            createdAt: new Date(Date.now() - 21600000), // 6 hours ago
            updatedAt: new Date(Date.now() - 21600000),
            score: 12,
            hotRank: 0.68,
            acceptedAnswerId: null,
            answers: [],
            votes: [],
            views: 89,
            isClosed: false
          }
        ];

        setQuestions(mockQuestions);
        localStorage.setItem('qa_questions', JSON.stringify(mockQuestions));
      }
      setIsLoading(false);
    };

    loadQuestions();
  }, []);

  // Save questions to localStorage whenever questions change
  useEffect(() => {
    if (questions.length > 0) {
      localStorage.setItem('qa_questions', JSON.stringify(questions));
    }
  }, [questions]);

  const getQuestionById = (id: string): Question | null => {
    return questions.find(q => q.id === id) || null;
  };

  const createQuestion = async (title: string, body: string, tags: string[], authorId: string): Promise<Question> => {
    const author = getUserById(authorId);
    if (!author) throw new Error('Author not found');

    const newQuestion: Question = {
      id: `q${Date.now()}`,
      title,
      body,
      authorId,
      author,
      tags,
      createdAt: new Date(),
      updatedAt: new Date(),
      score: 0,
      hotRank: 0.5,
      acceptedAnswerId: null,
      answers: [],
      votes: [],
      views: 0,
      isClosed: false
    };

    setQuestions(prev => [newQuestion, ...prev]);
    return newQuestion;
  };

  const updateQuestion = (id: string, updates: Partial<Question>) => {
    setQuestions(prev => prev.map(q => 
      q.id === id 
        ? { ...q, ...updates, updatedAt: new Date() }
        : q
    ));
  };

  const deleteQuestion = (id: string) => {
    setQuestions(prev => prev.filter(q => q.id !== id));
  };

  const getQuestionsByAuthor = (authorId: string): Question[] => {
    return questions.filter(q => q.authorId === authorId);
  };

  const getFilteredQuestions = (filters: FeedFilters): Question[] => {
    let filtered = [...questions];

    // Filter by tags
    if (filters.tags.length > 0) {
      filtered = filtered.filter(q => 
        filters.tags.some(tag => q.tags.includes(tag))
      );
    }

    // Filter by time range
    if (filters.timeRange && filters.timeRange !== 'all') {
      const now = new Date();
      let cutoffDate = new Date();
      
      switch (filters.timeRange) {
        case 'today':
          cutoffDate.setHours(0, 0, 0, 0);
          break;
        case 'week':
          cutoffDate.setDate(now.getDate() - 7);
          break;
        case 'month':
          cutoffDate.setMonth(now.getMonth() - 1);
          break;
      }
      
      filtered = filtered.filter(q => q.createdAt >= cutoffDate);
    }

    // Sort by specified criteria
    switch (filters.sort) {
      case 'new':
        filtered.sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
        break;
      case 'hot':
        filtered.sort((a, b) => b.hotRank - a.hotRank);
        break;
      case 'unanswered':
        filtered = filtered.filter(q => q.answers.length === 0);
        filtered.sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
        break;
      case 'trending':
        // Sort by recent activity and score
        filtered.sort((a, b) => {
          const aActivity = Math.max(a.createdAt.getTime(), a.updatedAt.getTime());
          const bActivity = Math.max(b.createdAt.getTime(), b.updatedAt.getTime());
          return (b.score * 0.3 + bActivity * 0.7) - (a.score * 0.3 + aActivity * 0.7);
        });
        break;
      default:
        filtered.sort((a, b) => b.hotRank - a.hotRank);
    }

    return filtered;
  };

  const incrementViews = (id: string) => {
    setQuestions(prev => prev.map(q => 
      q.id === id 
        ? { ...q, views: q.views + 1 }
        : q
    ));
  };

  const closeQuestion = (id: string) => {
    setQuestions(prev => prev.map(q => 
      q.id === id 
        ? { ...q, isClosed: true, updatedAt: new Date() }
        : q
    ));
  };

  const value: QuestionsContextType = {
    questions,
    getQuestionById,
    createQuestion,
    updateQuestion,
    deleteQuestion,
    getQuestionsByAuthor,
    getFilteredQuestions,
    incrementViews,
    closeQuestion,
    isLoading
  };

  return (
    <QuestionsContext.Provider value={value}>
      {children}
    </QuestionsContext.Provider>
  );
}