import { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { Tag } from '../types';

interface TagsContextType {
  tags: Tag[];
  getTagByName: (name: string) => Tag | null;
  createTag: (name: string) => Tag;
  getPopularTags: (limit?: number) => Tag[];
  searchTags: (query: string) => Tag[];
  updateTagCount: (tagName: string) => void;
  isLoading: boolean;
}

const TagsContext = createContext<TagsContextType | null>(null);

export function useTags() {
  const context = useContext(TagsContext);
  if (!context) throw new Error('useTags must be used within TagsProvider');
  return context;
}

interface TagsProviderProps {
  children: ReactNode;
}

export function TagsProvider({ children }: TagsProviderProps) {
  const [tags, setTags] = useState<Tag[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  // Initialize mock tags data
  useEffect(() => {
    const loadTags = () => {
      // Check for stored tags
      const storedTags = localStorage.getItem('qa_tags');
      if (storedTags) {
        const parsed = JSON.parse(storedTags);
        setTags(parsed);
      } else {
        // Initialize with mock data based on existing questions
        const mockTags: Tag[] = [
          { id: 't1', name: 'javascript', questionsCount: 1234 },
          { id: 't2', name: 'react', questionsCount: 987 },
          { id: 't3', name: 'python', questionsCount: 856 },
          { id: 't4', name: 'typescript', questionsCount: 743 },
          { id: 't5', name: 'node.js', questionsCount: 654 },
          { id: 't6', name: 'authentication', questionsCount: 432 },
          { id: 't7', name: 'jwt', questionsCount: 321 },
          { id: 't8', name: 'security', questionsCount: 567 },
          { id: 't9', name: 'express', questionsCount: 445 },
          { id: 't10', name: 'error-handling', questionsCount: 234 },
          { id: 't11', name: 'api', questionsCount: 789 },
          { id: 't12', name: 'backend', questionsCount: 456 },
          { id: 't13', name: 'performance', questionsCount: 378 },
          { id: 't14', name: 'optimization', questionsCount: 289 },
          { id: 't15', name: 'hooks', questionsCount: 445 },
          { id: 't16', name: 'database', questionsCount: 567 },
          { id: 't17', name: 'postgresql', questionsCount: 323 },
          { id: 't18', name: 'schema-design', questionsCount: 145 },
          { id: 't19', name: 'scalability', questionsCount: 234 },
          { id: 't20', name: 'generics', questionsCount: 167 },
          { id: 't21', name: 'components', questionsCount: 445 },
          { id: 't22', name: 'html', questionsCount: 678 },
          { id: 't23', name: 'css', questionsCount: 567 },
          { id: 't24', name: 'sql', questionsCount: 456 },
          { id: 't25', name: 'testing', questionsCount: 345 },
          { id: 't26', name: 'deployment', questionsCount: 234 },
          { id: 't27', name: 'docker', questionsCount: 289 },
          { id: 't28', name: 'aws', questionsCount: 198 },
          { id: 't29', name: 'mongodb', questionsCount: 234 },
          { id: 't30', name: 'redux', questionsCount: 178 },
          { id: 't31', name: 'graphql', questionsCount: 156 },
          { id: 't32', name: 'rest-api', questionsCount: 267 },
          { id: 't33', name: 'microservices', questionsCount: 134 },
          { id: 't34', name: 'devops', questionsCount: 189 },
          { id: 't35', name: 'git', questionsCount: 345 },
          { id: 't36', name: 'webpack', questionsCount: 123 },
          { id: 't37', name: 'nextjs', questionsCount: 234 },
          { id: 't38', name: 'vue', questionsCount: 178 },
          { id: 't39', name: 'angular', questionsCount: 189 },
          { id: 't40', name: 'linux', questionsCount: 156 }
        ];

        setTags(mockTags);
        localStorage.setItem('qa_tags', JSON.stringify(mockTags));
      }
      setIsLoading(false);
    };

    loadTags();
  }, []);

  // Save tags to localStorage whenever tags change
  useEffect(() => {
    if (tags.length > 0) {
      localStorage.setItem('qa_tags', JSON.stringify(tags));
    }
  }, [tags]);

  const getTagByName = (name: string): Tag | null => {
    return tags.find(t => t.name.toLowerCase() === name.toLowerCase()) || null;
  };

  const createTag = (name: string): Tag => {
    const normalizedName = name.toLowerCase().trim();
    
    // Check if tag already exists
    const existingTag = getTagByName(normalizedName);
    if (existingTag) {
      return existingTag;
    }

    const newTag: Tag = {
      id: `t${Date.now()}`,
      name: normalizedName,
      questionsCount: 1
    };

    setTags(prev => [...prev, newTag]);
    return newTag;
  };

  const getPopularTags = (limit: number = 10): Tag[] => {
    return [...tags]
      .sort((a, b) => (b.questionsCount || 0) - (a.questionsCount || 0))
      .slice(0, limit);
  };

  const searchTags = (query: string): Tag[] => {
    if (!query.trim()) return [];
    
    const searchTerm = query.toLowerCase();
    return tags.filter(tag => 
      tag.name.toLowerCase().includes(searchTerm)
    ).sort((a, b) => {
      // Prioritize exact matches
      if (a.name.toLowerCase() === searchTerm) return -1;
      if (b.name.toLowerCase() === searchTerm) return 1;
      
      // Then by popularity
      return (b.questionsCount || 0) - (a.questionsCount || 0);
    });
  };

  const updateTagCount = (tagName: string) => {
    setTags(prev => prev.map(tag => 
      tag.name === tagName 
        ? { ...tag, questionsCount: (tag.questionsCount || 0) + 1 }
        : tag
    ));
  };

  const value: TagsContextType = {
    tags,
    getTagByName,
    createTag,
    getPopularTags,
    searchTags,
    updateTagCount,
    isLoading
  };

  return (
    <TagsContext.Provider value={value}>
      {children}
    </TagsContext.Provider>
  );
}