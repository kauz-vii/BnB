import { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { Answer, AskerRating } from '../types';
import { getUserById } from './AuthContext';

interface AnswersContextType {
  answers: Answer[];
  getAnswerById: (id: string) => Answer | null;
  getAnswersByQuestion: (questionId: string) => Answer[];
  getAnswersByAuthor: (authorId: string) => Answer[];
  createAnswer: (questionId: string, body: string, authorId: string) => Promise<Answer>;
  updateAnswer: (id: string, updates: Partial<Answer>) => void;
  deleteAnswer: (id: string) => void;
  acceptAnswer: (answerId: string) => void;
  rateAnswer: (answerId: string, raterId: string, stars: number) => void;
  getAnswerRating: (answerId: string, raterId: string) => AskerRating | null;
  isLoading: boolean;
}

const AnswersContext = createContext<AnswersContextType | null>(null);

export function useAnswers() {
  const context = useContext(AnswersContext);
  if (!context) throw new Error('useAnswers must be used within AnswersProvider');
  return context;
}

interface AnswersProviderProps {
  children: ReactNode;
}

export function AnswersProvider({ children }: AnswersProviderProps) {
  const [answers, setAnswers] = useState<Answer[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  // Initialize mock answers data
  useEffect(() => {
    const loadAnswers = () => {
      // Check for stored answers
      const storedAnswers = localStorage.getItem('qa_answers');
      if (storedAnswers) {
        const parsed = JSON.parse(storedAnswers);
        // Convert date strings back to Date objects
        const answersWithDates = parsed.map((a: any) => ({
          ...a,
          createdAt: new Date(a.createdAt),
          updatedAt: new Date(a.updatedAt),
          author: getUserById(a.authorId) || a.author,
          ratings: a.ratings || []
        }));
        setAnswers(answersWithDates);
      } else {
        // Initialize with mock data
        const mockAnswers: Answer[] = [
          {
            id: 'a1',
            questionId: 'q1',
            authorId: '3',
            author: getUserById('3')!,
            body: `Great question! Here's a comprehensive approach to JWT authentication security:

## 1. Token Storage Strategy

**httpOnly Cookies** are generally the most secure option:

\`\`\`javascript
// Server-side (Express.js)
app.post('/auth/login', async (req, res) => {
  const { accessToken, refreshToken } = await authenticateUser(req.body);
  
  res.cookie('accessToken', accessToken, {
    httpOnly: true,
    secure: true,
    sameSite: 'strict',
    maxAge: 15 * 60 * 1000 // 15 minutes
  });
  
  res.cookie('refreshToken', refreshToken, {
    httpOnly: true,
    secure: true,
    sameSite: 'strict',
    maxAge: 7 * 24 * 60 * 60 * 1000 // 7 days
  });
});
\`\`\`

## 2. Implementation Best Practices

- **Short-lived access tokens** (15-30 minutes)
- **Automatic token refresh** using refresh tokens
- **Secure cookie flags** (httpOnly, secure, sameSite)
- **CSRF protection** for state-changing operations

## 3. Client-side Implementation

\`\`\`javascript
// Axios interceptor for automatic token refresh
axios.interceptors.response.use(
  (response) => response,
  async (error) => {
    if (error.response?.status === 401) {
      await refreshToken();
      return axios.request(error.config);
    }
    return Promise.reject(error);
  }
);
\`\`\`

This approach provides excellent security while maintaining good UX.`,
            createdAt: new Date(Date.now() - 1800000), // 30 minutes ago
            updatedAt: new Date(Date.now() - 1800000),
            score: 15,
            isAccepted: true,
            ratings: [],
            comments: [],
            votes: []
          },
          {
            id: 'a2',
            questionId: 'q1',
            authorId: '4',
            author: getUserById('4')!,
            body: `I'd also recommend implementing a **token blacklist** for logout functionality:

\`\`\`javascript
// Server-side token blacklist
const blacklistedTokens = new Set();

const logout = (req, res) => {
  const token = req.cookies.accessToken;
  blacklistedTokens.add(token);
  res.clearCookie('accessToken');
  res.clearCookie('refreshToken');
};

// Middleware to check blacklist
const verifyToken = (req, res, next) => {
  const token = req.cookies.accessToken;
  if (blacklistedTokens.has(token)) {
    return res.status(401).json({ error: 'Token revoked' });
  }
  // Continue with JWT verification...
};
\`\`\`

Additionally, consider using **Redis** for token storage in production for better scalability.`,
            createdAt: new Date(Date.now() - 900000), // 15 minutes ago
            updatedAt: new Date(Date.now() - 900000),
            score: 8,
            isAccepted: false,
            ratings: [],
            comments: [],
            votes: []
          },
          {
            id: 'a3',
            questionId: 'q2',
            authorId: '1',
            author: getUserById('1')!,
            body: `For Node.js error handling, I recommend a comprehensive approach:

## 1. Global Error Handler Middleware

\`\`\`javascript
// error-handler.js
const errorHandler = (err, req, res, next) => {
  let error = { ...err };
  error.message = err.message;

  // Log error
  console.error(err);

  // Mongoose bad ObjectId
  if (err.name === 'CastError') {
    const message = 'Resource not found';
    error = { message, statusCode: 404 };
  }

  // Mongoose duplicate key
  if (err.code === 11000) {
    const message = 'Duplicate field value entered';
    error = { message, statusCode: 400 };
  }

  // Mongoose validation error
  if (err.name === 'ValidationError') {
    const message = Object.values(err.errors).map(val => val.message);
    error = { message, statusCode: 400 };
  }

  res.status(error.statusCode || 500).json({
    success: false,
    error: error.message || 'Server Error'
  });
};

module.exports = errorHandler;
\`\`\`

## 2. Custom Error Classes

\`\`\`javascript
class ErrorResponse extends Error {
  constructor(message, statusCode) {
    super(message);
    this.statusCode = statusCode;
  }
}

module.exports = ErrorResponse;
\`\`\`

This gives you clean, consistent error handling across your entire API.`,
            createdAt: new Date(Date.now() - 5400000), // 1.5 hours ago
            updatedAt: new Date(Date.now() - 5400000),
            score: 12,
            isAccepted: false,
            ratings: [],
            comments: [],
            votes: []
          },
          {
            id: 'a4',
            questionId: 'q3',
            authorId: '2',
            author: getUserById('2')!,
            body: `Here are some advanced React optimization techniques:

## 1. Virtualization for Large Lists

\`\`\`javascript
import { FixedSizeList as List } from 'react-window';

const VirtualizedList = ({ items }) => (
  <List
    height={400}
    itemCount={items.length}
    itemSize={50}
    itemData={items}
  >
    {({ index, style, data }) => (
      <div style={style}>
        {data[index].name}
      </div>
    )}
  </List>
);
\`\`\`

## 2. Smart Context Splitting

Instead of one large context, split into multiple focused contexts:

\`\`\`javascript
// Instead of one UserContext with everything
const UserDataContext = createContext();
const UserActionsContext = createContext();

// This prevents unnecessary re-renders when only actions change
\`\`\`

## 3. Lazy Loading with Suspense

\`\`\`javascript
const LazyComponent = lazy(() => import('./HeavyComponent'));

function App() {
  return (
    <Suspense fallback={<Loading />}>
      <LazyComponent />
    </Suspense>
  );
}
\`\`\`

These techniques can dramatically improve performance for complex applications.`,
            createdAt: new Date(Date.now() - 3600000), // 1 hour ago
            updatedAt: new Date(Date.now() - 3600000),
            score: 25,
            isAccepted: true,
            ratings: [],
            comments: [],
            votes: []
          }
        ];

        setAnswers(mockAnswers);
        localStorage.setItem('qa_answers', JSON.stringify(mockAnswers));
      }
      setIsLoading(false);
    };

    loadAnswers();
  }, []);

  // Save answers to localStorage whenever answers change
  useEffect(() => {
    if (answers.length > 0) {
      localStorage.setItem('qa_answers', JSON.stringify(answers));
    }
  }, [answers]);

  const getAnswerById = (id: string): Answer | null => {
    return answers.find(a => a.id === id) || null;
  };

  const getAnswersByQuestion = (questionId: string): Answer[] => {
    return answers.filter(a => a.questionId === questionId);
  };

  const getAnswersByAuthor = (authorId: string): Answer[] => {
    return answers.filter(a => a.authorId === authorId);
  };

  const createAnswer = async (questionId: string, body: string, authorId: string): Promise<Answer> => {
    const author = getUserById(authorId);
    if (!author) throw new Error('Author not found');

    const newAnswer: Answer = {
      id: `a${Date.now()}`,
      questionId,
      authorId,
      author,
      body,
      createdAt: new Date(),
      updatedAt: new Date(),
      score: 0,
      isAccepted: false,
      ratings: [],
      comments: [],
      votes: []
    };

    setAnswers(prev => [...prev, newAnswer]);
    return newAnswer;
  };

  const updateAnswer = (id: string, updates: Partial<Answer>) => {
    setAnswers(prev => prev.map(a => 
      a.id === id 
        ? { ...a, ...updates, updatedAt: new Date() }
        : a
    ));
  };

  const deleteAnswer = (id: string) => {
    setAnswers(prev => prev.filter(a => a.id !== id));
  };

  const acceptAnswer = (answerId: string) => {
    setAnswers(prev => prev.map(a => 
      a.id === answerId 
        ? { ...a, isAccepted: true }
        : { ...a, isAccepted: false } // Only one answer can be accepted per question
    ));
  };

  const rateAnswer = (answerId: string, raterId: string, stars: number) => {
    setAnswers(prev => prev.map(a => {
      if (a.id === answerId) {
        const existingRatingIndex = a.ratings.findIndex(r => r.raterId === raterId);
        const newRating: AskerRating = {
          id: `r${Date.now()}`,
          questionId: a.questionId,
          answerId,
          raterId,
          answererId: a.authorId,
          stars,
          createdAt: new Date()
        };

        if (existingRatingIndex >= 0) {
          // Update existing rating
          const updatedRatings = [...a.ratings];
          updatedRatings[existingRatingIndex] = newRating;
          return { ...a, ratings: updatedRatings };
        } else {
          // Add new rating
          return { ...a, ratings: [...a.ratings, newRating] };
        }
      }
      return a;
    }));
  };

  const getAnswerRating = (answerId: string, raterId: string): AskerRating | null => {
    const answer = answers.find(a => a.id === answerId);
    if (!answer) return null;
    
    return answer.ratings.find(r => r.raterId === raterId) || null;
  };

  const value: AnswersContextType = {
    answers,
    getAnswerById,
    getAnswersByQuestion,
    getAnswersByAuthor,
    createAnswer,
    updateAnswer,
    deleteAnswer,
    acceptAnswer,
    rateAnswer,
    getAnswerRating,
    isLoading
  };

  return (
    <AnswersContext.Provider value={value}>
      {children}
    </AnswersContext.Provider>
  );
}