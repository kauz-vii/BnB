import { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { Notification } from '../types';

interface NotificationsContextType {
  notifications: Notification[];
  getNotificationsByUser: (userId: string) => Notification[];
  getUnreadCount: (userId: string) => number;
  createNotification: (userId: string, type: Notification['type'], data: any) => void;
  markAsRead: (notificationId: string) => void;
  markAllAsRead: (userId: string) => void;
  deleteNotification: (notificationId: string) => void;
  isLoading: boolean;
}

const NotificationsContext = createContext<NotificationsContextType | null>(null);

export function useNotifications() {
  const context = useContext(NotificationsContext);
  if (!context) throw new Error('useNotifications must be used within NotificationsProvider');
  return context;
}

interface NotificationsProviderProps {
  children: ReactNode;
}

export function NotificationsProvider({ children }: NotificationsProviderProps) {
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  // Initialize mock notifications data
  useEffect(() => {
    const loadNotifications = () => {
      // Check for stored notifications
      const storedNotifications = localStorage.getItem('qa_notifications');
      if (storedNotifications) {
        const parsed = JSON.parse(storedNotifications);
        // Convert date strings back to Date objects
        const notificationsWithDates = parsed.map((n: any) => ({
          ...n,
          createdAt: new Date(n.createdAt)
        }));
        setNotifications(notificationsWithDates);
      } else {
        // Initialize with mock data
        const mockNotifications: Notification[] = [
          {
            id: 'n1',
            userId: '2', // CodeMaster
            type: 'ANSWER_POSTED',
            data: {
              questionTitle: 'How to implement user authentication with JWT tokens in a React application?',
              answerAuthor: 'SecurityExpert',
              questionId: 'q1'
            },
            read: false,
            createdAt: new Date(Date.now() - 1800000) // 30 minutes ago
          },
          {
            id: 'n2',
            userId: '2', // CodeMaster
            type: 'ANSWER_POSTED',
            data: {
              questionTitle: 'How to implement user authentication with JWT tokens in a React application?',
              answerAuthor: 'ReactGuru',
              questionId: 'q1'
            },
            read: false,
            createdAt: new Date(Date.now() - 900000) // 15 minutes ago
          },
          {
            id: 'n3',
            userId: '3', // SecurityExpert
            type: 'RATING_RECEIVED',
            data: {
              stars: 5,
              questionTitle: 'How to implement user authentication with JWT tokens in a React application?',
              raterId: 'CodeMaster'
            },
            read: false,
            createdAt: new Date(Date.now() - 600000) // 10 minutes ago
          },
          {
            id: 'n4',
            userId: '3', // SecurityExpert
            type: 'ANSWER_ACCEPTED',
            data: {
              questionTitle: 'How to implement user authentication with JWT tokens in a React application?',
              questionId: 'q1',
              answerId: 'a1'
            },
            read: true,
            createdAt: new Date(Date.now() - 300000) // 5 minutes ago
          },
          {
            id: 'n5',
            userId: '1', // TonyStark
            type: 'ANSWER_POSTED',
            data: {
              questionTitle: 'TypeScript generics with React components',
              answerAuthor: 'ReactGuru',
              questionId: 'q5'
            },
            read: true,
            createdAt: new Date(Date.now() - 7200000) // 2 hours ago
          },
          {
            id: 'n6',
            userId: '4', // ReactGuru
            type: 'RATING_RECEIVED',
            data: {
              stars: 4,
              questionTitle: 'How to implement user authentication with JWT tokens in a React application?',
              raterId: 'CodeMaster'
            },
            read: false,
            createdAt: new Date(Date.now() - 450000) // 7.5 minutes ago
          }
        ];

        setNotifications(mockNotifications);
        localStorage.setItem('qa_notifications', JSON.stringify(mockNotifications));
      }
      setIsLoading(false);
    };

    loadNotifications();
  }, []);

  // Save notifications to localStorage whenever notifications change
  useEffect(() => {
    if (notifications.length > 0) {
      localStorage.setItem('qa_notifications', JSON.stringify(notifications));
    }
  }, [notifications]);

  const getNotificationsByUser = (userId: string): Notification[] => {
    return notifications
      .filter(n => n.userId === userId)
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
  };

  const getUnreadCount = (userId: string): number => {
    return notifications.filter(n => n.userId === userId && !n.read).length;
  };

  const createNotification = (userId: string, type: Notification['type'], data: any) => {
    const newNotification: Notification = {
      id: `n${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
      userId,
      type,
      data,
      read: false,
      createdAt: new Date()
    };

    setNotifications(prev => [newNotification, ...prev]);
  };

  const markAsRead = (notificationId: string) => {
    setNotifications(prev => prev.map(n => 
      n.id === notificationId 
        ? { ...n, read: true }
        : n
    ));
  };

  const markAllAsRead = (userId: string) => {
    setNotifications(prev => prev.map(n => 
      n.userId === userId 
        ? { ...n, read: true }
        : n
    ));
  };

  const deleteNotification = (notificationId: string) => {
    setNotifications(prev => prev.filter(n => n.id !== notificationId));
  };

  const value: NotificationsContextType = {
    notifications,
    getNotificationsByUser,
    getUnreadCount,
    createNotification,
    markAsRead,
    markAllAsRead,
    deleteNotification,
    isLoading
  };

  return (
    <NotificationsContext.Provider value={value}>
      {children}
    </NotificationsContext.Provider>
  );
}