import { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { User } from '../types';

interface AuthContextType {
  user: User | null;
  login: (email: string, password: string) => Promise<void>;
  register: (username: string, email: string, password: string) => Promise<void>;
  logout: () => void;
  updateUser: (updates: Partial<User>) => void;
  isLoading: boolean;
}

const AuthContext = createContext<AuthContextType | null>(null);

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) throw new Error('useAuth must be used within AuthProvider');
  return context;
}

interface AuthProviderProps {
  children: ReactNode;
}

export function AuthProvider({ children }: AuthProviderProps) {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  // Mock users database
  const mockUsers: User[] = [
    {
      id: '1',
      username: 'TonyStark',
      email: 'tony@stark.com',
      avatarUrl: null,
      bio: 'Genius, billionaire, playboy, philanthropist',
      reputation: 1250,
      level: 4,
      createdAt: new Date('2023-01-15'),
      features: ['DM', 'GROUP_CHAT', 'VIDEO_CALL', 'EDIT_POSTS']
    },
    {
      id: '2',
      username: 'CodeMaster',
      email: 'code@master.com',
      avatarUrl: null,
      bio: 'Full-stack developer with 10+ years of experience',
      reputation: 2450,
      level: 5,
      createdAt: new Date('2022-06-10'),
      features: ['DM', 'GROUP_CHAT', 'VIDEO_CALL', 'EDIT_POSTS', 'CREATE_TAGS']
    },
    {
      id: '3',
      username: 'SecurityExpert',
      email: 'security@expert.com',
      avatarUrl: null,
      bio: 'Senior Software Engineer specializing in web security and authentication systems',
      reputation: 4200,
      level: 6,
      createdAt: new Date('2021-03-20'),
      features: ['DM', 'GROUP_CHAT', 'VIDEO_CALL', 'EDIT_POSTS', 'CREATE_TAGS', 'COMMUNITY_MOD']
    },
    {
      id: '4',
      username: 'ReactGuru',
      email: 'react@guru.com',
      avatarUrl: null,
      bio: 'React specialist and performance optimization expert',
      reputation: 3200,
      level: 6,
      createdAt: new Date('2021-08-05'),
      features: ['DM', 'GROUP_CHAT', 'VIDEO_CALL', 'EDIT_POSTS', 'CREATE_TAGS', 'COMMUNITY_MOD']
    },
    {
      id: '5',
      username: 'DBArchitect',
      email: 'db@architect.com',
      avatarUrl: null,
      bio: 'Database architect and backend systems specialist',
      reputation: 987,
      level: 3,
      createdAt: new Date('2023-05-12'),
      features: ['DM', 'GROUP_CHAT', 'TAG_SUGGEST']
    }
  ];

  useEffect(() => {
    // Check for existing session
    const token = localStorage.getItem('qa_token');
    const savedUserId = localStorage.getItem('qa_user_id');
    
    if (token && savedUserId) {
      // Find user in mock database
      const foundUser = mockUsers.find(u => u.id === savedUserId);
      if (foundUser) {
        setUser(foundUser);
      }
    }
    
    setIsLoading(false);
  }, []);

  const saveUserSession = (user: User, token: string) => {
    localStorage.setItem('qa_token', token);
    localStorage.setItem('qa_user_id', user.id);
    localStorage.setItem('qa_user_data', JSON.stringify(user));
  };

  const clearUserSession = () => {
    localStorage.removeItem('qa_token');
    localStorage.removeItem('qa_user_id');
    localStorage.removeItem('qa_user_data');
  };

  const login = async (email: string, password: string) => {
    try {
      // Simulate API call delay
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      // Find user by email
      const foundUser = mockUsers.find(u => u.email === email);
      if (!foundUser) {
        throw new Error('Invalid credentials');
      }

      const token = `mock-token-${foundUser.id}-${Date.now()}`;
      setUser(foundUser);
      saveUserSession(foundUser, token);
    } catch (error) {
      throw new Error('Login failed');
    }
  };

  const register = async (username: string, email: string, password: string) => {
    try {
      // Simulate API call delay
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      // Check if user already exists
      const existingUser = mockUsers.find(u => u.email === email || u.username === username);
      if (existingUser) {
        throw new Error('User already exists');
      }

      const newUser: User = {
        id: `user-${Date.now()}`,
        username,
        email,
        avatarUrl: null,
        bio: null,
        reputation: 0,
        level: 1,
        createdAt: new Date(),
        features: ['ASK_QUESTION', 'ANSWER_QUESTION', 'COMMENT']
      };

      // Add to mock database
      mockUsers.push(newUser);
      
      const token = `mock-token-${newUser.id}-${Date.now()}`;
      setUser(newUser);
      saveUserSession(newUser, token);
    } catch (error) {
      throw new Error('Registration failed');
    }
  };

  const logout = () => {
    setUser(null);
    clearUserSession();
  };

  const updateUser = (updates: Partial<User>) => {
    if (user) {
      const updatedUser = { ...user, ...updates };
      setUser(updatedUser);
      
      // Update in mock database
      const userIndex = mockUsers.findIndex(u => u.id === user.id);
      if (userIndex !== -1) {
        mockUsers[userIndex] = updatedUser;
      }
      
      // Update stored user data
      localStorage.setItem('qa_user_data', JSON.stringify(updatedUser));
    }
  };

  const value: AuthContextType = {
    user,
    login,
    register,
    logout,
    updateUser,
    isLoading
  };

  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  );
}

// Utility function to get user by ID
export const getUserById = (userId: string): User | null => {
  const mockUsers: User[] = [
    {
      id: '1',
      username: 'TonyStark',
      email: 'tony@stark.com',
      avatarUrl: null,
      bio: 'Genius, billionaire, playboy, philanthropist',
      reputation: 1250,
      level: 4,
      createdAt: new Date('2023-01-15'),
      features: ['DM', 'GROUP_CHAT', 'VIDEO_CALL', 'EDIT_POSTS']
    },
    {
      id: '2',
      username: 'CodeMaster',
      email: 'code@master.com',
      avatarUrl: null,
      bio: 'Full-stack developer with 10+ years of experience',
      reputation: 2450,
      level: 5,
      createdAt: new Date('2022-06-10'),
      features: ['DM', 'GROUP_CHAT', 'VIDEO_CALL', 'EDIT_POSTS', 'CREATE_TAGS']
    },
    {
      id: '3',
      username: 'SecurityExpert',
      email: 'security@expert.com',
      avatarUrl: null,
      bio: 'Senior Software Engineer specializing in web security and authentication systems',
      reputation: 4200,
      level: 6,
      createdAt: new Date('2021-03-20'),
      features: ['DM', 'GROUP_CHAT', 'VIDEO_CALL', 'EDIT_POSTS', 'CREATE_TAGS', 'COMMUNITY_MOD']
    },
    {
      id: '4',
      username: 'ReactGuru',
      email: 'react@guru.com',
      avatarUrl: null,
      bio: 'React specialist and performance optimization expert',
      reputation: 3200,
      level: 6,
      createdAt: new Date('2021-08-05'),
      features: ['DM', 'GROUP_CHAT', 'VIDEO_CALL', 'EDIT_POSTS', 'CREATE_TAGS', 'COMMUNITY_MOD']
    },
    {
      id: '5',
      username: 'DBArchitect',
      email: 'db@architect.com',
      avatarUrl: null,
      bio: 'Database architect and backend systems specialist',
      reputation: 987,
      level: 3,
      createdAt: new Date('2023-05-12'),
      features: ['DM', 'GROUP_CHAT', 'TAG_SUGGEST']
    }
  ];
  
  return mockUsers.find(user => user.id === userId) || null;
};